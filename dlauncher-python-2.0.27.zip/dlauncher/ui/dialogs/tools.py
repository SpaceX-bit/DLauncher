"""Окна «удобных штук»: ярлык, шаблоны настроек, быстрый FPS, проверка сборки, ссылка на лог, Ctrl+K."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication, QCheckBox, QLabel, QLineEdit, QListWidget, QListWidgetItem

from .. import i18n
from ..widgets import Modal, VScroll, label

i18n.register({
    "Ярлык на рабочий стол": "Desktop shortcut",
    "Ярлык создан: двойной щелчок запустит «{n}»": "Shortcut created: double-click launches “{n}”",
    "Шаблоны настроек": "Settings templates",
    "Шаблон — это сохранённые настройки игры (графика, управление, звук). Применяй их к любой сборке.":
        "A template is a saved set of game options (graphics, controls, sound). Apply it to any build.",
    "Название шаблона": "Template name",
    "Сохранить текущие": "Save current",
    "Применить": "Apply",
    "Удалить": "Delete",
    "Шаблонов пока нет": "No templates yet",
    "Шаблон «{n}» сохранён": "Template “{n}” saved",
    "Шаблон «{n}» применён (старые настройки лежат в options.txt.bak)": "Template “{n}” applied (old options are in options.txt.bak)",
    "Применить шаблон «{n}» к сборке «{b}»? Текущие настройки игры будут заменены (копия сохранится).":
        "Apply template “{n}” to build “{b}”? The current game options will be replaced (a backup is kept).",
    "Удалить шаблон «{n}»?": "Delete template “{n}”?",
    "Быстрый режим FPS": "Quick FPS mode",
    "Один клик, чтобы игра меньше тормозила. Всё можно вернуть: старые настройки копируются в options.txt.bak.":
        "One click to make the game run smoother. Everything is reversible: old options are copied to options.txt.bak.",
    "Оптимизированные аргументы Java": "Optimized Java arguments",
    "Подобрать память: {n} ГБ": "Set memory: {n} GB",
    "Облегчить графику в настройках игры ({n} пунктов)": "Lighten graphics in game options ({n} items)",
    "Поставить моды-оптимизаторы (Sodium, Lithium и др.)": "Install optimization mods (Sodium, Lithium, etc.)",
    "Ускорить": "Speed up",
    "Готово: {n}": "Done: {n}",
    "Применяю...": "Applying...",
    "Ставлю моды-оптимизаторы...": "Installing optimization mods...",
    "Установлено модов: {n}": "Mods installed: {n}",
    "Проверка сборки": "Build check",
    "Проверяю...": "Checking...",
    "Проверено модов: {n}": "Mods checked: {n}",
    "Ошибок: {n}": "Errors: {n}",
    "Предупреждений: {n}": "Warnings: {n}",
    "Со сборкой всё в порядке": "The build looks fine",
    "Поделиться логом": "Share log",
    "Лог игры": "Game log",
    "Отчёт о вылете": "Crash report",
    "Лог будет загружен на mclo.gs (публичный сервис логов), и ты получишь ссылку. Токены и имя папки пользователя скрываются автоматически. Загрузить?":
        "The log will be uploaded to mclo.gs (a public log service) and you will get a link. Tokens and your user folder name are hidden automatically. Upload?",
    "Загрузить": "Upload",
    "Ссылка на лог скопирована": "Log link copied",
    "Загружаю лог...": "Uploading log...",
    "Поиск: сборки, страницы, действия": "Search: builds, pages, actions",
    "Играть: {n}": "Play: {n}",
    "Открыть: {n}": "Open: {n}",
    "Ничего не найдено": "Nothing found",
    "Сборка не найдена": "Build not found",
    "Закрыть": "Close", "Отмена": "Cancel", "Нет профилей": "No profiles",
})


def _err(app):
    return lambda m: app.toast(str(m), "err")


# ---------- ярлык ----------
def create_shortcut(app, p: dict) -> None:
    def ok(r):
        if isinstance(r, dict) and r.get("ok"):
            app.toast(app.t("Ярлык создан: двойной щелчок запустит «{n}»", n=p["name"]), "ok")
        else:
            app.toast(app.t(str((r or {}).get("error") or "?")), "err")
    app.call("shortcut:create", {"profileId": p["id"]}, ok, _err(app))


# ---------- шаблоны настроек ----------
class PresetsDialog(Modal):
    def __init__(self, app, profile: dict, parent=None):
        super().__init__(app, "Шаблоны настроек", width=520, height=420, parent=parent)
        self.p = profile
        self.body.addWidget(label(app, "Шаблон — это сохранённые настройки игры (графика, управление, звук). Применяй их к любой сборке.", "muted", wrap=True))
        self.list = VScroll()
        self.body.addWidget(self.list, 1)
        self.name = QLineEdit()
        self.name.setMaxLength(40)
        self.name.setPlaceholderText(app.t("Название шаблона"))
        self.body.addWidget(self.name)
        self.add_button("Сохранить текущие", "primary", self._save)
        self.add_button("Закрыть", "ghost", self.accept)
        self.refresh()

    def refresh(self) -> None:
        self.app.call("optpresets:list", None, self._got, _err(self.app))

    def _got(self, r) -> None:
        from PySide6.QtWidgets import QHBoxLayout, QWidget
        from ..widgets import button
        lay = self.list.lay
        while lay.count():
            it = lay.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
        items = (r or {}).get("items") if isinstance(r, dict) else None
        if not items:
            lay.addWidget(label(self.app, "Шаблонов пока нет", "muted"))
            lay.addStretch(1)
            return
        for it in items:
            row = QHBoxLayout()
            row.setContentsMargins(0, 0, 0, 0)
            row.addWidget(QLabel(str(it["name"])), 1)
            row.addWidget(button(self.app, "Применить", "small", lambda n=it["name"]: self._apply(n)))
            row.addWidget(button(self.app, "Удалить", "small", lambda n=it["name"]: self._delete(n)))
            w = QWidget()
            w.setLayout(row)
            lay.addWidget(w)
        lay.addStretch(1)

    def _save(self) -> None:
        n = self.name.text().strip()

        def ok(r):
            if isinstance(r, dict) and r.get("ok"):
                self.app.toast(self.app.t("Шаблон «{n}» сохранён", n=r["name"]), "ok")
                self.name.clear()
                self.refresh()
            else:
                self.app.toast(self.app.t(str((r or {}).get("error") or "?")), "err")
        self.app.call("optpresets:save", {"profileId": self.p["id"], "name": n}, ok, _err(self.app))

    def _apply(self, n: str) -> None:
        if not self.app.confirm("Применить шаблон «{n}» к сборке «{b}»? Текущие настройки игры будут заменены (копия сохранится).",
                                "Применить", n=n, b=self.p["name"]):
            return

        def ok(r):
            if isinstance(r, dict) and r.get("ok"):
                self.app.toast(self.app.t("Шаблон «{n}» применён (старые настройки лежат в options.txt.bak)", n=n), "ok")
            else:
                self.app.toast(self.app.t(str((r or {}).get("error") or "?")), "err")
        self.app.call("optpresets:apply", {"profileId": self.p["id"], "name": n}, ok, _err(self.app))

    def _delete(self, n: str) -> None:
        if self.app.confirm("Удалить шаблон «{n}»?", "Удалить", danger=True, n=n):
            self.app.call("optpresets:delete", {"name": n}, lambda r: self.refresh(), _err(self.app))


# ---------- быстрый FPS ----------
class FpsDialog(Modal):
    def __init__(self, app, profile: dict, parent=None):
        super().__init__(app, "Быстрый режим FPS", width=500, parent=parent)
        self.p = profile
        self.plan: dict = {}
        self.body.addWidget(label(app, "Один клик, чтобы игра меньше тормозила. Всё можно вернуть: старые настройки копируются в options.txt.bak.", "muted", wrap=True))
        self.c_jvm = QCheckBox(app.t("Оптимизированные аргументы Java"))
        self.c_ram = QCheckBox("")
        self.c_opt = QCheckBox("")
        self.c_mods = QCheckBox(app.t("Поставить моды-оптимизаторы (Sodium, Lithium и др.)"))
        for c in (self.c_jvm, self.c_ram, self.c_opt, self.c_mods):
            c.setChecked(True)
            self.body.addWidget(c)
        self.status = label(app, None, "muted", wrap=True)
        self.body.addWidget(self.status)
        self.go_btn = self.add_button("Ускорить", "primary", self._go)
        self.go_btn.setEnabled(False)
        self.add_button("Закрыть", "ghost", self.accept)
        app.call("fps:plan", {"profileId": profile["id"]}, self._plan, _err(app))

    def _plan(self, r) -> None:
        if not (isinstance(r, dict) and r.get("ok")):
            self.status.setText(self.app.t(str((r or {}).get("error") or "?")))
            return
        self.plan = r
        self.c_ram.setText(self.app.t("Подобрать память: {n} ГБ", n=r["ram"]))
        n = len(r.get("options") or [])
        self.c_opt.setText(self.app.t("Облегчить графику в настройках игры ({n} пунктов)", n=n))
        self.c_opt.setEnabled(n > 0)
        self.c_opt.setChecked(n > 0)
        self.c_mods.setEnabled(bool(r.get("canOptimize")))
        self.c_mods.setChecked(bool(r.get("canOptimize")))
        self.go_btn.setEnabled(True)

    def _go(self) -> None:
        self.go_btn.setEnabled(False)
        self.status.setText(self.app.t("Применяю..."))
        payload = {"profileId": self.p["id"], "jvm": self.c_jvm.isChecked(), "ram": self.c_ram.isChecked(),
                   "options": self.c_opt.isChecked() and self.c_opt.isEnabled()}

        def after_mods(r):
            n = (r or {}).get("installed", 0) if isinstance(r, dict) else 0
            self.status.setText(self.app.t("Установлено модов: {n}", n=n))
            self.app.refresh_profiles()
            self.app.toast(self.app.t("Готово: {n}", n=self.app.t("Быстрый режим FPS")), "ok")
            self.go_btn.setEnabled(True)

        def ok(r):
            if not (isinstance(r, dict) and r.get("ok")):
                self.status.setText(self.app.t(str((r or {}).get("error") or "?")))
                self.go_btn.setEnabled(True)
                return
            self.app.refresh_profiles()
            if self.c_mods.isChecked() and self.c_mods.isEnabled():
                self.status.setText(self.app.t("Ставлю моды-оптимизаторы..."))
                self.app.call("opt:install", {"profileId": self.p["id"]}, after_mods, _err(self.app))
            else:
                after_mods({"installed": 0})
        self.app.call("fps:apply", payload, ok, lambda m: (self.status.setText(str(m)), self.go_btn.setEnabled(True)))


# ---------- проверка сборки ----------
class BuildCheckDialog(Modal):
    def __init__(self, app, profile: dict, parent=None):
        super().__init__(app, "Проверка сборки", width=620, height=460, parent=parent)
        self.p = profile
        self.sum = label(app, "Проверяю...", "muted", wrap=True)
        self.body.addWidget(self.sum)
        self.scroll = VScroll()
        self.body.addWidget(self.scroll, 1)
        self.add_button("Закрыть", "primary", self.accept)
        self.refresh()

    def refresh(self) -> None:
        self.app.call("profile:check", {"profileId": self.p["id"]}, self._got, lambda m: self.sum.setText(str(m)))

    def _got(self, r) -> None:
        from .compat import problem_card
        lay = self.scroll.lay
        while lay.count():
            it = lay.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
        if not (isinstance(r, dict) and r.get("ok")):
            self.sum.setText(self.app.t(str((r or {}).get("error") or "?")))
            return
        s = r.get("summary") or {}
        bits = [self.app.t("Проверено модов: {n}", n=r.get("scanned", 0)),
                self.app.t("Ошибок: {n}", n=s.get("errors", 0)), self.app.t("Предупреждений: {n}", n=s.get("warnings", 0))]
        self.sum.setText(" · ".join(bits))
        probs = r.get("problems") or []
        if not probs:
            lay.addWidget(label(self.app, "Со сборкой всё в порядке", "ok"))
        for pr in probs:
            lay.addWidget(problem_card(self.app, pr, self.p["id"], self.refresh))
        lay.addStretch(1)


# ---------- ссылка на лог ----------
def share_log(app, profile: dict, what: str = "log") -> None:
    if not app.confirm("Лог будет загружен на mclo.gs (публичный сервис логов), и ты получишь ссылку. Токены и имя папки пользователя скрываются автоматически. Загрузить?",
                       "Загрузить"):
        return
    app.toast(app.t("Загружаю лог..."), "info")

    def ok(r):
        if isinstance(r, dict) and r.get("ok") and r.get("url"):
            QApplication.clipboard().setText(str(r["url"]))
            app.info("Поделиться логом", f"{app.t('Ссылка на лог скопирована')}:\n{r['url']}")
        else:
            app.toast(app.t(str((r or {}).get("error") or "?")), "err")
    app.call("log:share", {"profileId": profile["id"], "what": what}, ok, _err(app))


# ---------- Ctrl+K ----------
class PaletteDialog(Modal):
    def __init__(self, app, parent=None):
        super().__init__(app, "Поиск: сборки, страницы, действия", width=520, height=420, parent=parent)
        self.edit = QLineEdit()
        self.edit.setPlaceholderText(app.t("Поиск: сборки, страницы, действия"))
        self.body.addWidget(self.edit)
        self.list = QListWidget()
        self.body.addWidget(self.list, 1)
        self.entries = self._build()
        self.edit.textChanged.connect(self._filter)
        self.edit.returnPressed.connect(self._run_current)
        self.list.itemActivated.connect(lambda _i: self._run_current())
        self.list.itemDoubleClicked.connect(lambda _i: self._run_current())
        self._filter("")
        self.edit.setFocus()

    def _build(self) -> list[tuple[str, object]]:
        from ..mainwindow import PAGE_SPECS
        app, win = self.app, self.app.window
        t = app.t
        out: list[tuple[str, object]] = []
        for p in app.profiles:
            if isinstance(p, dict) and p.get("id"):
                out.append((t("Играть: {n}", n=p["name"]), lambda pid=p["id"]: win.launch_build(pid)))
        for key, ru, _m, _c in PAGE_SPECS:
            out.append((t("Открыть: {n}", n=t(ru)), lambda k=key: win.show_page(k)))
        cur = app.current_profile()
        if cur:
            out += [
                (f"{t('Проверка сборки')}: {cur['name']}", lambda: BuildCheckDialog(app, cur).exec()),
                (f"{t('Быстрый режим FPS')}: {cur['name']}", lambda: FpsDialog(app, cur).exec()),
                (f"{t('Шаблоны настроек')}: {cur['name']}", lambda: PresetsDialog(app, cur).exec()),
                (f"{t('Ярлык на рабочий стол')}: {cur['name']}", lambda: create_shortcut(app, cur)),
                (f"{t('Поделиться логом')}: {cur['name']}", lambda: share_log(app, cur, "log")),
            ]
        return out

    def _filter(self, text: str) -> None:
        q = text.strip().casefold()
        self.list.clear()
        for i, (title, _fn) in enumerate(self.entries):
            if not q or all(w in title.casefold() for w in q.split()):
                it = QListWidgetItem(title)
                it.setData(Qt.UserRole, i)
                self.list.addItem(it)
        if self.list.count():
            self.list.setCurrentRow(0)
        else:
            self.list.addItem(QListWidgetItem(self.app.t("Ничего не найдено")))
            self.list.item(0).setFlags(Qt.NoItemFlags)

    def _run_current(self) -> None:
        it = self.list.currentItem()
        idx = it.data(Qt.UserRole) if it is not None else None
        if idx is None:
            return
        fn = self.entries[int(idx)][1]
        self.accept()
        fn()

    def keyPressEvent(self, e):  # noqa: N802
        if e.key() in (Qt.Key_Down, Qt.Key_Up):
            self.list.setFocus()
            self.list.keyPressEvent(e)
            self.edit.setFocus()
            return
        super().keyPressEvent(e)


def open_palette(app) -> None:
    PaletteDialog(app).exec()
