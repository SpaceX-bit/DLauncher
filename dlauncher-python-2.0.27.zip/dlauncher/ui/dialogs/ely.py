"""Вход через Ely.by: логин/почта, пароль и (если включена двухфакторная защита) код."""
from __future__ import annotations

from PySide6.QtWidgets import QLabel, QLineEdit

from ..widgets import Modal


class ElyLoginDialog(Modal):
    def __init__(self, app, parent=None):
        super().__init__(app, "Вход через Ely.by", width=460, parent=parent)
        self.body.addWidget(QLabel(app.t("Логин или почта Ely.by:")))
        self.user = QLineEdit()
        self.user.setMaxLength(100)
        self.body.addWidget(self.user)
        self.body.addWidget(QLabel(app.t("Пароль:")))
        self.pw = QLineEdit()
        self.pw.setEchoMode(QLineEdit.Password)
        self.pw.setMaxLength(200)
        self.body.addWidget(self.pw)
        self.totp_lbl = QLabel(app.t("Код двухфакторной защиты:"))
        self.totp = QLineEdit()
        self.totp.setMaxLength(12)
        self.totp_lbl.hide()
        self.totp.hide()
        self.body.addWidget(self.totp_lbl)
        self.body.addWidget(self.totp)
        self.status = QLabel(app.t("Пароль нигде не сохраняется — лаунчер хранит только токен входа."))
        self.status.setWordWrap(True)
        self.status.setProperty("kind", "muted")
        self.body.addWidget(self.status)
        self.btn = self.add_button("Войти", "primary", self._go)
        self.add_button("Отмена", "ghost", self.reject)
        self.pw.returnPressed.connect(self._go)
        self.totp.returnPressed.connect(self._go)

    def _go(self) -> None:
        if not self.btn.isEnabled():
            return
        self.btn.setEnabled(False)
        self.status.setText(self.app.t("Вхожу..."))
        payload = {"username": self.user.text().strip(), "password": self.pw.text(), "totp": self.totp.text().strip()}

        def ok(r):
            self.btn.setEnabled(True)
            r = r if isinstance(r, dict) else {}
            if r.get("ok"):
                self.pw.clear()
                self.accept()
                return
            if r.get("needTotp"):
                self.totp_lbl.show()
                self.totp.show()
                self.totp.setFocus()
            self.status.setText(self.app.t(str(r.get("error") or "?")))

        def err(m):
            self.btn.setEnabled(True)
            self.status.setText(str(m))
        self.app.call("ely:login", payload, ok, err)
