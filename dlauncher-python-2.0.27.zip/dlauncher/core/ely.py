"""Вход через Ely.by (совместимый с Mojang сервер авторизации) и запуск игры с authlib-injector.
Пароль нигде не хранится: после входа сохраняется только токен доступа (в Windows — зашифрованный DPAPI)."""
from __future__ import annotations

import base64
import hashlib
import json
import os
import secrets
import threading
import urllib.parse

from . import util
from .msauth import dpapi_available, dpapi_decrypt, dpapi_encrypt

AUTH = "https://authserver.ely.by/auth"
INJECTOR_LATEST = "https://authlib-injector.yushi.moe/artifact/latest.json"
INJECTOR_FALLBACK = ("1.2.5", "https://github.com/yushijinhun/authlib-injector/releases/download/v1.2.5/authlib-injector-1.2.5.jar")
INJECTOR_HOSTS = ("authlib-injector.yushi.moe", "github.com", "bmclapi2.bangbang93.com", "objects.githubusercontent.com")
ERR_RU = {
    "Invalid credentials. Invalid email or password.": "Неверный логин или пароль (или неверный код двухфакторной защиты).",
    "Account protected with two factor auth.": "Нужен код из приложения двухфакторной защиты.",
    "Token expired.": "Сессия Ely.by истекла — войди заново.",
}


class Ely:
    def __init__(self, ctx, protect=None, unprotect=None):
        self.ctx = ctx
        self._lock = threading.RLock()
        if protect is None and dpapi_available():
            protect, unprotect = dpapi_encrypt, dpapi_decrypt
        self._protect, self._unprotect = protect, unprotect

    @property
    def file(self) -> str:
        return os.path.join(self.ctx.user_data, "ely.json")

    # ---------- хранение ----------
    def _read(self) -> dict | None:
        try:
            with open(self.file, encoding="utf-8") as f:
                rec = json.load(f)
            if rec.get("enc"):
                if not self._unprotect:
                    return None
                secret = self._unprotect(base64.b64decode(rec["enc"])).decode("utf-8")
            else:
                secret = rec.get("plain")
            tok = json.loads(secret)
            return {"id": rec["id"], "name": rec["name"], "clientToken": rec["clientToken"], "accessToken": tok["accessToken"]}
        except (OSError, ValueError, KeyError, TypeError):
            return None

    def _write(self, acc: dict) -> None:
        secret = json.dumps({"accessToken": acc["accessToken"]})
        rec = {"id": acc["id"], "name": acc["name"], "clientToken": acc["clientToken"]}
        sealed = False
        if self._protect:
            try:
                rec["enc"] = base64.b64encode(self._protect(secret.encode("utf-8"))).decode("ascii")
                sealed = True
            except Exception:  # noqa: BLE001
                pass
        if not sealed:
            rec["plain"] = secret
        os.makedirs(self.ctx.user_data, exist_ok=True)
        tmp = self.file + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(rec, f)
        try:
            os.chmod(tmp, 0o600)
        except OSError:
            pass
        os.replace(tmp, self.file)

    # ---------- запросы ----------
    @staticmethod
    def _error(r: dict) -> str:
        data = r.get("data") if isinstance(r.get("data"), dict) else {}
        msg = str(data.get("errorMessage") or data.get("error") or "")
        return ERR_RU.get(msg) or msg or "Ely.by не ответил"

    def login(self, arg=None) -> dict:
        arg = arg or {}
        user = str(arg.get("username") or "").strip()
        pw = str(arg.get("password") or "")
        code = str(arg.get("totp") or "").strip()
        if not user or not pw:
            return {"ok": False, "error": "Введи логин (или почту) и пароль Ely.by"}
        if len(user) > 100 or len(pw) > 200:
            return {"ok": False, "error": "Слишком длинные данные"}
        old = self._read()
        client = (old or {}).get("clientToken") or secrets.token_hex(16)
        try:
            r = util.post_json(f"{AUTH}/authenticate", {"username": user, "password": pw + (":" + code if code else ""),
                                                        "clientToken": client, "requestUser": True},
                               allow_error=True, timeout=20)
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": f"Не удалось связаться с Ely.by: {e}"}
        if not r.get("ok"):
            msg = str((r.get("data") or {}).get("errorMessage") or "") if isinstance(r.get("data"), dict) else ""
            if "two factor" in msg.lower():
                return {"ok": False, "needTotp": True, "error": ERR_RU["Account protected with two factor auth."]}
            return {"ok": False, "error": self._error(r)}
        d = r["data"]
        prof = d.get("selectedProfile") or (d.get("availableProfiles") or [None])[0]
        if not isinstance(prof, dict) or not prof.get("id") or not d.get("accessToken"):
            return {"ok": False, "error": "У этого аккаунта Ely.by нет игрового профиля"}
        with self._lock:
            self._write({"id": str(prof["id"]), "name": str(prof.get("name") or user), "clientToken": d.get("clientToken") or client,
                         "accessToken": str(d["accessToken"])})
        return {"ok": True, "name": str(prof.get("name") or user)}

    def status(self, _=None) -> dict:
        acc = self._read()
        return {"ok": True, "loggedIn": bool(acc), "name": acc["name"] if acc else None}

    def logout(self, _=None) -> dict:
        acc = self._read()
        if acc:
            try:
                util.post_json(f"{AUTH}/invalidate", {"accessToken": acc["accessToken"], "clientToken": acc["clientToken"]},
                               allow_error=True, timeout=8)
            except Exception:  # noqa: BLE001
                pass
        try:
            os.remove(self.file)
        except OSError:
            pass
        return {"ok": True}

    def get_launch_auth(self) -> dict:
        """Токен для запуска игры: проверяется, при необходимости обновляется. Бросает RuntimeError с понятным текстом."""
        acc = self._read()
        if not acc:
            raise RuntimeError("Войди через Ely.by в Настройках или переключись на другой режим входа.")
        tok = acc["accessToken"]
        try:
            ok = util.post_json(f"{AUTH}/validate", {"accessToken": tok}, allow_error=True, timeout=10).get("ok")
        except Exception:  # noqa: BLE001
            ok = True  # нет связи — пробуем с тем, что есть (в сети с Ely.by игра всё равно не зайдёт, а на офлайн-серверах зайдёт)
        if not ok:
            try:
                r = util.post_json(f"{AUTH}/refresh", {"accessToken": tok, "clientToken": acc["clientToken"]}, allow_error=True, timeout=15)
            except Exception as e:  # noqa: BLE001
                raise RuntimeError(f"Не удалось обновить сессию Ely.by: {e}") from None
            if not r.get("ok") or not (r.get("data") or {}).get("accessToken"):
                raise RuntimeError("Сессия Ely.by истекла — войди заново в Настройках.")
            tok = str(r["data"]["accessToken"])
            with self._lock:
                self._write({**acc, "accessToken": tok})
        return {"access_token": tok, "client_token": acc["clientToken"], "uuid": acc["id"], "name": acc["name"],
                "user_properties": "{}", "user_type": "mojang", "meta": {"type": "ely", "demo": False},
                "javaagent": "-javaagent:" + self.ensure_injector() + "=ely.by"}

    # ---------- authlib-injector ----------
    def injector_dir(self) -> str:
        return os.path.join(self.ctx.root, "runtime", "authlib-injector")

    def ensure_injector(self) -> str:
        """Путь к authlib-injector.jar (скачивается один раз). Без него Ely.by не узнает игру."""
        d = self.injector_dir()
        have = sorted(n for n in (os.listdir(d) if os.path.isdir(d) else []) if n.endswith(".jar"))
        if have:
            return os.path.join(d, have[-1])
        ver, url, sha = INJECTOR_FALLBACK[0], INJECTOR_FALLBACK[1], None
        try:
            meta = util.get_json(INJECTOR_LATEST, timeout=10)
            host = urllib.parse.urlparse(str(meta.get("download_url", ""))).hostname if isinstance(meta, dict) else None
            if host in INJECTOR_HOSTS and str(meta.get("download_url", "")).startswith("https://") and meta.get("version"):
                ver, url = str(meta["version"]), meta["download_url"]
                sha = (meta.get("checksums") or {}).get("sha256")
        except Exception:  # noqa: BLE001
            pass
        if not ver.replace(".", "").isdigit():
            ver, url = INJECTOR_FALLBACK[0], INJECTOR_FALLBACK[1]
        os.makedirs(d, exist_ok=True)
        dest = os.path.join(d, f"authlib-injector-{ver}.jar")
        util.download(url, dest)
        if sha:
            h = hashlib.sha256()
            with open(dest, "rb") as f:
                for chunk in iter(lambda: f.read(1 << 20), b""):
                    h.update(chunk)
            if h.hexdigest().lower() != str(sha).lower():
                os.remove(dest)
                raise RuntimeError("Не совпала контрольная сумма authlib-injector — попробуй позже")
        return dest


def setup(ctx) -> None:
    ctx.ely = Ely(ctx)


def handlers(ctx):
    e = ctx.ely
    return {"ely:login": e.login, "ely:status": e.status, "ely:logout": e.logout}
