"""Удобные штуки вокруг сборок: ярлык на рабочий стол, избранные моды, проверка сборки,
шаблоны настроек игры (options.txt), быстрый режим FPS, ссылка на лог.

Обработчики: shortcut:create, favs:list, favs:toggle, profile:check, optpresets:list/save/apply/delete,
fps:plan, fps:apply, log:share.
"""
from __future__ import annotations

import os
import re
import shutil
import sys
import time

from . import util
from .base import parse_jvm_args, suggest_ram, system_ram_gb

MCLOGS_URL = "https://api.mclo.gs/1/log"
MAX_FAVS = 300
MAX_PRESETS = 20
MAX_LOG = 9_000_000          # mclo.gs принимает до 10 МБ
FAV_KINDS = ("mod", "resourcepack", "shader", "modpack")

# Лёгкий набор JVM-аргументов для Java 17+ (G1, короткие паузы). Память задаётся отдельно.
FPS_JVM = ["-XX:+UseG1GC", "-XX:+ParallelRefProcEnabled", "-XX:MaxGCPauseMillis=100",
           "-XX:+DisableExplicitGC", "-XX:+PerfDisableSharedMem", "-XX:G1NewSizePercent=30",
           "-XX:G1MaxNewSizePercent=40", "-XX:G1HeapRegionSize=8M", "-XX:G1ReservePercent=20",
           "-XX:InitiatingHeapOccupancyPercent=15"]

# Настройки options.txt, которые снижают нагрузку. Меняем только ключи, которые уже есть в файле.
FPS_OPTIONS = {"renderDistance": "8", "simulationDistance": "8", "particles": "1", "entityShadows": "false",
               "ao": "false", "bobView": "false", "biomeBlendRadius": "1", "maxFps": "120",
               "enableVsync": "false", "entityDistanceScaling": "0.75", "mipmapLevels": "2"}

_BAD = re.compile(r'[\\/:*?"<>|\x00-\x1f]')


def safe_name(s, limit: int = 40) -> str:
    out = _BAD.sub("", str(s or "")).strip().strip(".")
    return out[:limit].strip()


# ---------------- ярлык ----------------
def _ps_quote(s: str) -> str:
    return "'" + str(s).replace("'", "''") + "'"


def launcher_command() -> tuple[str, str]:
    """(программа, начало аргументов) для запуска этого лаунчера."""
    if getattr(sys, "frozen", False):
        return sys.executable, ""
    main = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "main.py"))
    return sys.executable, f'"{main}" '


def run_ps(script: str) -> str:
    """Запуск PowerShell (отдельная функция — чтобы подменять в тестах)."""
    return util.run("powershell", ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", script], timeout=30)


def create_shortcut(profile: dict, icon_path: str | None = None) -> str:
    """Создаёт ярлык «запустить эту сборку». Возвращает путь к ярлыку."""
    exe, pre = launcher_command()
    args = f'{pre}--launch {profile["id"]}'.strip()
    title = safe_name(profile.get("name")) or "Minecraft"
    if sys.platform == "win32":
        script = (
            "$d=[Environment]::GetFolderPath('Desktop');"
            f"$p=Join-Path $d ({_ps_quote('DLauncher - ' + title + '.lnk')});"
            "$s=(New-Object -ComObject WScript.Shell).CreateShortcut($p);"
            f"$s.TargetPath={_ps_quote(exe)};$s.Arguments={_ps_quote(args)};"
            f"$s.WorkingDirectory={_ps_quote(os.path.dirname(exe))};"
            f"$s.Description={_ps_quote('Запустить ' + title)};"
            + (f"$s.IconLocation={_ps_quote(icon_path)};" if icon_path else f"$s.IconLocation={_ps_quote(exe)};")
            + "$s.Save();Write-Output $p"
        )
        out = run_ps(script).strip().splitlines()
        return out[-1].strip() if out else ""
    desk = os.path.join(os.path.expanduser("~"), "Desktop")
    os.makedirs(desk, exist_ok=True)
    p = os.path.join(desk, f"DLauncher - {title}.desktop")
    cmd = f'"{exe}" {args}'
    with open(p, "w", encoding="utf-8") as f:
        f.write(f"[Desktop Entry]\nType=Application\nName=DLauncher - {title}\nExec={cmd}\nTerminal=false\n")
    try:
        os.chmod(p, 0o755)
    except OSError:
        pass
    return p


# ---------------- options.txt ----------------
def read_options(path: str) -> list[str]:
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read().splitlines()
    except OSError:
        return []


def patch_options(lines: list[str], changes: dict) -> tuple[list[str], list[str]]:
    """Меняет значения только у существующих ключей. -> (новые строки, изменённые ключи)."""
    out, done = [], []
    for ln in lines:
        k, sep, _v = ln.partition(":")
        if sep and k in changes:
            out.append(f"{k}:{changes[k]}")
            done.append(k)
        else:
            out.append(ln)
    return out, done


# ---------------- проверка сборки ----------------
def build_report(ctx, p: dict) -> dict:
    from . import compat
    d = ctx.instance_dir(p["id"])
    r = compat.check_mods(p, os.path.join(d, "mods"), ctx.settings.get("lang", "ru"))
    items = list(r["problems"])
    en = ctx.settings.get("lang") == "en"
    loader = p.get("loader") or "vanilla"
    jars = [f for f in _listdir(os.path.join(d, "mods")) if f.lower().endswith((".jar", ".jar.disabled"))]
    if loader == "vanilla" and jars:
        items.insert(0, {"level": "error", "code": "vanilla", "file": None, "fixes": [],
                         "text": ("The profile is Vanilla, so mods in the mods folder will not load. Pick Fabric/Forge/NeoForge/Quilt."
                                  if en else "Сборка на Vanilla, поэтому моды из папки mods не загрузятся. Выбери Fabric, Forge, NeoForge или Quilt.")})
    packs = [f for f in _listdir(os.path.join(d, "resourcepacks")) if f.lower().endswith(".zip")]
    shaders = [f for f in _listdir(os.path.join(d, "shaderpacks"))]
    if shaders and not any("iris" in j.lower() or "optifine" in j.lower() or "oculus" in j.lower() for j in jars):
        items.append({"level": "info", "code": "shaders", "file": None, "fixes": [],
                      "text": ("Shader packs are installed but no Iris/OptiFine mod was found — shaders will not work."
                               if en else "Шейдеры лежат в папке, но Iris/OptiFine не найден — шейдеры не заработают.")})
    rank = {"error": 0, "warn": 1, "info": 2}
    items.sort(key=lambda x: rank.get(x.get("level"), 3))
    errors = sum(1 for x in items if x["level"] == "error")
    warns = sum(1 for x in items if x["level"] == "warn")
    return {"ok": True, "problems": items, "scanned": r["scanned"], "disabled": r["disabled"],
            "packs": len(packs), "shaders": len(shaders),
            "summary": {"errors": errors, "warnings": warns},
            "profile": {"id": p["id"], "name": p["name"], "version": p["version"], "loader": loader}}


def _listdir(d: str) -> list[str]:
    try:
        return sorted(os.listdir(d))
    except OSError:
        return []


# ---------------- лог ----------------
_USER_PATH = re.compile(r"(?i)([A-Z]:\\Users\\)[^\\/\r\n]+|(/home/|/Users/)[^/\r\n]+")


def clean_log(text: str) -> str:
    from . import gamelog
    t = gamelog.redact(text)
    t = _USER_PATH.sub(lambda m: (m.group(1) + "***") if m.group(1) else (m.group(2) + "***"), t)
    return t


def handlers(ctx):
    fav_file = os.path.join(ctx.user_data, "favorites.json")
    preset_dir = os.path.join(ctx.user_data, "option-presets")

    def profile_of(arg):
        pid = (arg or {}).get("profileId") if isinstance(arg, dict) else None
        return ctx.find_profile(pid or ctx.settings.get("currentProfile"))

    # --- ярлык
    def shortcut_create(arg=None):
        p = profile_of(arg)
        if not p:
            return {"ok": False, "error": "Профиль не найден"}
        try:
            path = create_shortcut(p)
            return {"ok": True, "path": path}
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": f"Не удалось создать ярлык: {e}"}

    # --- избранное
    def load_favs():
        d = util.read_json(fav_file, [])
        return [x for x in d if isinstance(x, dict) and x.get("id")] if isinstance(d, list) else []

    def favs_list(_=None):
        return {"ok": True, "items": load_favs()}

    def favs_toggle(arg=None):
        arg = arg or {}
        src = arg.get("source") if arg.get("source") in ("modrinth", "curseforge") else None
        pid = str(arg.get("id") or "")[:80]
        if not src or not pid:
            return {"ok": False, "error": "Неверный мод"}
        items = load_favs()
        hit = next((x for x in items if x.get("source") == src and str(x.get("id")) == pid), None)
        if hit:
            items.remove(hit)
            on = False
        else:
            if len(items) >= MAX_FAVS:
                return {"ok": False, "error": f"В избранном уже {MAX_FAVS} штук"}
            kind = arg.get("kind") if arg.get("kind") in FAV_KINDS else "mod"
            items.insert(0, {"source": src, "id": pid, "title": str(arg.get("title") or pid)[:80],
                             "icon": str(arg.get("icon") or "")[:300], "kind": kind,
                             "author": str(arg.get("author") or "")[:60], "added": int(time.time())})
            on = True
        util.write_json(fav_file, items)
        return {"ok": True, "on": on, "count": len(items)}

    # --- проверка сборки
    def profile_check(arg=None):
        p = profile_of(arg)
        if not p:
            return {"ok": False, "error": "Профиль не найден"}
        try:
            return build_report(ctx, p)
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": str(e)}

    # --- шаблоны настроек
    def preset_path(name):
        n = safe_name(name)
        return (n, os.path.join(preset_dir, n + ".txt")) if n else (None, None)

    def presets_list(_=None):
        out = []
        for f in _listdir(preset_dir):
            if f.endswith(".txt"):
                fp = os.path.join(preset_dir, f)
                try:
                    st = os.stat(fp)
                    out.append({"name": f[:-4], "size": st.st_size, "time": int(st.st_mtime * 1000),
                                "lines": len(read_options(fp))})
                except OSError:
                    pass
        out.sort(key=lambda x: x["name"].casefold())
        return {"ok": True, "items": out}

    def presets_save(arg=None):
        arg = arg or {}
        p = profile_of(arg)
        if not p:
            return {"ok": False, "error": "Профиль не найден"}
        n, dest = preset_path(arg.get("name"))
        if not n:
            return {"ok": False, "error": "Введи название шаблона"}
        src = os.path.join(ctx.instance_dir(p["id"]), "options.txt")
        if not os.path.isfile(src):
            return {"ok": False, "error": "У этой сборки ещё нет настроек: запусти игру один раз и выйди."}
        existing = [x["name"] for x in presets_list()["items"]]
        if n not in existing and len(existing) >= MAX_PRESETS:
            return {"ok": False, "error": f"Можно хранить до {MAX_PRESETS} шаблонов — удали ненужные."}
        os.makedirs(preset_dir, exist_ok=True)
        shutil.copyfile(src, dest)
        return {"ok": True, "name": n}

    def presets_apply(arg=None):
        arg = arg or {}
        p = profile_of(arg)
        if not p:
            return {"ok": False, "error": "Профиль не найден"}
        n, src = preset_path(arg.get("name"))
        if not n or not os.path.isfile(src):
            return {"ok": False, "error": "Шаблон не найден"}
        d = ctx.ensure_instance(p["id"])
        dest = os.path.join(d, "options.txt")
        if os.path.isfile(dest):
            shutil.copyfile(dest, dest + ".bak")
        shutil.copyfile(src, dest)
        return {"ok": True, "name": n}

    def presets_delete(arg=None):
        n, fp = preset_path((arg or {}).get("name") if isinstance(arg, dict) else arg)
        if not n or not os.path.isfile(fp):
            return {"ok": False, "error": "Шаблон не найден"}
        os.remove(fp)
        return {"ok": True}

    # --- быстрый FPS
    def fps_plan(arg=None):
        p = profile_of(arg)
        if not p:
            return {"ok": False, "error": "Профиль не найден"}
        total = system_ram_gb()
        gb, why = suggest_ram(total, ctx.count_mods(p["id"]), p.get("loader", "vanilla"), p.get("version", ""))
        opts = os.path.join(ctx.instance_dir(p["id"]), "options.txt")
        _new, keys = patch_options(read_options(opts), FPS_OPTIONS)
        return {"ok": True, "ram": gb, "ramReason": why, "jvm": " ".join(FPS_JVM),
                "options": keys, "canOptimize": (p.get("loader") or "vanilla") != "vanilla",
                "profile": {"id": p["id"], "name": p["name"], "loader": p.get("loader")}}

    def fps_apply(arg=None):
        arg = arg or {}
        p = profile_of(arg)
        if not p:
            return {"ok": False, "error": "Профиль не найден"}
        done = []
        with ctx.lock:
            if arg.get("jvm", True):
                old = parse_jvm_args(p.get("jvmArgs") or "")
                add = [a for a in FPS_JVM if a not in old]
                p["jvmArgs"] = " ".join(old + add)[:600]
                done.append("jvm")
            if arg.get("ram", True):
                gb, _why = suggest_ram(system_ram_gb(), ctx.count_mods(p["id"]), p.get("loader", "vanilla"), p.get("version", ""))
                p["ram"] = gb
                done.append("ram")
            ctx.save_settings()
        if arg.get("options", True):
            fp = os.path.join(ctx.instance_dir(p["id"]), "options.txt")
            lines = read_options(fp)
            new, keys = patch_options(lines, FPS_OPTIONS)
            if keys:
                shutil.copyfile(fp, fp + ".bak")
                with open(fp, "w", encoding="utf-8", newline="\n") as f:
                    f.write("\n".join(new) + "\n")
                done.append("options")
        return {"ok": True, "done": done, "profile": p}

    # --- ссылка на лог
    def log_share(arg=None):
        arg = arg or {}
        p = profile_of(arg)
        if not p:
            return {"ok": False, "error": "Профиль не найден"}
        from . import crash
        d = ctx.instance_dir(p["id"])
        which = arg.get("what")
        path = None
        if which == "crash":
            c = crash.latest_crash_report(d)
            path = c["file"] if c else None
        else:
            path = os.path.join(d, "logs", "latest.log")
        text = crash.tail_of(path, MAX_LOG) if path and os.path.isfile(path) else ""
        if not text.strip():
            return {"ok": False, "error": "Лог пуст: запусти игру, потом поделись логом." if which != "crash"
                    else "Отчётов о вылете нет."}
        text = clean_log(text)
        if arg.get("preview"):
            return {"ok": True, "chars": len(text), "lines": text.count("\n") + 1}
        try:
            r = util.post_json(MCLOGS_URL, {"content": text}, form=True, allow_error=True, timeout=30)
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": f"Нет связи с mclo.gs: {e}"}
        data = r.get("data") or {}
        if not r.get("ok") or not data.get("success") or not data.get("url"):
            return {"ok": False, "error": str(data.get("error") or "Сервис логов не принял файл")}
        return {"ok": True, "url": data["url"], "id": data.get("id")}

    return {"shortcut:create": shortcut_create, "favs:list": favs_list, "favs:toggle": favs_toggle,
            "profile:check": profile_check, "optpresets:list": presets_list, "optpresets:save": presets_save,
            "optpresets:apply": presets_apply, "optpresets:delete": presets_delete,
            "fps:plan": fps_plan, "fps:apply": fps_apply, "log:share": log_share}
