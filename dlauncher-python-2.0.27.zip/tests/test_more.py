"""Откат, дублирование, код сборки, обновление сборки, проверка перед запуском, брошенные файлы."""
import hashlib
import io
import json
import os
import zipfile

import pytest

from dlauncher.api import Api
from dlauncher.core import modpacks, profileio, rollback, util


def mk(ctx, name="P", **extra):
    p = ctx.create_profile({"name": name, "version": "1.20.1", "versionType": "release", "loader": "fabric", "loaderVersion": "0.15"})
    p.update(extra)
    return p


def put(ctx, p, rel, data=b"PK"):
    f = os.path.join(ctx.instance_dir(p["id"]), rel)
    os.makedirs(os.path.dirname(f), exist_ok=True)
    open(f, "wb").write(data)
    return f


def test_rollback_module(ctx):
    p = mk(ctx)
    a = put(ctx, p, "mods/a-1.jar", b"old")
    rollback.reset(ctx, p["id"])
    rollback.stash(ctx, p["id"], "mods/a-1.jar")
    put(ctx, p, "mods/a-2.jar", b"new")
    rollback.added(ctx, p["id"], "mods/a-2.jar")
    assert not os.path.exists(a) and rollback.count(ctx, p["id"]) == 2 and rollback.names(ctx, p["id"]) == ["a-1.jar"]
    r = rollback.restore(ctx, p["id"])
    assert r["ok"] and r["restored"] == 1 and r["removed"] == 1
    assert open(a, "rb").read() == b"old" and not os.path.exists(os.path.join(os.path.dirname(a), "a-2.jar"))
    assert rollback.restore(ctx, p["id"])["ok"] is False  # второй раз откатывать нечего
    with pytest.raises(ValueError):
        rollback.stash(ctx, p["id"], "../evil.jar")


def test_mod_update_can_be_rolled_back(ctx, monkeypatch):
    api = Api(ctx, modules=["base", "modsmgr"])
    p = mk(ctx)
    put(ctx, p, "mods/a-1.jar", b"old")
    monkeypatch.setattr(util, "download", lambda url, dest, prog=None: open(dest, "wb").write(b"new") and None)
    r = api.call("installed:update", {"profileId": p["id"], "file": "a-1.jar", "url": "https://cdn.modrinth.com/x/a-2.jar", "filename": "a-2.jar", "kind": "mod"})
    assert r["ok"]
    mods = os.path.join(ctx.instance_dir(p["id"]), "mods")
    assert sorted(os.listdir(mods)) == ["a-2.jar"]
    assert api.call("installed:rollback_info", {"profileId": p["id"]})["count"] == 2
    rb = api.call("installed:rollback", {"profileId": p["id"]})
    assert rb["ok"] and sorted(os.listdir(mods)) == ["a-1.jar"] and open(os.path.join(mods, "a-1.jar"), "rb").read() == b"old"
    assert api.call("installed:rollback", {"profileId": p["id"]})["ok"] is False
    assert api.call("installed:rollback", {"profileId": "nope"})["ok"] is False


def test_duplicate_profile(ctx):
    api = Api(ctx, modules=["base"])
    p = mk(ctx, "Мир", color="#5b6ee1", glyph="★", group="Выживание", ram=6, servers=[{"id": "s1", "name": "S", "host": "a.net", "port": 25565, "favorite": True}])
    put(ctx, p, "mods/a.jar")
    put(ctx, p, "saves/W/level.dat")
    put(ctx, p, "logs/latest.log")
    cur = ctx.settings["currentProfile"]
    r = api.call("profiles:duplicate", {"id": p["id"]})
    assert r["ok"]
    n = r["profile"]
    assert n["id"] != p["id"] and n["name"] == "Мир (копия)" and n["color"] == "#5b6ee1" and n["group"] == "Выживание" and n["ram"] == 6
    assert n["servers"][0]["host"] == "a.net" and n["servers"][0]["id"] != "s1"
    d = ctx.instance_dir(n["id"])
    assert os.path.isfile(os.path.join(d, "mods", "a.jar")) and not os.path.exists(os.path.join(d, "saves", "W"))
    assert not os.path.exists(os.path.join(d, "logs"))
    assert ctx.settings["currentProfile"] == cur  # выбранной остаётся прежняя
    r2 = api.call("profiles:duplicate", {"id": p["id"], "withWorlds": True})
    assert os.path.isfile(os.path.join(ctx.instance_dir(r2["profile"]["id"]), "saves", "W", "level.dat"))
    assert api.call("profiles:duplicate", {"id": "nope"})["ok"] is False


def test_build_code_roundtrip():
    h1, h2 = hashlib.sha1(b"a").hexdigest(), hashlib.sha1(b"b").hexdigest()
    code = profileio.make_code({"n": "Моя сборка", "m": "1.20.1", "l": "fabric", "v": "0.15"}, [[h1, h2], [], [h1]])
    assert code.startswith("DLC1-") and len(code) < 300
    head, groups = profileio.read_code("  " + code[:20] + "\n" + code[20:] + " ")  # пробелы и переносы не мешают
    assert head["n"] == "Моя сборка" and groups == [[h1, h2], [], [h1]]
    for bad in ("", "abc", "DLC1-", "DLC1-AAAA", code[:-6], "DLC2-" + code[5:]):
        with pytest.raises(ValueError):
            profileio.read_code(bad)
    known = {h1: {"url": "https://cdn.modrinth.com/data/x/versions/y/a.jar", "size": 1, "filename": "a.jar"}}
    idx, lost = profileio.index_from_code(head, groups, known)
    assert lost == 1 and [f["path"] for f in idx["files"]] == ["mods/a.jar", "shaderpacks/a.jar"]
    assert idx["dependencies"] == {"minecraft": "1.20.1", "fabric-loader": "0.15"}
    assert modpacks.parse_index(json.dumps(idx))[1:] == ("1.20.1", "fabric", "0.15")


def test_code_export_and_import(ctx, monkeypatch):
    api = Api(ctx, modules=["base", "profileio", "modpacks"])
    p = mk(ctx)
    put(ctx, p, "mods/a.jar", b"AAA")
    put(ctx, p, "mods/own.jar", b"OWN")
    ha = hashlib.sha1(b"AAA").hexdigest()
    monkeypatch.setattr(profileio, "lookup", lambda sh: {ha: {"url": "https://cdn.modrinth.com/data/x/a.jar", "size": 3, "filename": "a.jar"}} if ha in sh else {})
    r = api.call("profile:code", {"profileId": p["id"]})
    assert r["ok"] and r["linked"] == 1 and r["skipped"] == 1
    monkeypatch.setattr(util, "download", lambda url, dest, prog=None: (os.makedirs(os.path.dirname(dest), exist_ok=True), open(dest, "wb").write(b"AAA")) and None)
    n = api.call("profile:code_import", {"code": r["code"]})
    assert n["ok"] and n["missing"] == []
    assert os.path.isfile(os.path.join(ctx.instance_dir(n["profile"]["id"]), "mods", "a.jar"))
    assert n["profile"]["loader"] == "fabric" and n["profile"]["name"] == "P"
    assert api.call("profile:code_import", {"code": "мусор"})["ok"] is False
    empty = mk(ctx, "Empty")
    assert api.call("profile:code", {"profileId": empty["id"]})["ok"] is False


def make_mrpack(path, files, name="Pack", extra=None):
    idx = {"formatVersion": 1, "game": "minecraft", "name": name, "dependencies": {"minecraft": "1.20.4", "fabric-loader": "0.16"},
           "files": [{"path": p, "hashes": {"sha1": hashlib.sha1(d).hexdigest()}, "downloads": ["https://cdn.modrinth.com/data/" + p], "env": {"client": "required"}} for p, d in files.items()]}
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("modrinth.index.json", json.dumps(idx))
        for k, v in (extra or {}).items():
            z.writestr(k, v)


def test_update_pack_in_place(ctx, monkeypatch, tmp_path):
    p = mk(ctx, "Pack", pack={"source": "modrinth", "id": "abc", "version": "1", "versionId": "v1"}, packFiles=["mods/old.jar", "mods/keep.jar"])
    put(ctx, p, "mods/old.jar", b"old")
    put(ctx, p, "mods/keep.jar", b"keep1")
    put(ctx, p, "mods/mine.jar", b"mine")
    put(ctx, p, "options.txt", b"mine-options")
    put(ctx, p, "saves/W/level.dat", b"world")
    mr = str(tmp_path / "new.mrpack")
    make_mrpack(mr, {"mods/keep.jar": b"keep2", "mods/new.jar": b"new"}, extra={"overrides/options.txt": "pack-options", "overrides/config/x.toml": "x"})
    blobs = {"mods/keep.jar": b"keep2", "mods/new.jar": b"new"}

    def fake_dl(url, dest, prog=None):
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        key = url.split("/data/")[-1] if "/data/" in url else None
        open(dest, "wb").write(blobs[key] if key else open(mr, "rb").read())
    monkeypatch.setattr(util, "download", fake_dl)
    ver = {"id": "v2", "version_number": "2", "files": [{"primary": True, "url": "https://cdn.modrinth.com/pack.mrpack"}]}
    r = modpacks.update_pack(ctx, p, ver)
    d = ctx.instance_dir(p["id"])
    assert r["version"] == "2" and r["missing"] == []
    assert sorted(os.listdir(os.path.join(d, "mods"))) == ["keep.jar", "mine.jar", "new.jar"]  # old.jar убран, своё мод-файл цел
    assert open(os.path.join(d, "mods", "keep.jar"), "rb").read() == b"keep2"
    assert open(os.path.join(d, "options.txt"), "rb").read() == b"mine-options"  # свои настройки игрока сохранены
    assert os.path.isfile(os.path.join(d, "config", "x.toml")) and os.path.isfile(os.path.join(d, "saves", "W", "level.dat"))
    assert p["version"] == "1.20.4" and p["pack"]["versionId"] == "v2" and sorted(p["packFiles"]) == ["mods/keep.jar", "mods/new.jar"]
    rb = rollback.restore(ctx, p["id"])
    assert rb["ok"] and sorted(os.listdir(os.path.join(d, "mods"))) == ["keep.jar", "mine.jar", "old.jar"]
    assert open(os.path.join(d, "mods", "keep.jar"), "rb").read() == b"keep1"
    # сборка, поставленная старой версией лаунчера (нет packFiles), на месте не обновляется
    q = mk(ctx, "Old", pack={"source": "modrinth", "id": "abc", "version": "1"})
    with pytest.raises(ValueError):
        modpacks.update_pack(ctx, q, ver)


def test_pack_updates_check(ctx, monkeypatch):
    api = Api(ctx, modules=["base", "modpacks"])
    p = mk(ctx, "Pack", pack={"source": "modrinth", "id": "abcd1234", "version": "1.0", "versionId": "v1"}, packFiles=["mods/a.jar"])
    vs = [{"id": "v3", "version_number": "3.0", "version_type": "beta"}, {"id": "v2", "version_number": "2.0", "version_type": "release", "name": "Two"},
          {"id": "v1", "version_number": "1.0", "version_type": "release"}]
    monkeypatch.setattr(util, "get_json", lambda *a, **k: vs)
    r = api.call("pack:updates", {"profileId": p["id"]})
    assert r["ok"] and r["available"] and r["version"] == "2.0" and r["canUpdate"] is True
    p["pack"]["versionId"] = "v2"
    assert api.call("pack:updates", {"profileId": p["id"]})["available"] is False
    q = mk(ctx, "Own")
    assert api.call("pack:updates", {"profileId": q["id"]})["available"] is False
    assert api.call("pack:updates", {"profileId": "nope"})["ok"] is False


def test_preflight_and_drop(ctx, tmp_path):
    api = Api(ctx, modules=["base"])
    p = mk(ctx, javaPath="/nonexistent/java")
    r = api.call("launch:preflight", {"profileId": p["id"]})
    assert r["ok"] and any(w["key"] == "java" and w["level"] == "err" for w in r["warnings"])
    jar = tmp_path / "cool.jar"
    jar.write_bytes(b"PK")
    d = api.call("files:drop", {"profileId": p["id"], "path": str(jar)})
    assert d["ok"] and d["folder"] == "mods" and os.path.isfile(os.path.join(ctx.instance_dir(p["id"]), "mods", "cool.jar"))
    assert api.call("files:drop", {"profileId": p["id"], "path": str(jar)})["ok"] is False  # уже есть
    z = tmp_path / "pack.zip"
    z.write_bytes(b"PK")
    assert api.call("files:drop", {"profileId": p["id"], "path": str(z), "kind": "shader"})["folder"] == "shaderpacks"
    assert api.call("files:drop", {"profileId": p["id"], "path": str(z)})["folder"] == "resourcepacks"
    t = tmp_path / "a.txt"
    t.write_text("x")
    assert api.call("files:drop", {"profileId": p["id"], "path": str(t)})["ok"] is False
    assert api.call("files:drop", {"profileId": p["id"], "path": str(tmp_path / "none.jar")})["ok"] is False


def test_new_achievements_and_theme_settings(ctx, tmp_path):
    from dlauncher.core import achievements as A
    api = Api(ctx, modules=["base", "achievements"])
    assert {"builds_5", "clone", "undo", "code", "drop", "accent"} <= set(A.ORDER)
    for i in range(5):
        api.call("profiles:create", {"name": f"B{i}", "version": "1.20.1", "versionType": "release"})
    assert ctx.achievements.has("builds_5")
    assert api.call("achievements:grant", {"id": "accent"})["ok"]
    jar = tmp_path / "x.jar"
    jar.write_bytes(b"PK")
    api.call("files:drop", {"path": str(jar)})
    assert ctx.achievements.has("drop")
    s = api.call("settings:set", {"tone": "midnight", "accent": "#5b6ee1"})
    assert s["tone"] == "midnight" and s["accent"] == "#5b6ee1"
    s = api.call("settings:set", {"tone": "pink", "accent": "javascript:1"})
    assert s["tone"] == "dark" and s["accent"] == ""


def test_search_errors_and_fallbacks(ctx, monkeypatch):
    import urllib.error
    from dlauncher.core import mods
    api = Api(ctx, modules=["base", "mods"])
    calls = []

    def fake(url, *a, **k):
        calls.append(url)
        hits = [] if "versions%3A" in url or "versions:" in url else [{"project_id": "p1", "title": "Pack", "description": "d", "icon_url": None, "downloads": 5, "author": "me"}]
        return 200, {}, json.dumps({"total_hits": len(hits), "hits": hits}).encode()
    monkeypatch.setattr(util, "request", fake)
    r = api.call("mods:search", {"source": "modrinth", "kind": "resourcepack", "mc": "1.99.9", "query": ""})
    assert r["ok"] and len(r["items"]) == 1 and len(calls) == 2  # с версией пусто -> повтор без неё
    calls.clear()
    r = api.call("mods:search", {"source": "modrinth", "kind": "mod", "mc": "1.99.9", "loader": "fabric"})
    assert r["ok"] and r["items"] == [] and len(calls) == 1  # для модов этого повтора нет

    def boom(url, *a, **k):
        raise urllib.error.URLError("timed out")
    monkeypatch.setattr(util, "request", boom)
    r = api.call("mods:search", {"source": "modrinth", "kind": "resourcepack", "query": "x"})
    assert r["ok"] is False and "Modrinth" in r["error"] and "Повторить" in r["error"]


def test_icon_circuit_breaker(ctx, monkeypatch):
    from dlauncher.core import mods
    monkeypatch.setattr(mods, "_icon_state", {"fails": 0, "until": 0.0})
    n = {"c": 0}

    def bad(route):
        n["c"] += 1
        raise OSError("blocked")
    monkeypatch.setattr(mods, "_fetch_icon", bad)
    url = "https://cdn.modrinth.com/data/x/icon.png"
    for _ in range(4):
        assert mods.icon_get(ctx, url) is None
    asked = n["c"]
    assert asked == 8  # 4 иконки × 2 адреса, потом включилась пауза
    assert mods.icon_get(ctx, url) is None and n["c"] == asked  # пока пауза — в сеть не ходим


def test_loose_install_for_packs(ctx, monkeypatch, tmp_path):
    from dlauncher.core import mods
    seen = []

    def gj(url, *a, **k):
        seen.append(url)
        if "game_versions" in url:
            return []
        return [{"id": "v", "version_type": "release", "files": [{"primary": True, "filename": "Pack.zip", "url": "https://cdn.modrinth.com/p.zip"}], "dependencies": []}]
    monkeypatch.setattr(util, "get_json", gj)
    monkeypatch.setattr(util, "download", lambda u, d, prog=None: open(d, "wb").write(b"z") and None)
    with pytest.raises(mods.NoVersion):
        mods.install_modrinth("proj", "1.99", None, str(tmp_path), set())
    assert mods.install_modrinth("proj2", "1.99", None, str(tmp_path), set(), loose=True) == ["Pack.zip"]


def test_search_cache_fresh_and_offline(ctx, monkeypatch):
    import urllib.error
    from dlauncher.core import mods
    n = {"c": 0, "down": False}

    def fake(url, *a, **k):
        n["c"] += 1
        if n["down"]:
            raise urllib.error.URLError("no network")
        return 200, {}, json.dumps({"total_hits": 1, "hits": [{"project_id": "p", "title": "T"}]}).encode()
    monkeypatch.setattr(util, "request", fake)
    url = "https://api.modrinth.com/v2/search?limit=20&offset=0"
    d1, st1 = mods.cached_json(ctx, url)
    d2, st2 = mods.cached_json(ctx, url)  # свежий кэш — сети не нужно
    assert d1 == d2 and st1 is False and st2 is False and n["c"] == 1
    n["down"] = True
    d3, st3 = mods.cached_json(ctx, url, ttl=0)  # кэш устарел, сети нет — отдаём старый и говорим об этом
    assert d3 == d1 and st3 is True
    with pytest.raises(urllib.error.URLError):
        mods.cached_json(ctx, url + "&other=1")  # такого запроса в кэше не было — ошибка как обычно
    api = Api(ctx, modules=["base", "mods"])
    r = api.call("mods:search", {"source": "modrinth", "kind": "mod", "query": ""})
    assert r["ok"] is False  # без кэша и без сети
    n["down"] = False
    api.call("mods:search", {"source": "modrinth", "kind": "mod", "query": ""})
    n["down"] = True
    r = api.call("mods:search", {"source": "modrinth", "kind": "mod", "query": ""})
    assert r["ok"] and r["offline"] is False  # свежий кэш


# ---------------- 2.0.27: Ely.by, ярлык, избранное, шаблоны, FPS, лог, библиотека скинов ----------------
def ely_api(ctx, monkeypatch, responses):
    """Api с Ely.by; util.post_json отвечает по очереди из responses (по суффиксу URL)."""
    from dlauncher.core import ely
    calls = []

    def fake(url, body, headers=None, form=False, allow_error=False, timeout=0):
        calls.append((url, body))
        key = url.rsplit("/", 1)[-1]
        return responses[key]
    monkeypatch.setattr(util, "post_json", fake)
    return Api(ctx, modules=["base", "ely"]), calls, ely


def test_ely_login_status_logout(ctx, monkeypatch):
    api, calls, ely = ely_api(ctx, monkeypatch, {
        "authenticate": {"status": 200, "ok": True, "data": {"accessToken": "tok123", "clientToken": "c1",
                                                              "selectedProfile": {"id": "u" * 32, "name": "Steve"}}},
        "invalidate": {"status": 200, "ok": True, "data": None}})
    assert api.call("ely:status")["loggedIn"] is False
    assert api.call("ely:login", {"username": "", "password": ""})["ok"] is False
    r = api.call("ely:login", {"username": "me@x.ru", "password": "pw", "totp": "123456"})
    assert r == {"ok": True, "name": "Steve"}
    assert calls[0][1]["password"] == "pw:123456"  # код 2FA дописывается к паролю
    raw = open(os.path.join(ctx.user_data, "ely.json"), encoding="utf-8").read()
    assert "pw" not in json.loads(raw).get("plain", "") and '"password"' not in raw  # пароль не хранится
    st = api.call("ely:status")
    assert st["loggedIn"] and st["name"] == "Steve"
    assert api.call("ely:logout")["ok"] and api.call("ely:status")["loggedIn"] is False


def test_ely_needs_totp_and_bad_password(ctx, monkeypatch):
    api, _c, _e = ely_api(ctx, monkeypatch, {"authenticate": {"status": 401, "ok": False, "data": {
        "error": "ForbiddenOperationException", "errorMessage": "Account protected with two factor auth."}}})
    r = api.call("ely:login", {"username": "a", "password": "b"})
    assert r["ok"] is False and r["needTotp"] is True
    api2, _c2, _e2 = ely_api(ctx, monkeypatch, {"authenticate": {"status": 401, "ok": False, "data": {
        "errorMessage": "Invalid credentials. Invalid email or password."}}})
    r = api2.call("ely:login", {"username": "a", "password": "b"})
    assert r["ok"] is False and "Неверный логин" in r["error"] and not r.get("needTotp")


def test_ely_launch_auth_refresh_and_injector(ctx, monkeypatch):
    api, calls, ely = ely_api(ctx, monkeypatch, {
        "authenticate": {"status": 200, "ok": True, "data": {"accessToken": "old", "clientToken": "c1",
                                                              "selectedProfile": {"id": "a" * 32, "name": "Alex"}}},
        "validate": {"status": 403, "ok": False, "data": None},
        "refresh": {"status": 200, "ok": True, "data": {"accessToken": "new", "clientToken": "c1"}}})
    api.call("ely:login", {"username": "a", "password": "b"})
    monkeypatch.setattr(ctx.ely, "ensure_injector", lambda: "/x/authlib-injector-1.2.5.jar")
    a = ctx.ely.get_launch_auth()
    assert a["access_token"] == "new" and a["name"] == "Alex" and a["user_type"] == "mojang"
    assert a["javaagent"] == "-javaagent:/x/authlib-injector-1.2.5.jar=ely.by"
    assert ctx.ely._read()["accessToken"] == "new"  # обновлённый токен сохранён


def test_ely_launch_without_login(ctx):
    api = Api(ctx, modules=["base", "ely"])
    with pytest.raises(RuntimeError):
        ctx.ely.get_launch_auth()


def test_ely_injector_download_and_checksum(ctx, monkeypatch):
    api = Api(ctx, modules=["base", "ely"])
    good = b"JARDATA"
    monkeypatch.setattr(util, "get_json", lambda url, **k: {"version": "1.2.6", "download_url": "https://authlib-injector.yushi.moe/x.jar",
                                                           "checksums": {"sha256": hashlib.sha256(good).hexdigest()}})
    seen = []
    monkeypatch.setattr(util, "download", lambda url, dest, prog=None: (seen.append(url), open(dest, "wb").write(good)))
    p = ctx.ely.ensure_injector()
    assert p.endswith("authlib-injector-1.2.6.jar") and open(p, "rb").read() == good
    assert ctx.ely.ensure_injector() == p and len(seen) == 1  # второй раз не качает
    os.remove(p)
    monkeypatch.setattr(util, "get_json", lambda url, **k: {"version": "1.2.7", "download_url": "https://authlib-injector.yushi.moe/x.jar",
                                                           "checksums": {"sha256": "0" * 64}})
    with pytest.raises(RuntimeError):
        ctx.ely.ensure_injector()
    assert not os.path.exists(os.path.join(ctx.ely.injector_dir(), "authlib-injector-1.2.7.jar"))
    # чужой хост в ответе не используется — берётся запасная ссылка GitHub
    seen.clear()
    monkeypatch.setattr(util, "get_json", lambda url, **k: {"version": "9.9", "download_url": "https://evil.example/x.jar"})
    ctx.ely.ensure_injector()
    assert seen[0].startswith("https://github.com/")


def test_launch_uses_ely_agent(ctx, monkeypatch):
    from dlauncher.core import launch
    src = open(launch.__file__, encoding="utf-8").read()
    assert 'accountMode' in src and '"ely"' in src and 'javaagent' in src


def tools_api(ctx):
    return Api(ctx, modules=["base", "tools"])


def test_shortcut_create(ctx, monkeypatch, tmp_path):
    from dlauncher.core import tools
    api = tools_api(ctx)
    p = mk(ctx, "Моя / сборка")
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(os.path, "expanduser", lambda s: s.replace("~", str(tmp_path)))
    r = api.call("shortcut:create", {"profileId": p["id"]})
    assert r["ok"], r
    txt = open(r["path"], encoding="utf-8").read()
    assert f"--launch {p['id']}" in txt and "/" not in os.path.basename(r["path"])
    assert api.call("shortcut:create", {"profileId": "nope"})["ok"] is False
    assert tools.safe_name('a<b>:"c"/d\\e?') == "abcde"


def test_favorites(ctx):
    api = tools_api(ctx)
    assert api.call("favs:list")["items"] == []
    r = api.call("favs:toggle", {"source": "modrinth", "id": "sodium", "title": "Sodium", "kind": "mod", "icon": "https://x/i.png"})
    assert r["ok"] and r["on"] and r["count"] == 1
    assert api.call("favs:list")["items"][0]["title"] == "Sodium"
    assert api.call("favs:toggle", {"source": "bad", "id": "x"})["ok"] is False
    r = api.call("favs:toggle", {"source": "modrinth", "id": "sodium"})
    assert r["ok"] and r["on"] is False and api.call("favs:list")["items"] == []


def test_option_presets(ctx):
    api = tools_api(ctx)
    a, b = mk(ctx, "A"), mk(ctx, "B")
    assert api.call("optpresets:save", {"profileId": a["id"], "name": "x"})["ok"] is False  # у сборки ещё нет options.txt
    put(ctx, a, "options.txt", b"renderDistance:12\nparticles:0\n")
    assert api.call("optpresets:save", {"profileId": a["id"], "name": ""})["ok"] is False
    assert api.call("optpresets:save", {"profileId": a["id"], "name": "../Мой"})["name"] == "Мой"  # имя очищается
    assert [x["name"] for x in api.call("optpresets:list")["items"]] == ["Мой"]
    put(ctx, b, "options.txt", b"renderDistance:4\n")
    assert api.call("optpresets:apply", {"profileId": b["id"], "name": "Мой"})["ok"]
    d = ctx.instance_dir(b["id"])
    assert open(os.path.join(d, "options.txt")).read().startswith("renderDistance:12")
    assert open(os.path.join(d, "options.txt.bak")).read() == "renderDistance:4\n"
    assert api.call("optpresets:apply", {"profileId": b["id"], "name": "нет"})["ok"] is False
    assert api.call("optpresets:delete", {"name": "Мой"})["ok"] and api.call("optpresets:list")["items"] == []
    for i in range(20):
        assert api.call("optpresets:save", {"profileId": a["id"], "name": f"n{i}"})["ok"]
    assert api.call("optpresets:save", {"profileId": a["id"], "name": "лишний"})["ok"] is False  # лимит 20


def test_fps_plan_and_apply(ctx):
    from dlauncher.core import tools
    api = tools_api(ctx)
    p = mk(ctx, "F", jvmArgs="-XX:+UseG1GC -Dmine=1")
    put(ctx, p, "options.txt", b"renderDistance:16\nparticles:0\nfoo:bar\nao:true\n")
    plan = api.call("fps:plan", {"profileId": p["id"]})
    assert plan["ok"] and plan["canOptimize"] and set(plan["options"]) == {"renderDistance", "particles", "ao"}
    r = api.call("fps:apply", {"profileId": p["id"]})
    assert r["ok"] and set(r["done"]) == {"jvm", "ram", "options"}
    prof = ctx.find_profile(p["id"])
    assert prof["jvmArgs"].count("-XX:+UseG1GC") == 1 and "-Dmine=1" in prof["jvmArgs"] and prof["ram"]
    assert "-Xmx" not in prof["jvmArgs"] and len(prof["jvmArgs"]) <= 600
    opts = open(os.path.join(ctx.instance_dir(p["id"]), "options.txt")).read()
    assert "renderDistance:8" in opts and "foo:bar" in opts and "ao:false" in opts
    assert os.path.exists(os.path.join(ctx.instance_dir(p["id"]), "options.txt.bak"))
    assert api.call("fps:apply", {"profileId": "no"})["ok"] is False
    v = mk(ctx, "V", loader="vanilla")
    assert api.call("fps:plan", {"profileId": v["id"]})["canOptimize"] is False


def test_profile_check_report(ctx):
    api = Api(ctx, modules=["base", "compat", "tools"])
    p = mk(ctx, "C", loader="vanilla")
    put(ctx, p, "mods/a.jar", b"PK")
    r = api.call("profile:check", {"profileId": p["id"]})
    assert r["ok"] and r["problems"][0]["code"] == "vanilla" and r["summary"]["errors"] >= 1
    put(ctx, p, "shaderpacks/s.zip", b"PK")
    r = api.call("profile:check", {"profileId": p["id"]})
    assert any(x["code"] == "shaders" for x in r["problems"]) and r["shaders"] == 1
    assert api.call("profile:check", {"profileId": "no"})["ok"] is False


def test_log_share(ctx, monkeypatch):
    api = Api(ctx, modules=["base", "crash", "tools"])
    p = mk(ctx, "L")
    assert api.call("log:share", {"profileId": p["id"]})["ok"] is False  # лога нет
    secret = "Bearer " + "A" * 40
    put(ctx, p, "logs/latest.log", (f"[main] user C:\\Users\\Vasya\\x token {secret}\n/home/vasya/.minecraft\n").encode())
    sent = {}

    def fake(url, body, headers=None, form=False, allow_error=False, timeout=0):
        sent.update(url=url, body=body, form=form)
        return {"status": 200, "ok": True, "data": {"success": True, "url": "https://mclo.gs/abc", "id": "abc"}}
    monkeypatch.setattr(util, "post_json", fake)
    pre = api.call("log:share", {"profileId": p["id"], "preview": True})
    assert pre["ok"] and not sent  # предпросмотр ничего не отправляет
    r = api.call("log:share", {"profileId": p["id"]})
    assert r == {"ok": True, "url": "https://mclo.gs/abc", "id": "abc"}
    body = sent["body"]["content"]
    assert sent["form"] and "AAAA" not in body and "Vasya" not in body and "vasya" not in body
    monkeypatch.setattr(util, "post_json", lambda *a, **k: {"status": 400, "ok": False, "data": {"success": False, "error": "Too big"}})
    assert api.call("log:share", {"profileId": p["id"]}) == {"ok": False, "error": "Too big"}
    assert api.call("log:share", {"profileId": p["id"], "what": "crash"})["ok"] is False  # отчётов о вылете нет


def png(w=64, h=64):
    import struct
    return b"\x89PNG\r\n\x1a\n" + struct.pack(">I", 13) + b"IHDR" + struct.pack(">II", w, h) + b"\x08\x06\x00\x00\x00" + b"\0" * 8


def test_skin_library(ctx, monkeypatch, tmp_path):
    api = Api(ctx, modules=["base", "skins"])
    assert api.call("skinlib:list")["items"] == []
    assert api.call("skinlib:add", {})["ok"] is False  # нечего добавлять: файл не выбран
    f = tmp_path / "my.png"
    f.write_bytes(png())
    ctx.ui.open_file = lambda *a, **k: str(f)
    assert api.call("skins:choose")["ok"]
    r = api.call("skinlib:add", {"name": "Герой.png", "variant": "slim"})
    assert r["ok"] and r["items"][0]["name"] == "Герой" and r["items"][0]["variant"] == "slim"
    assert os.path.isfile(r["items"][0]["image"])
    assert api.call("skinlib:add", {})["error"].startswith("Этот скин уже")
    api.call("skins:discard")
    u = api.call("skinlib:use", {"id": r["items"][0]["id"]})
    assert u["ok"] and u["name"] == "Герой" and u["variant"] == "slim"
    assert api.call("skinlib:use", {"id": "zzz"})["ok"] is False
    assert api.call("skinlib:remove", {"id": r["items"][0]["id"]})["items"] == []
    assert api.call("skinlib:remove", {"id": "zzz"})["ok"] is False


def test_skins_message_for_ely(ctx):
    api = Api(ctx, modules=["base", "skins"])
    ctx.settings["accountMode"] = "ely"
    r = api.call("skins:get")
    assert r["ok"] is False and "ely.by" in r["error"]


def test_tools_module_registered():
    from dlauncher.api import MODULES
    assert "tools" in MODULES and "ely" in MODULES and MODULES.index("ely") < MODULES.index("launch")
