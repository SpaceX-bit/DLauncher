"""Дымовые тесты страниц: Qt подменён (fakeqt), ядро — настоящее. Ловит опечатки, NameError, неверные формы данных."""
import importlib
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(__file__))
import fakeqt  # noqa: E402

fakeqt.install()
from fakeapp import FakeApp  # noqa: E402

PAGES = [("play", "PlayPage"), ("profiles", "ProfilesPage"), ("mods", "ModsPage"), ("installed", "InstalledPage"),
         ("worlds", "WorldsPage"), ("skins", "SkinsPage"), ("settings", "SettingsPage")]


class RealApp(FakeApp):
    """FakeApp, у которого call() идёт в настоящее ядро (Api)."""

    def __init__(self, api, **kw):
        super().__init__(**kw)
        self.api = api
        self.ctx = api.ctx
        self.settings.update(api.ctx.public_settings())

    def call(self, channel, payload=None, on_ok=None, on_err=None):
        self.calls.append((channel, payload))
        try:
            res = self.api.call(channel, payload)
        except Exception as e:  # noqa: BLE001
            self.errors = getattr(self, "errors", []) + [(channel, repr(e))]
            if on_err:
                on_err(str(e))
            return
        if on_ok:
            on_ok(res)


@pytest.fixture
def app(ctx, monkeypatch):
    from dlauncher.api import Api
    from dlauncher.core import util

    def offline(url, *a, **k):
        raise util.HttpError(0, url, reason="offline in tests")
    monkeypatch.setattr(util, "request", offline)
    api = Api(ctx)
    ctx.create_profile({"name": "Test", "version": "1.20.1", "loader": "vanilla"})
    a = RealApp(api)
    a.profiles = [dict(p, modsCount=0) for p in ctx.settings["profiles"]]
    a.current_id = ctx.settings["currentProfile"]
    ctx.on_settings_changed = None
    return a


@pytest.mark.parametrize("mod,cls", PAGES)
def test_page_builds_and_cycles(app, mod, cls):
    m = importlib.import_module(f"dlauncher.ui.pages.{mod}")
    page = getattr(m, cls)(app)
    for fn in ("on_show", "retranslate", "selftest"):
        f = getattr(page, fn, None)
        if callable(f):
            f()
    real = [e for e in getattr(app, "errors", []) if "offline in tests" not in e[1]]
    assert not real, real


def test_settings_save_roundtrip(app):
    from dlauncher.ui.pages import settings as st
    f = {"accountMode": "microsoft", "nickname": "  Abcdefghijklmnopqrstu ", "msClientId": " id ", "ram": 5.3,
         "javaPath": "", "lang": "en", "glass": False, "glassStrength": 30, "bgDim": 20, "closeToTray": True,
         "autoStart": False, "compatCheck": True, "autoBackup": True, "backupKeep": 3, "discordRpc": True,
         "discordClientId": "12ab34", "autoUpdate": True, "updateUrl": "", "curseforgeKey": "k", "rootDir": "/x"}
    p = st.build_patch(f, 16)
    assert p["nickname"] == "Abcdefghijklmnop" and p["ram"] == 5.5 and p["discordClientId"] == "1234"
    s = app.api.call("settings:set", p)
    assert s["accountMode"] == "microsoft" and s["lang"] == "en" and s["glass"] is False and s["closeToTray"] is True
    assert st.clamp_ram(99, 8) == 8 and st.clamp_ram(0, 8) == 1
    assert st.fmt_gb(4.0) == "4" and st.fmt_gb(4.5) == "4.5"


def test_update_and_discord_text(app):
    from dlauncher.ui.pages import settings as st
    assert "1.8" in st.update_text(app, {"state": "ready", "version": "1.8"})
    assert st.update_text(app, {"state": "downloading", "percent": 40}).endswith("40%")
    assert st.update_text(app, {}) == ""
    assert "user1" in st.discord_text(app, {"state": "ready", "user": "user1"})
    assert st.discord_text(app, None) == ""


def test_importer_dialog(app):
    from dlauncher.ui.dialogs import importer
    d = importer.ImportDialog(app)
    d._scanned({"ok": True, "candidates": [
        {"id": "a", "name": "A", "launcher": "TLauncher", "version": "1.16.5", "loader": "forge", "modsCount": 2,
         "worldsCount": 1, "imported": False, "options": [{"id": "o1", "version": "1.16.5", "loader": "forge",
                                                         "loaderVersion": "36"}, {"id": "o2", "version": "1.16.5"}],
         "defaultOption": "o1"}]})
    assert len(d.rows) == 1
    assert importer.option_label({"version": "1.20", "loader": "fabric", "loaderVersion": "0.15"}) == "1.20 · fabric 0.15"


def test_skin_geometry():
    from dlauncher.ui.pages.skins import skin_parts
    for legacy in (False, True):
        for slim in (False, True):
            for back in (False, True):
                for p in skin_parts(legacy, slim, back):
                    x, y, w, h = p["src"]
                    assert x + w <= 64 and y + h <= (32 if legacy else 64)
                    dx, dy, dw, dh = p["dst"]
                    assert 0 <= dx and dx + dw <= 16 and dy + dh <= 32


def test_buildcard_helpers(app):
    from dlauncher.ui import buildcard as bc
    assert bc.initials("Pixel mon") == "PM" and bc.initials("ATM10") == "AT" and bc.initials("") == "?"
    assert bc.tile_color("x") == bc.tile_color("x") and bc.tile_color("x").startswith("#")
    ps = [{"id": "a"}, {"id": "b", "lastPlayed": 5}, {"id": "c", "lastPlayed": 9}]
    assert [p["id"] for p in bc.recent_first(ps)] == ["c", "b", "a"]
    c = bc.BuildCard(app, {"id": "a", "name": "A", "version": "1.20.1", "loader": "forge", "modsCount": 3}, selected=True)
    assert c.pid == "a"
