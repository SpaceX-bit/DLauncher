import os, pytest
from dlauncher.api import Api
from dlauncher.core import util
from dlauncher.core.base import parse_jvm_args


def test_settings_roundtrip_and_clamp(ctx):
    api = Api(ctx, modules=["base"])
    s = api.call("settings:set", {"ram": 9999, "lang": "xx", "bgDim": 500, "glassStrength": -4, "backupKeep": 0, "nickname": "Steve", "hack": 1})
    assert s["ram"] == s["systemRamGb"] and s["lang"] == "ru" and s["bgDim"] == 80 and s["glassStrength"] == 0
    assert s["backupKeep"] == 5 and s["nickname"] == "Steve" and "hack" not in s and "profiles" not in s
    from dlauncher.core.ctx import Ctx
    c2 = Ctx(user_data=ctx.user_data)
    assert c2.settings["nickname"] == "Steve"


def test_profiles_crud(ctx, srv):
    srv.map_host("https://launchermeta.mojang.com", "")
    srv.route("GET", "/mc/game/version_manifest_v2.json", json={"latest": {"release": "1.21"}, "versions": [{"id": "1.21", "type": "release", "releaseTime": "x"}]})
    api = Api(ctx, modules=["base"])
    r = api.call("profiles:create", {"version": "1.21", "name": "Мой / профиль", "loader": "fabric", "loaderVersion": "0.15"})
    assert r["ok"] and r["profile"]["loader"] == "fabric" and r["profile"]["versionType"] == "release"
    pid = r["profile"]["id"]
    assert os.path.isdir(os.path.join(ctx.root, "instances", pid, "mods"))
    assert api.call("profiles:create", {})["ok"] is False
    assert api.call("profiles:update", {"id": pid, "patch": {"width": 800}})["ok"] is False
    assert api.call("profiles:update", {"id": pid, "patch": {"width": 800, "height": 600, "jvmArgs": "-XX:+UseG1GC"}})["ok"]
    assert api.call("profiles:update", {"id": pid, "patch": {"jvmArgs": "-Xmx2G"}})["ok"] is False
    assert api.call("profiles:update", {"id": pid, "patch": {"name": " "}})["ok"] is False
    lst = api.call("profiles:list")
    assert lst["current"] == pid and lst["profiles"][0]["modsCount"] == 0
    d = api.call("profiles:delete", {"id": pid})
    assert d["ok"] and d["current"] is None and not os.path.exists(os.path.join(ctx.root, "instances", pid))
    assert api.call("versions:list")["latest"]["release"] == "1.21"


def test_jvm_args():
    assert parse_jvm_args('"-Dfoo=a b" -XX:+X') == ["-Dfoo=a b", "-XX:+X"]
    with pytest.raises(ValueError):
        parse_jvm_args("foo")


def test_http_download(srv, tmp_path):
    srv.route("GET", "/f", body=b"x" * 500000)
    seen = []
    util.download(srv.base + "/f", str(tmp_path / "a" / "f.bin"), seen.append)
    assert os.path.getsize(tmp_path / "a" / "f.bin") == 500000 and seen[-1] == 100
    srv.route("GET", "/e", status=404, body=b"{}")
    with pytest.raises(util.HttpError):
        util.get_json(srv.base + "/e")
    assert util.safe_join(str(tmp_path), "a/b").startswith(str(tmp_path))
    with pytest.raises(ValueError):
        util.safe_join(str(tmp_path), "../x")
