"""Карточка сборки (профиля) для списков: цветная плитка с буквами, название, версия, моды, время игры."""
from __future__ import annotations

import zlib

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QPushButton, QVBoxLayout

from . import i18n
from .pages._profile_util import fmt_date, loader_name

i18n.register({
    "Выбрать": "Select",
    "Играть": "Play",
    "Выбрана": "Selected",
    "модов: {n}": "mods: {n}",
    "Не запускалась": "Never played",
})

TILE_COLORS = ["#5b6ee1", "#c2557a", "#3f9d78", "#c98a2b", "#8b5cc2", "#2f8fb5", "#b5533c", "#6a8f3a"]


def initials(name: str) -> str:
    """Две буквы для плитки: первые буквы слов или первые два символа."""
    words = [w for w in str(name or "").replace("_", " ").replace("-", " ").split() if w]
    if len(words) >= 2:
        return (words[0][0] + words[1][0]).upper()
    s = words[0] if words else "?"
    return s[:2].upper()


def tile_color(name: str) -> str:
    return TILE_COLORS[zlib.crc32(str(name or "").encode("utf-8")) % len(TILE_COLORS)]


class BuildCard(QFrame):
    """Клик по карточке — выбрать; кнопка справа — выбрать или (если уже выбрана) играть."""
    chosen = Signal(str)
    play = Signal(str)

    def __init__(self, app, profile: dict, selected: bool = False, compact: bool = False):
        super().__init__()
        self.app = app
        self.pid = profile["id"]
        self.selected = selected
        self.setProperty("kind", "buildsel" if selected else "build")
        self.setCursor(Qt.PointingHandCursor)
        row = QHBoxLayout(self)
        row.setContentsMargins(12, 10, 12, 10)
        row.setSpacing(12)
        tile = QLabel(initials(profile.get("name")))
        tile.setAlignment(Qt.AlignCenter)
        size = 40 if compact else 48
        tile.setFixedSize(size, size)
        tile.setStyleSheet(f"background: {tile_color(profile.get('name'))}; color: #fff; border-radius: 10px;"
                           "font-weight: 800; font-size: 15px; border: none;")
        row.addWidget(tile)
        col = QVBoxLayout()
        col.setSpacing(1)
        name = QLabel(str(profile.get("name") or ""))
        name.setStyleSheet("font-weight: 700; font-size: 14px; background: transparent; border: none;")
        col.addWidget(name)
        ver = QLabel(f"{profile.get('version', '')} · {loader_name(profile.get('loader', 'vanilla'))}")
        ver.setProperty("kind", "muted")
        col.addWidget(ver)
        last = fmt_date(app, profile.get("lastPlayed")) if profile.get("lastPlayed") else app.t("Не запускалась")
        meta = QLabel(f"{app.t('модов: {n}', n=profile.get('modsCount', 0))} · {last}")
        meta.setProperty("kind", "muted")
        meta.setStyleSheet("font-size: 11px;")
        col.addWidget(meta)
        row.addLayout(col, 1)
        self.btn = QPushButton(app.t("Играть") if selected else app.t("Выбрать"))
        self.btn.setProperty("kind", "primary" if selected else "ghost")
        self.btn.setCursor(Qt.PointingHandCursor)
        self.btn.clicked.connect(lambda _=False: self.play.emit(self.pid) if self.selected else self.chosen.emit(self.pid))
        row.addWidget(self.btn)

    def mousePressEvent(self, e):  # noqa: N802
        if e.button() == Qt.LeftButton and not self.selected:
            self.chosen.emit(self.pid)
        super().mousePressEvent(e)


def recent_first(profiles: list[dict]) -> list[dict]:
    """Недавно игравшие — сверху, потом остальные в исходном порядке."""
    played = sorted((p for p in profiles if p.get("lastPlayed")), key=lambda p: p["lastPlayed"], reverse=True)
    rest = [p for p in profiles if not p.get("lastPlayed")]
    return played + rest
