"""Экспорт профиля в .mrpack (формат Modrinth, его понимают Modrinth App, Prism и другие) и импорт из .mrpack.

Моды, которые есть на Modrinth, попадают в сборку ссылками; остальные файлы кладутся внутрь архива.
Порт lib/profileio.js + lib/zipwrite.js. Обработчики: profile:export, profile:import. События: profile:progress.
"""
from __future__ import annotations

import json
import os
import re
import threading

from . import modpacks, util
from .mods import MR_BASE
from .ziputil import ZipWriter, walk_files

MAX_IMPORT = 1024 * 1024 * 1024
LISTED = [
    ("mods", re.compile(r"\.jar$", re.I)),
    ("resourcepacks", re.compile(r"\.zip$", re.I)),
    ("shaderpacks", re.compile(r"\.zip$", re.I)),
]
LOADER_KEY = {"fabric": "fabric-loader", "quilt": "quilt-loader", "neoforge": "neoforge", "forge": "forge"}
FILTERS = [("Modrinth modpack", ["mrpack"])]
_lock = threading.Lock()


def safe_name(s) -> str:
    out = re.sub(r"[\\/:*?\"<>|\x00-\x1f]", "_", str(s or ""))
    out = re.sub(r"\s+", " ", out).strip()[:60]
    return out or "profile"


def lookup(sha1s: list[str]) -> dict:
    """Какие из файлов есть на Modrinth: sha1 -> {url, size}."""
    out: dict = {}
    if not sha1s:
        return out
    try:
        data = util.post_json(f"{MR_BASE}/version_files", {"hashes": sha1s, "algorithm": "sha1"})["data"] or {}
        for h, v in data.items():
            f = next((x for x in ((v or {}).get("files") or []) if (x.get("hashes") or {}).get("sha1") == h), None)
            if f and f.get("url") and str(f["url"]).startswith("https://cdn.modrinth.com/"):
                out[h] = {"url": f["url"], "size": f.get("size")}
    except Exception:  # noqa: BLE001
        pass  # нет сети: все файлы упакуем внутрь
    return out


def _state(ctx) -> dict:
    with _lock:
        st = getattr(ctx, "_profileio_state", None)
        if st is None:
            st = {"working": False}
            ctx._profileio_state = st
        return st


def _take(ctx) -> bool:
    st = _state(ctx)
    with _lock:
        if st["working"]:
            return False
        st["working"] = True
        return True


def _free(ctx) -> None:
    st = _state(ctx)
    with _lock:
        st["working"] = False


def export_profile(ctx, profile_id=None) -> dict:
    progress = lambda text: ctx.send("profile:progress", {"text": text})  # noqa: E731
    if _state(ctx)["working"]:
        return {"ok": False, "error": "Другая операция с профилем ещё идёт"}
    p = ctx.find_profile(profile_id or ctx.settings.get("currentProfile"))
    if not p:
        return {"ok": False, "error": "Профиль не найден"}
    dep_key = LOADER_KEY.get(p.get("loader"))
    if p.get("loader") != "vanilla" and (not dep_key or not p.get("loaderVersion")):
        return {"ok": False, "error": "У профиля не указана версия загрузчика"}

    path = ctx.ui.save_file(ctx.t("Экспорт профиля", "Export profile"), f"{safe_name(p.get('name'))}.mrpack", FILTERS)
    if not path:
        return {"ok": False, "canceled": True}
    dest = path if path.lower().endswith(".mrpack") else path + ".mrpack"

    if not _take(ctx):
        return {"ok": False, "error": "Другая операция с профилем ещё идёт"}
    base = ctx.instance_dir(p["id"])
    zw = None
    try:
        progress("Считаю контрольные суммы...")
        local = []
        for d, rx in LISTED:
            try:
                names = sorted(os.listdir(os.path.join(base, d)), key=lambda s: (s.lower(), s))
            except OSError:
                continue
            for name in names:
                absf = os.path.join(base, d, name)
                if not rx.search(name) or not os.path.isfile(absf):
                    continue
                local.append({"rel": f"{d}/{name}", "abs": absf, "sha1": util.sha1_file(absf)})

        progress("Ищу файлы на Modrinth...")
        known = lookup(list(dict.fromkeys(f["sha1"] for f in local)))
        files, bundled = [], []
        for f in local:
            k = known.get(f["sha1"])
            if not k:
                bundled.append(f)
                continue
            files.append({
                "path": f["rel"],
                "hashes": {"sha1": f["sha1"], "sha512": util.sha512_file(f["abs"])},
                "env": {"client": "required", "server": "required"},
                "downloads": [k["url"]],
                "fileSize": os.path.getsize(f["abs"]),
            })

        deps = {"minecraft": p["version"]}
        if dep_key:
            deps[dep_key] = p["loaderVersion"]
        index = {"formatVersion": 1, "game": "minecraft", "versionId": "1.0.0", "name": p.get("name"),
                 "summary": "Exported from DLauncher", "files": files, "dependencies": deps}

        progress("Собираю архив...")
        zw = ZipWriter(dest)
        zw.add_bytes("modrinth.index.json", json.dumps(index, indent=2, ensure_ascii=False))
        for f in bundled:
            zw.add_file(f"overrides/{f['rel']}", f["abs"])
        # настройки: config, options.txt, servers.dat (миры и логи не берём)
        for rel, absf in walk_files(os.path.join(base, "config")):
            zw.add_file(f"overrides/config/{rel}", absf)
        for one in ("options.txt", "servers.dat"):
            absf = os.path.join(base, one)
            if os.path.isfile(absf):
                zw.add_file(f"overrides/{one}", absf)
        zw.finish()
        zw = None
        return {"ok": True, "file": dest, "linked": len(files), "bundled": len(bundled), "size": os.path.getsize(dest)}
    except Exception as e:  # noqa: BLE001
        if zw:
            zw.abort()
        return {"ok": False, "error": str(e)}
    finally:
        _free(ctx)


def import_profile(ctx) -> dict:
    if _state(ctx)["working"]:
        return {"ok": False, "error": "Другая операция с профилем ещё идёт"}
    file = ctx.ui.open_file(ctx.t("Импорт профиля", "Import profile"), FILTERS)
    if isinstance(file, (list, tuple)):
        file = file[0] if file else None
    if not file:
        return {"ok": False, "canceled": True}
    if not _take(ctx):
        return {"ok": False, "error": "Другая операция с профилем ещё идёт"}
    try:
        if not file.lower().endswith(".mrpack"):
            raise ValueError("Нужен файл .mrpack")
        if os.path.getsize(file) > MAX_IMPORT:
            raise ValueError("Файл больше 1 ГБ — такой архив не поддерживается")
        title = re.sub(r"\.mrpack$", "", os.path.basename(file), flags=re.I)
        r = modpacks.import_mrpack(ctx, file, title)
        return {"ok": True, "profile": r["profile"], "missing": r["missing"]}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": str(e)}
    finally:
        _free(ctx)


def handlers(ctx):
    return {
        "profile:export": lambda arg=None: export_profile(ctx, (arg or {}).get("profileId")),
        "profile:import": lambda arg=None: import_profile(ctx),
    }
