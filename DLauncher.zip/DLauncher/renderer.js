const $ = (id) => document.getElementById(id);
const api = window.api;

const NAMES = { vanilla: 'Vanilla', fabric: 'Fabric', forge: 'Forge', quilt: 'Quilt' };
const KIND_LABEL = { mod: 'Моды', resourcepack: 'Ресурспаки', shader: 'Шейдеры' };

let manifest = null;
let loaders = [];
let modSource = 'modrinth';
let modKind = 'mod';

const esc = (s) =>
  String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

// ---------- Тема ----------
function applyTheme(theme) {
  document.documentElement.dataset.theme = theme === 'light' ? 'light' : 'dark';
}

// ---------- Окно ----------
$('btn-min').onclick = () => api.invoke('win:minimize');
$('btn-close').onclick = () => api.invoke('win:close');

// ---------- Навигация ----------
function showView(name) {
  document.querySelectorAll('.nav-btn').forEach((x) => x.classList.toggle('active', x.dataset.view === name));
  document.querySelectorAll('.view').forEach((v) => v.classList.toggle('active', v.id === 'view-' + name));
  if (name === 'mods') {
    refreshModsInfo();
    if (!$('mods-list').children.length) searchMods();
  }
}
document.querySelectorAll('.nav-btn').forEach((b) => { b.onclick = () => showView(b.dataset.view); });

// Секрет: 5 нажатий подряд (пауза не дольше 3 секунд) на «О разработчике»
let aboutClicks = 0;
let aboutTimer = null;
$('btn-about').addEventListener('click', () => {
  showView('about');
  aboutClicks++;
  clearTimeout(aboutTimer);
  aboutTimer = setTimeout(() => { aboutClicks = 0; }, 3000);
  if (aboutClicks >= 5) {
    aboutClicks = 0;
    showSecret();
  }
});

// Картинка сама исчезает через 3 секунды
let secretTimer = null;
function showSecret() {
  clearTimeout(secretTimer);
  $('secret-modal').classList.remove('hidden');
  secretTimer = setTimeout(hideSecret, 3000);
}
function hideSecret() {
  clearTimeout(secretTimer);
  $('secret-modal').classList.add('hidden');
}
$('secret-modal').onclick = hideSecret;
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    hideSecret();
    $('opt-modal').classList.add('hidden');
  }
});

// ---------- Версии ----------
const TYPE_LABEL = { release: 'релиз', snapshot: 'снапшот', old_beta: 'бета', old_alpha: 'альфа' };

function renderVersions() {
  const filter = $('type-filter').value;
  const list = manifest.versions.filter((v) => filter === 'all' || v.type === filter);
  const prev = $('version-select').value;
  $('version-select').innerHTML = list
    .map((v) => `<option value="${v.id}" data-type="${v.type}">${v.id}${filter === 'all' ? ' · ' + TYPE_LABEL[v.type] : ''}</option>`)
    .join('');
  if (list.some((v) => v.id === prev)) $('version-select').value = prev;
  loadLoaders();
}

async function loadLoaders() {
  const mc = $('version-select').value;
  if (!mc) return;
  $('loader-select').innerHTML = '<option>Загрузка...</option>';
  try {
    loaders = await api.invoke('loaders:list', mc);
  } catch {
    loaders = [{ loader: 'vanilla', versions: ['—'] }];
  }
  if ($('version-select').value !== mc) return; // пользователь уже выбрал другую версию
  $('loader-select').innerHTML = loaders
    .map((l) => `<option value="${l.loader}">${NAMES[l.loader]}</option>`)
    .join('');
  renderLoaderVersions();
  refreshModsInfo();
}

function renderLoaderVersions() {
  const cur = loaders.find((l) => l.loader === $('loader-select').value);
  const sel = $('loader-version');
  if (!cur || cur.loader === 'vanilla') {
    sel.classList.add('hidden');
    sel.innerHTML = '';
  } else {
    sel.classList.remove('hidden');
    sel.innerHTML = cur.versions.map((v) => `<option>${v}</option>`).join('');
  }
}

$('type-filter').onchange = renderVersions;
$('version-select').onchange = loadLoaders;
$('loader-select').onchange = () => { renderLoaderVersions(); refreshModsInfo(); };

// ---------- Запуск ----------
$('btn-play').onclick = async () => {
  const opt = $('version-select').selectedOptions[0];
  if (!opt) return;
  $('btn-play').disabled = true;
  $('status').textContent = 'Запуск...';
  const res = await api.invoke('game:launch', {
    version: opt.value,
    type: opt.dataset.type,
    loader: $('loader-select').value,
    loaderVersion: $('loader-version').value,
  });
  if (!res.ok) {
    $('status').textContent = 'Ошибка: ' + res.error;
    $('progress').classList.add('hidden');
    $('btn-play').disabled = false;
  }
};

api.on('game:status', (t) => { $('status').textContent = t; });
api.on('game:progress', (p) => {
  $('progress').classList.remove('hidden');
  const pct = p.total ? Math.min(100, Math.round((p.task / p.total) * 100)) : 0;
  $('progress-bar').style.width = pct + '%';
  $('status').textContent = `${p.label || 'Загрузка'}: ${pct}%`;
});
api.on('game:closed', (code) => {
  $('status').textContent = code === 0 ? 'Игра закрыта' : `Игра завершилась с кодом ${code}`;
  $('progress').classList.add('hidden');
  $('btn-play').disabled = false;
});
api.on('game:log', (m) => {
  if (m.includes('Launching with arguments') || m.includes('Setting user')) {
    $('status').textContent = 'Игра запущена';
    $('progress').classList.add('hidden');
  }
});

// ---------- Папки ----------
$('btn-root').onclick = () => api.invoke('folder:open', 'root');
$('btn-modsdir').onclick = () => api.invoke('folder:open', 'mods');

// ---------- Моды / ресурспаки / шейдеры ----------
function refreshModsInfo() {
  const mc = $('version-select').value;
  const loader = $('loader-select').value;
  let text;
  if (modKind === 'mod') {
    text =
      loader === 'vanilla'
        ? `Версия ${mc}: выбран Vanilla. Для установки модов выбери Fabric / Forge / Quilt внизу.`
        : `Моды для Minecraft ${mc} · ${NAMES[loader] || loader}`;
  } else if (modKind === 'shader') {
    text = `Шейдеры для Minecraft ${mc}. Для работы нужен мод Iris (Fabric/Quilt) или Oculus (Forge) — найди его во вкладке «Моды».`;
  } else {
    text = `Ресурспаки для Minecraft ${mc}`;
  }
  $('mods-info').textContent = text;
}

function setKind(kind) {
  modKind = kind;
  document.querySelectorAll('#kind-seg .seg-btn').forEach((x) => x.classList.toggle('active', x.dataset.kind === kind));
  $('mod-query').placeholder = `Поиск: ${KIND_LABEL[kind].toLowerCase()}...`;
  refreshModsInfo();
  searchMods();
}

document.querySelectorAll('#kind-seg .seg-btn').forEach((b) => { b.onclick = () => setKind(b.dataset.kind); });
document.querySelectorAll('#source-seg .seg-btn').forEach((b) => {
  b.onclick = () => {
    modSource = b.dataset.source;
    document.querySelectorAll('#source-seg .seg-btn').forEach((x) => x.classList.toggle('active', x === b));
    searchMods();
  };
});
$('mod-search').onclick = () => searchMods();
$('mod-query').onkeydown = (e) => { if (e.key === 'Enter') searchMods(); };

// Иконки грузит сам лаунчер (кэш на диске, запасной путь) — ВПН не нужен
const iconQueue = [];
let iconActive = 0;
function loadIcon(url, el) {
  iconQueue.push({ url, el });
  pumpIcons();
}
function pumpIcons() {
  while (iconActive < 6 && iconQueue.length) {
    const { url, el } = iconQueue.shift();
    iconActive++;
    api.invoke('icon:get', url)
      .then((data) => {
        if (data && el.isConnected) {
          const img = document.createElement('img');
          img.alt = '';
          img.src = data;
          el.replaceWith(img);
        }
      })
      .catch(() => {})
      .finally(() => { iconActive--; pumpIcons(); });
  }
}

let modOffset = 0;
let searchSeq = 0;

async function searchMods(append = false) {
  const list = $('mods-list');
  const seq = ++searchSeq;
  if (!append) {
    iconQueue.length = 0;
    modOffset = 0;
    list.innerHTML = '<p class="muted">Ищу...</p>';
  } else if ($('mods-more')) {
    $('mods-more').disabled = true;
    $('mods-more').textContent = 'Загрузка...';
  }

  const res = await api.invoke('mods:search', {
    source: modSource,
    query: $('mod-query').value.trim(),
    mc: $('version-select').value,
    loader: $('loader-select').value,
    kind: modKind,
    offset: modOffset,
  });
  if (seq !== searchSeq) return; // пришёл устаревший ответ
  if ($('mods-more')) $('mods-more').remove();

  if (!res.ok) {
    if (append) $('mods-info').textContent = res.error;
    else list.innerHTML = `<p class="muted">${esc(res.error)}</p>`;
    return;
  }
  if (!append) list.innerHTML = '';
  if (!res.items.length && !append) { list.innerHTML = '<p class="muted">Ничего не найдено</p>'; return; }

  res.items.forEach((m) => {
    const card = document.createElement('div');
    card.className = 'mod-card';
    card.innerHTML = `
      <div class="ph">${esc((m.title || '?').trim().charAt(0).toUpperCase())}</div>
      <div class="info">
        <div class="name">${esc(m.title)}</div>
        <div class="desc">${esc(m.description)}</div>
        <div class="meta">${esc(m.author || '')} · ⬇ ${Number(m.downloads || 0).toLocaleString('ru-RU')}</div>
      </div>
      <button class="btn">Скачать</button>`;
    if (m.icon) loadIcon(m.icon, card.querySelector('.ph'));
    const btn = card.querySelector('button');
    btn.onclick = async () => {
      btn.disabled = true;
      btn.textContent = '...';
      const r = await api.invoke('mods:install', {
        source: modSource,
        id: m.id,
        mc: $('version-select').value,
        loader: $('loader-select').value,
        kind: modKind,
      });
      btn.textContent = r.ok ? 'Готово' : 'Ошибка';
      if (!r.ok) {
        $('mods-info').textContent = r.error;
        btn.disabled = false;
      } else {
        $('mods-info').textContent =
          `Установлено: ${r.filename}` + (r.extra ? ` (+${r.extra} необходимых зависимостей)` : '');
      }
    };
    list.appendChild(card);
  });

  modOffset += res.items.length;
  if (res.total && modOffset < res.total) {
    const more = document.createElement('button');
    more.id = 'mods-more';
    more.className = 'btn ghost mods-more';
    more.textContent = `Показать ещё (осталось ${(res.total - modOffset).toLocaleString('ru-RU')})`;
    more.onclick = () => searchMods(true);
    list.appendChild(more);
  }
}

// ---------- Оптимизация ----------
const OPT_ICON = { loading: '⏳', ok: '✅', skip: '➖', fail: '❌' };

async function openOpt() {
  const mc = $('version-select').value;
  const loader = $('loader-select').value;
  $('opt-modal').classList.remove('hidden');
  $('opt-sub').textContent = `Minecraft ${mc} · ${NAMES[loader] || loader}`;
  $('opt-msg').textContent = '';
  $('opt-go').textContent = 'Установить всё';

  const list = await api.invoke('opt:list', loader);
  if (!list.length) {
    $('opt-list').innerHTML =
      '<p class="muted">Для Vanilla оптимизация модами недоступна. Выбери Fabric, Forge или Quilt рядом с кнопкой «ИГРАТЬ».</p>';
    $('opt-go').disabled = true;
    return;
  }
  $('opt-list').innerHTML = list
    .map(
      (m) => `<div class="opt-row">
        <span class="opt-state" id="opt-${m.slug}">•</span>
        <div><b>${esc(m.name)}</b> <span class="src" id="optsrc-${m.slug}"></span><div class="muted">${esc(m.desc)}</div></div>
      </div>`
    )
    .join('');
  $('opt-go').disabled = false;
}

$('btn-opt').onclick = openOpt;
$('opt-close').onclick = () => $('opt-modal').classList.add('hidden');
$('opt-modal').onclick = (e) => { if (e.target === $('opt-modal')) $('opt-modal').classList.add('hidden'); };

$('opt-go').onclick = async () => {
  $('opt-go').disabled = true;
  $('opt-msg').textContent = 'Скачиваю...';
  const r = await api.invoke('opt:install', {
    mc: $('version-select').value,
    loader: $('loader-select').value,
  });
  if (!r.ok) {
    $('opt-msg').textContent = r.error;
  } else {
    $('opt-msg').textContent =
      `Готово: установлено ${r.installed} (Modrinth: ${r.bySource.modrinth}, CurseForge: ${r.bySource.curseforge})` +
      (r.skipped ? `, недоступно для этой версии: ${r.skipped}` : '') +
      (r.failed ? `, ошибок: ${r.failed}` : '') +
      (r.needKey && r.skipped ? '. Чтобы искать и на CurseForge, добавь API-ключ в Настройках.' : '');
  }
  $('opt-go').textContent = 'Повторить';
  $('opt-go').disabled = false;
};

api.on('opt:progress', ({ slug, status, detail, source }) => {
  const el = $('opt-' + slug);
  if (!el) return;
  el.textContent = OPT_ICON[status] || '•';
  el.title = detail || '';
  const src = $('optsrc-' + slug);
  if (src) src.textContent = source ? '· ' + source : '';
});

// ---------- Настройки ----------
let ramMax = 16;

function setRamUi(value) {
  const v = Math.min(Math.max(Number(value) || 4, 1), ramMax);
  $('set-ram').value = v;
  $('ram-val').textContent = v;
  document.querySelectorAll('#ram-chips .chip').forEach((c) =>
    c.classList.toggle('active', Number(c.dataset.ram) === v)
  );
}

async function loadSettings() {
  const s = await api.invoke('settings:get');
  ramMax = s.systemRamGb || 16;
  $('set-ram').max = ramMax;
  $('ram-hint').textContent =
    `Всего в системе: ${ramMax} ГБ. Для Vanilla хватит 2–4 ГБ, для модов обычно 4–8 ГБ. ` +
    `Не выделяй больше, чем половину памяти компьютера.`;
  setRamUi(s.ram);
  $('set-nick').value = s.nickname;
  $('set-cf').value = s.curseforgeKey;
  $('set-root').value = s.rootDir;
  $('set-java').value = s.javaPath || '';
  $('set-theme').value = s.theme || 'dark';
  applyTheme(s.theme);
}

$('set-ram').oninput = () => setRamUi($('set-ram').value);
document.querySelectorAll('#ram-chips .chip').forEach((c) => {
  c.onclick = () => setRamUi(c.dataset.ram);
});

// Тема применяется и сохраняется сразу
$('set-theme').onchange = async () => {
  applyTheme($('set-theme').value);
  await api.invoke('settings:set', { theme: $('set-theme').value });
};

$('set-save').onclick = async () => {
  await api.invoke('settings:set', {
    nickname: $('set-nick').value.trim() || 'Player',
    ram: Number($('set-ram').value),
    curseforgeKey: $('set-cf').value.trim(),
    rootDir: $('set-root').value.trim(),
    javaPath: $('set-java').value.trim(),
    theme: $('set-theme').value,
  });
  $('set-msg').textContent = 'Сохранено ✓';
  setTimeout(() => ($('set-msg').textContent = ''), 2000);
};

// «Предметы для Minecraft»: папки и переходы к скачиванию
document.querySelectorAll('[data-folder]').forEach((b) => {
  b.onclick = () => api.invoke('folder:open', b.dataset.folder);
});
document.querySelectorAll('[data-goto]').forEach((b) => {
  b.onclick = () => {
    showView('mods');
    setKind(b.dataset.goto);
  };
});

// ---------- Старт ----------
(async function init() {
  await loadSettings();
  try {
    manifest = await api.invoke('versions:list');
    renderVersions();
    $('version-select').value = manifest.latest.release;
    loadLoaders();
  } catch (e) {
    $('status').textContent = 'Не удалось загрузить список версий: проверь интернет';
  }
})();
