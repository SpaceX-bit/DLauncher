const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { once } = require('events');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { Client, Authenticator } = require('minecraft-launcher-core');

const UA = 'DLauncher/1.0 (personal project)';
const MANIFEST_URL = 'https://launchermeta.mojang.com/mc/game/version_manifest_v2.json';
let win;
let manifestCache = null;

// ---------- Настройки ----------
const settingsFile = () => path.join(app.getPath('userData'), 'settings.json');
const defaults = {
  nickname: 'Player',
  ram: 4,
  rootDir: path.join(os.homedir(), '.dlauncher'),
  curseforgeKey: '',
  javaPath: '', // пусто = Java скачивается автоматически
  theme: 'dark', // dark | light
};
let settings = { ...defaults };

function loadSettings() {
  try {
    settings = { ...defaults, ...JSON.parse(fs.readFileSync(settingsFile(), 'utf8')) };
  } catch {
    settings = { ...defaults };
  }
}
function saveSettings() {
  fs.mkdirSync(path.dirname(settingsFile()), { recursive: true });
  fs.writeFileSync(settingsFile(), JSON.stringify(settings, null, 2));
}
const modsDir = () => path.join(settings.rootDir, 'mods');
const systemRamGb = () => Math.max(2, Math.floor(os.totalmem() / 1024 ** 3));

// ---------- Утилиты ----------
async function getJSON(url, headers = {}) {
  const res = await fetch(url, { headers: { 'User-Agent': UA, ...headers } });
  if (!res.ok) throw new Error(`${res.status} ${res.statusText} — ${url}`);
  return res.json();
}

// Скачивание файла потоком, с процентами
async function download(url, dest, onProgress) {
  const res = await fetch(url, { headers: { 'User-Agent': UA }, redirect: 'follow' });
  if (!res.ok) throw new Error(`Не удалось скачать (${res.status}): ${url}`);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  const total = Number(res.headers.get('content-length')) || 0;
  const tmp = dest + '.part';
  const out = fs.createWriteStream(tmp);
  const reader = res.body.getReader();
  let got = 0;
  let last = -1;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      if (!out.write(value)) await once(out, 'drain');
      got += value.length;
      if (onProgress && total) {
        const p = Math.floor((got / total) * 100);
        if (p !== last) { last = p; onProgress(p); }
      }
    }
  } catch (err) {
    out.destroy();
    fs.rmSync(tmp, { force: true });
    throw err;
  }
  await new Promise((resolve, reject) => out.end((err) => (err ? reject(err) : resolve())));
  fs.renameSync(tmp, dest);
}

const run = (cmd, args) =>
  new Promise((resolve, reject) =>
    execFile(cmd, args, { maxBuffer: 1024 * 1024 * 50 }, (err, stdout, stderr) =>
      err ? reject(new Error(stderr || err.message)) : resolve(stdout)
    )
  );

function send(channel, payload) {
  if (win && !win.isDestroyed()) win.webContents.send(channel, payload);
}

// ---------- Окно ----------
function createWindow() {
  win = new BrowserWindow({
    width: 1280,
    height: 720,
    minWidth: 1100,
    minHeight: 620,
    frame: false,
    backgroundColor: '#0b0b14',
    icon: path.join(__dirname, 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  win.setMenuBarVisibility(false);
  win.loadFile('index.html');
}

app.whenReady().then(() => {
  loadSettings();
  fs.mkdirSync(settings.rootDir, { recursive: true });
  createWindow();
});
app.on('window-all-closed', () => app.quit());

ipcMain.handle('win:minimize', () => win.minimize());
ipcMain.handle('win:close', () => win.close());

// ---------- Настройки ----------
ipcMain.handle('settings:get', () => ({ ...settings, systemRamGb: systemRamGb() }));
ipcMain.handle('settings:set', (_e, patch) => {
  const next = { ...settings, ...patch };
  next.ram = Math.min(Math.max(Number(next.ram) || 4, 1), systemRamGb());
  next.theme = next.theme === 'light' ? 'light' : 'dark';
  settings = next;
  saveSettings();
  fs.mkdirSync(settings.rootDir, { recursive: true });
  return { ...settings, systemRamGb: systemRamGb() };
});

// ---------- Папки ----------
const FOLDERS = {
  root: '',
  mods: 'mods',
  resourcepacks: 'resourcepacks',
  shaderpacks: 'shaderpacks',
  saves: 'saves',
  screenshots: 'screenshots',
};
ipcMain.handle('folder:open', async (_e, which) => {
  const sub = Object.prototype.hasOwnProperty.call(FOLDERS, which) ? FOLDERS[which] : '';
  const dir = path.join(settings.rootDir, sub);
  fs.mkdirSync(dir, { recursive: true });
  await shell.openPath(dir);
});

// ---------- Версии Minecraft (релизы, снапшоты, бета, альфа) ----------
async function getManifest() {
  if (!manifestCache) manifestCache = await getJSON(MANIFEST_URL);
  return manifestCache;
}

ipcMain.handle('versions:list', async () => {
  const m = await getManifest();
  return {
    latest: m.latest,
    versions: m.versions.map((v) => ({ id: v.id, type: v.type, releaseTime: v.releaseTime })),
  };
});

// ---------- Загрузчики для выбранной версии ----------
ipcMain.handle('loaders:list', async (_e, mc) => {
  const result = [{ loader: 'vanilla', versions: ['—'] }];

  const [fabric, quilt, forge] = await Promise.allSettled([
    getJSON(`https://meta.fabricmc.net/v2/versions/loader/${encodeURIComponent(mc)}`),
    getJSON(`https://meta.quiltmc.org/v3/versions/loader/${encodeURIComponent(mc)}`),
    getJSON('https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json'),
  ]);

  if (fabric.status === 'fulfilled' && Array.isArray(fabric.value) && fabric.value.length) {
    result.push({ loader: 'fabric', versions: fabric.value.map((x) => x.loader.version) });
  }
  if (quilt.status === 'fulfilled' && Array.isArray(quilt.value) && quilt.value.length) {
    result.push({ loader: 'quilt', versions: quilt.value.map((x) => x.loader.version) });
  }
  if (forge.status === 'fulfilled') {
    const promos = forge.value.promos || {};
    const list = [];
    if (promos[`${mc}-recommended`]) list.push(promos[`${mc}-recommended`]);
    if (promos[`${mc}-latest`] && !list.includes(promos[`${mc}-latest`])) list.push(promos[`${mc}-latest`]);
    if (list.length) result.push({ loader: 'forge', versions: list });
  }
  return result;
});

// ---------- Java: автоматическая загрузка (Eclipse Temurin / Adoptium) ----------
async function requiredJava(version) {
  try {
    const m = await getManifest();
    const entry = m.versions.find((v) => v.id === version);
    if (!entry) return 17;
    const meta = await getJSON(entry.url);
    const major = (meta.javaVersion && meta.javaVersion.majorVersion) || 8;
    if (major <= 8) return 8;
    if (major <= 17) return 17; // 16 у Adoptium уже нет, 17 подходит
    if (major <= 21) return 21;
    return major;
  } catch {
    return 17;
  }
}

function findJavaBin(dir, depth = 0) {
  if (depth > 6 || !fs.existsSync(dir)) return null;
  const exe = process.platform === 'win32' ? 'java.exe' : 'java';
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return null;
  }
  if (path.basename(dir) === 'bin' && entries.some((e) => e.isFile() && e.name === exe)) {
    return path.join(dir, exe);
  }
  for (const e of entries) {
    if (e.isDirectory()) {
      const found = findJavaBin(path.join(dir, e.name), depth + 1);
      if (found) return found;
    }
  }
  return null;
}

async function extractArchive(archive, dir) {
  try {
    await run('tar', ['-xf', archive, '-C', dir]); // Linux/macOS и Windows 10+ (bsdtar понимает zip)
  } catch (err) {
    if (process.platform !== 'win32') throw err;
    await run('powershell', [
      '-NoProfile', '-Command',
      `Expand-Archive -Force -LiteralPath '${archive}' -DestinationPath '${dir}'`,
    ]);
  }
}

async function ensureJava(major) {
  const dir = path.join(settings.rootDir, 'runtime', `java${major}`);
  const existing = findJavaBin(dir);
  if (existing) return existing;

  const osName = { win32: 'windows', linux: 'linux', darwin: 'mac' }[process.platform];
  const arch = { x64: 'x64', arm64: 'aarch64', ia32: 'x86' }[process.arch];
  if (!osName || !arch) throw new Error('Эта система не поддерживается для автоматической загрузки Java');

  const url = `https://api.adoptium.net/v3/binary/latest/${major}/ga/${osName}/${arch}/jre/hotspot/normal/eclipse`;
  const archive = path.join(settings.rootDir, 'runtime', `java${major}.${osName === 'windows' ? 'zip' : 'tar.gz'}`);

  send('game:status', `Скачивание Java ${major}...`);
  await download(url, archive, (p) =>
    send('game:progress', { task: p, total: 100, label: `Java ${major}` })
  );

  send('game:status', `Распаковка Java ${major}...`);
  fs.rmSync(dir, { recursive: true, force: true });
  fs.mkdirSync(dir, { recursive: true });
  try {
    await extractArchive(archive, dir);
  } catch (err) {
    fs.rmSync(dir, { recursive: true, force: true });
    throw new Error('Не удалось распаковать Java: ' + err.message);
  } finally {
    fs.rmSync(archive, { force: true });
  }

  const bin = findJavaBin(dir);
  if (!bin) {
    fs.rmSync(dir, { recursive: true, force: true });
    throw new Error('Java скачана, но java не найдена в архиве');
  }
  if (process.platform !== 'win32') fs.chmodSync(bin, 0o755);
  return bin;
}

// ---------- Запуск игры ----------
let launching = false;

ipcMain.handle('game:launch', async (_e, { version, type, loader, loaderVersion }) => {
  if (launching) return { ok: false, error: 'Игра уже запускается' };
  launching = true;
  try {
    const root = settings.rootDir;
    fs.mkdirSync(root, { recursive: true });

    const ramMb = Math.round(Number(settings.ram || 4) * 1024);
    const opts = {
      authorization: Authenticator.getAuth(settings.nickname || 'Player'),
      root,
      version: { number: version, type: type || 'release' },
      memory: { max: `${ramMb}M`, min: `${Math.min(ramMb, 1024)}M` },
    };

    // Java: своя из настроек или автоматическая
    let javaPath = (settings.javaPath || '').trim();
    if (!javaPath) {
      const major = await requiredJava(version);
      javaPath = await ensureJava(major);
    }
    opts.javaPath = javaPath;

    if (loader === 'fabric' || loader === 'quilt') {
      send('game:status', `Подготовка ${loader}...`);
      const base =
        loader === 'fabric'
          ? 'https://meta.fabricmc.net/v2/versions/loader'
          : 'https://meta.quiltmc.org/v3/versions/loader';
      const profile = await getJSON(`${base}/${version}/${loaderVersion}/profile/json`);
      const id = profile.id;
      const file = path.join(root, 'versions', id, `${id}.json`);
      fs.mkdirSync(path.dirname(file), { recursive: true });
      fs.writeFileSync(file, JSON.stringify(profile));
      opts.version.custom = id;
    } else if (loader === 'forge') {
      send('game:status', 'Скачивание Forge...');
      const full = `${version}-${loaderVersion}`;
      const jar = path.join(root, 'forge', `forge-${full}-installer.jar`);
      if (!fs.existsSync(jar)) {
        await download(
          `https://maven.minecraftforge.net/net/minecraftforge/forge/${full}/forge-${full}-installer.jar`,
          jar
        );
      }
      opts.forge = jar;
    }

    const launcher = new Client();
    launcher.on('progress', (p) =>
      send('game:progress', { task: p.task, total: p.total, type: p.type })
    );
    launcher.on('debug', (m) => send('game:log', String(m)));
    launcher.on('data', (m) => send('game:log', String(m)));
    launcher.on('close', (code) => {
      launching = false;
      send('game:closed', code);
    });

    send('game:status', 'Загрузка файлов игры...');
    const proc = await launcher.launch(opts);
    if (!proc) {
      launching = false;
      return { ok: false, error: 'Не удалось запустить игру. Проверь путь к Java в настройках.' };
    }
    send('game:status', 'Игра запущена');
    return { ok: true };
  } catch (err) {
    launching = false;
    return { ok: false, error: err.message };
  }
});

// ---------- Моды / ресурспаки / шейдеры: Modrinth + CurseForge ----------
const CF_LOADER = { forge: 1, fabric: 4, quilt: 5 };
const CF_CLASS = { mod: 6, resourcepack: 12, shader: 6552 };
const KIND_DIR = { mod: 'mods', resourcepack: 'resourcepacks', shader: 'shaderpacks' };
const CF_BASE = 'https://api.curseforge.com/v1';
const cfHeaders = () => ({ 'x-api-key': settings.curseforgeKey, Accept: 'application/json' });
const enc = (x) => encodeURIComponent(JSON.stringify(x));
const loadersFor = (loader) => (loader === 'quilt' ? ['quilt', 'fabric'] : [loader]);

// Скачивает проект Modrinth + его обязательные зависимости (например, Fabric API)
async function installModrinth(idOrSlug, mc, loaders, dir, seen = new Set()) {
  if (seen.has(idOrSlug)) return [];
  seen.add(idOrSlug);

  let url = `https://api.modrinth.com/v2/project/${encodeURIComponent(idOrSlug)}/version?game_versions=${enc([mc])}`;
  if (loaders && loaders.length) url += `&loaders=${enc(loaders)}`;
  const versions = await getJSON(url);
  if (!versions.length) {
    const err = new Error(`Нет версии для ${mc}`);
    err.code = 'NO_VERSION';
    throw err;
  }
  const v = versions.find((x) => x.version_type === 'release') || versions[0];
  const file = v.files.find((f) => f.primary) || v.files[0];
  const dest = path.join(dir, file.filename);
  if (!fs.existsSync(dest)) await download(file.url, dest);

  const done = [file.filename];
  for (const d of v.dependencies || []) {
    if (d.dependency_type === 'required' && d.project_id) {
      try {
        done.push(...(await installModrinth(d.project_id, mc, loaders, dir, seen)));
      } catch {
        /* зависимость не нашлась — пропускаем */
      }
    }
  }
  return done;
}

// Скачивает файл CurseForge + обязательные зависимости
async function installCurseForge(modId, mc, loader, dir, seen = new Set()) {
  if (seen.has(modId)) return [];
  seen.add(modId);

  let q = `gameVersion=${encodeURIComponent(mc)}&pageSize=10`;
  const lt = CF_LOADER[loader === 'quilt' ? 'fabric' : loader];
  if (lt) q += `&modLoaderType=${lt}`;
  const res = await getJSON(`${CF_BASE}/mods/${modId}/files?${q}`, cfHeaders());
  if (!res.data || !res.data.length) {
    const err = new Error(`Нет файла для ${mc}`);
    err.code = 'NO_VERSION';
    throw err;
  }
  const f = res.data.find((x) => x.releaseType === 1) || res.data[0];
  const dest = path.join(dir, f.fileName);
  if (!fs.existsSync(dest)) {
    const dl = f.downloadUrl || `https://www.curseforge.com/api/v1/mods/${modId}/files/${f.id}/download`;
    await download(dl, dest);
  }
  const done = [f.fileName];
  for (const d of f.dependencies || []) {
    if (d.relationType === 3) {
      try {
        done.push(...(await installCurseForge(d.modId, mc, loader, dir, seen)));
      } catch {
        /* зависимость не нашлась — пропускаем */
      }
    }
  }
  return done;
}

// Ищет мод на CurseForge по названию (только точное совпадение, чтобы не поставить чужое)
async function cfFindMod(name, slug, mc, loader) {
  const lt = CF_LOADER[loader === 'quilt' ? 'fabric' : loader];
  let url =
    `${CF_BASE}/mods/search?gameId=432&classId=6&pageSize=10&sortField=2&sortOrder=desc` +
    `&searchFilter=${encodeURIComponent(name)}&gameVersion=${encodeURIComponent(mc)}`;
  if (lt) url += `&modLoaderType=${lt}`;
  const data = await getJSON(url, cfHeaders());
  const norm = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  return (data.data || []).find((m) => norm(m.name) === norm(name) || norm(m.slug) === norm(slug)) || null;
}

// ---------- Иконки: грузим сами и кэшируем на диске ----------
const ICON_HOSTS = [/(^|\.)modrinth\.com$/, /(^|\.)forgecdn\.net$/, /(^|\.)curseforge\.com$/];
const iconCacheDir = () => path.join(app.getPath('userData'), 'icon-cache');

async function fetchIconBytes(url) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 8000);
  try {
    const res = await fetch(url, { headers: { 'User-Agent': UA }, signal: ctl.signal, redirect: 'follow' });
    if (!res.ok) throw new Error(String(res.status));
    const type = res.headers.get('content-type') || 'image/png';
    if (!type.startsWith('image/')) throw new Error('не картинка');
    const buf = Buffer.from(await res.arrayBuffer());
    if (buf.length > 2 * 1024 * 1024) throw new Error('слишком большая');
    return { type, buf };
  } finally {
    clearTimeout(timer);
  }
}

ipcMain.handle('icon:get', async (_e, url) => {
  try {
    const u = new URL(url);
    if (u.protocol !== 'https:' || !ICON_HOSTS.some((re) => re.test(u.hostname))) return null;

    const key = crypto.createHash('sha1').update(url).digest('hex');
    const file = path.join(iconCacheDir(), key);
    if (fs.existsSync(file + '.json') && fs.existsSync(file)) {
      const meta = JSON.parse(fs.readFileSync(file + '.json', 'utf8'));
      return `data:${meta.type};base64,${fs.readFileSync(file).toString('base64')}`;
    }

    // 1) напрямую, 2) через публичный прокси картинок wsrv.nl (если CDN недоступен)
    const routes = [url, `https://wsrv.nl/?url=${encodeURIComponent(url)}&w=128&h=128&fit=cover`];
    for (const route of routes) {
      try {
        const { type, buf } = await fetchIconBytes(route);
        fs.mkdirSync(iconCacheDir(), { recursive: true });
        fs.writeFileSync(file, buf);
        fs.writeFileSync(file + '.json', JSON.stringify({ type }));
        return `data:${type};base64,${buf.toString('base64')}`;
      } catch {
        /* пробуем следующий путь */
      }
    }
    return null;
  } catch {
    return null;
  }
});

ipcMain.handle('mods:search', async (_e, { source, query, mc, loader, kind = 'mod', offset = 0 }) => {
  try {
    if (source === 'modrinth') {
      const facets = [[`project_type:${kind}`]];
      if (mc) facets.push([`versions:${mc}`]);
      if (kind === 'mod' && loader && loader !== 'vanilla') facets.push([`categories:${loader}`]);
      const url =
        `https://api.modrinth.com/v2/search?limit=40&offset=${Number(offset) || 0}&index=${query ? 'relevance' : 'downloads'}` +
        `&query=${encodeURIComponent(query || '')}&facets=${encodeURIComponent(JSON.stringify(facets))}`;
      const data = await getJSON(url);
      return {
        ok: true,
        total: data.total_hits,
        items: data.hits.map((h) => ({
          id: h.project_id,
          title: h.title,
          description: h.description,
          icon: h.icon_url,
          downloads: h.downloads,
          author: h.author,
        })),
      };
    }

    if (!settings.curseforgeKey) {
      return { ok: false, error: 'Для CurseForge нужен API-ключ: вставь его в Настройках (console.curseforge.com).' };
    }
    let url =
      `${CF_BASE}/mods/search?gameId=432&classId=${CF_CLASS[kind] || 6}&pageSize=40&index=${Number(offset) || 0}` +
      `&sortField=${query ? 2 : 6}&sortOrder=desc&searchFilter=${encodeURIComponent(query || '')}`;
    if (mc) url += `&gameVersion=${encodeURIComponent(mc)}`;
    if (kind === 'mod' && CF_LOADER[loader]) url += `&modLoaderType=${CF_LOADER[loader]}`;
    const data = await getJSON(url, cfHeaders());
    return {
      ok: true,
      total: data.pagination && data.pagination.totalCount,
      items: data.data.map((m) => ({
        id: m.id,
        title: m.name,
        description: m.summary,
        icon: m.logo && m.logo.thumbnailUrl,
        downloads: m.downloadCount,
        author: m.authors && m.authors[0] && m.authors[0].name,
      })),
    };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

ipcMain.handle('mods:install', async (_e, { source, id, mc, loader, kind = 'mod' }) => {
  try {
    if (kind === 'mod' && (!loader || loader === 'vanilla')) {
      return { ok: false, error: 'Выбери загрузчик модов (Fabric / Forge / Quilt) рядом с кнопкой «Играть».' };
    }
    const dir = path.join(settings.rootDir, KIND_DIR[kind] || 'mods');

    if (source === 'modrinth') {
      const files = await installModrinth(id, mc, kind === 'mod' ? loadersFor(loader) : null, dir);
      return { ok: true, filename: files[0], extra: files.length - 1 };
    }

    if (!settings.curseforgeKey) {
      return { ok: false, error: 'Для CurseForge нужен API-ключ: вставь его в Настройках (console.curseforge.com).' };
    }
    const files = await installCurseForge(id, mc, kind === 'mod' ? loader : null, dir);
    return { ok: true, filename: files[0], extra: files.length - 1 };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

// ---------- Оптимизация: набор модов с Modrinth ----------
// [slug на Modrinth, название, описание]
const OPT_FABRIC = [
  ['sodium', 'Sodium', 'Новый движок отрисовки — главный буст FPS'],
  ['lithium', 'Lithium', 'Оптимизация игровой логики и сервера'],
  ['ferrite-core', 'FerriteCore', 'Меньше потребление памяти'],
  ['entityculling', 'Entity Culling', 'Не рисует мобов, которых не видно'],
  ['immediatelyfast', 'ImmediatelyFast', 'Быстрее интерфейс и текст'],
  ['modernfix', 'ModernFix', 'Быстрый запуск и меньше памяти'],
  ['krypton', 'Krypton', 'Оптимизация сети'],
  ['dynamic-fps', 'Dynamic FPS', 'Снижает нагрузку, когда окно не в фокусе'],
  ['sodium-extra', 'Sodium Extra', 'Доп. настройки Sodium: облака, анимации, частицы'],
  ['moreculling', 'More Culling', 'Ещё больше отсечения невидимых объектов'],
  ['scalablelux', 'ScalableLux', 'Быстрое освещение мира'],
  ['noisium', 'Noisium', 'Быстрее генерация новых территорий'],
  ['memoryleakfix', 'Memory Leak Fix', 'Исправляет утечки памяти'],
];
const OPT_FORGE = [
  ['embeddium', 'Embeddium', 'Движок отрисовки (аналог Sodium) — буст FPS'],
  ['ferrite-core', 'FerriteCore', 'Меньше потребление памяти'],
  ['modernfix', 'ModernFix', 'Быстрый запуск и меньше памяти'],
  ['entityculling', 'Entity Culling', 'Не рисует мобов, которых не видно'],
  ['immediatelyfast', 'ImmediatelyFast', 'Быстрее интерфейс и текст'],
  ['dynamic-fps', 'Dynamic FPS', 'Снижает нагрузку, когда окно не в фокусе'],
  ['moreculling', 'More Culling', 'Ещё больше отсечения невидимых объектов'],
  ['memoryleakfix', 'Memory Leak Fix', 'Исправляет утечки памяти'],
];
const optList = (loader) =>
  loader === 'forge' ? OPT_FORGE : loader === 'fabric' || loader === 'quilt' ? OPT_FABRIC : [];

ipcMain.handle('opt:list', (_e, loader) =>
  optList(loader).map(([slug, name, desc]) => ({ slug, name, desc }))
);

ipcMain.handle('opt:install', async (_e, { mc, loader }) => {
  const list = optList(loader);
  if (!list.length) return { ok: false, error: 'Для Vanilla оптимизация модами недоступна — выбери Fabric, Forge или Quilt.' };

  const dir = modsDir();
  const seenMr = new Set();
  const seenCf = new Set();
  const stats = { installed: 0, skipped: 0, failed: 0, needKey: 0, bySource: { modrinth: 0, curseforge: 0 } };

  for (const [slug, name] of list) {
    send('opt:progress', { slug, status: 'loading' });
    let source = null;
    let file = null;
    let mrErr = null;
    let cfErr = null;

    // 1) Modrinth
    try {
      const files = await installModrinth(slug, mc, loadersFor(loader), dir, seenMr);
      source = 'Modrinth';
      file = files[0];
    } catch (err) {
      mrErr = err;
    }

    // 2) CurseForge (если на Modrinth не нашлось и есть API-ключ)
    if (!source && settings.curseforgeKey) {
      try {
        const m = await cfFindMod(name, slug, mc, loader);
        if (!m) {
          const e = new Error('не найден на CurseForge');
          e.code = 'NO_VERSION';
          throw e;
        }
        const files = await installCurseForge(m.id, mc, loader, dir, seenCf);
        source = 'CurseForge';
        file = files[0];
      } catch (err) {
        cfErr = err;
      }
    }

    if (source) {
      stats.installed++;
      stats.bySource[source === 'Modrinth' ? 'modrinth' : 'curseforge']++;
      send('opt:progress', { slug, status: 'ok', detail: file, source });
      continue;
    }

    if (!settings.curseforgeKey) stats.needKey++;
    const real = [mrErr, cfErr].find((e) => e && e.code !== 'NO_VERSION');
    if (real) {
      stats.failed++;
      send('opt:progress', { slug, status: 'fail', detail: real.message });
    } else {
      stats.skipped++;
      send('opt:progress', { slug, status: 'skip', detail: `Нет версии для ${mc}` });
    }
  }
  return { ok: true, ...stats };
});
