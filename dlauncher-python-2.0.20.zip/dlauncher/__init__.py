__version__ = "2.0.20"
APP_NAME = "DLauncher"
