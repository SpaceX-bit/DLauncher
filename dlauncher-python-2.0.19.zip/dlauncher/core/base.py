"""Базовые обработчики: настройки, фон, профили, папки, ссылки, список версий.

Порт соответствующих ipcMain.handle из main.js.
Контракт модулей: handlers(ctx) -> dict[канал, функция(payload) -> результат].
"""
from __future__ import annotations

import os
import re
import shutil
import time

from . import util
from .ctx import PUBLIC_KEYS, system_ram_gb

BG_IMAGE = [".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp", ".avif"]
BG_VIDEO = [".mp4", ".webm", ".m4v", ".ogv", ".mov"]
BG_LIMIT = {"image": 100 * 1024 ** 2, "video": 1024 ** 3}

FOLDERS = {
    "mods": "mods", "resourcepacks": "resourcepacks", "shaderpacks": "shaderpacks",
    "saves": "saves", "screenshots": "screenshots", "backups": "backups",
    "logs": "logs", "crash-reports": "crash-reports",
}
LINKS = {"tiktok": "https://www.tiktok.com/@udinaxui067"}


def parse_jvm_args(text) -> list[str]:
    """Аргументы Java: делим по пробелам (кавычки поддерживаются). Память задаётся отдельно."""
    out = []
    for m in re.finditer(r'"([^"]*)"|\'([^\']*)\'|(\S+)', str(text or "")):
        out.append(next(g for g in m.groups() if g is not None))
    for a in out:
        if not a.startswith("-"):
            raise ValueError(f"Аргумент «{a}» должен начинаться с «-»")
        if re.match(r"^-Xm[sx]", a, re.I):
            raise ValueError("Память задаётся ползунком выше, а не в аргументах (-Xmx/-Xms)")
    return out


def _dimension(v, label):
    if v is None or v == "":
        return None
    try:
        n = round(float(v))
    except (TypeError, ValueError):
        raise ValueError(f"{label}: число от 320 до 7680")
    if n < 320 or n > 7680:
        raise ValueError(f"{label}: число от 320 до 7680")
    return int(n)


def _num(v, default):
    try:
        n = float(v)
        return n if n == n else default
    except (TypeError, ValueError):
        return default


def handlers(ctx):
    # ---------- настройки ----------
    def settings_get(_=None):
        return ctx.public_settings()

    def settings_set(patch=None):
        patch = patch or {}
        with ctx.lock:
            nxt = dict(ctx.settings)
            for k in PUBLIC_KEYS:
                if k in patch:
                    nxt[k] = patch[k]
            nxt["ram"] = min(max(_num(nxt.get("ram"), 4) or 4, 1), system_ram_gb())
            if float(nxt["ram"]).is_integer():
                nxt["ram"] = int(nxt["ram"])
            nxt["accountMode"] = "microsoft" if nxt.get("accountMode") == "microsoft" else "offline"
            nxt["glass"] = nxt.get("glass") is not False
            gs = _num(nxt.get("glassStrength"), 60)
            nxt["glassStrength"] = int(min(max(gs, 0), 100))
            nxt["lang"] = "en" if nxt.get("lang") == "en" else "ru"
            nxt["bgDim"] = int(min(max(round(_num(nxt.get("bgDim"), 0)), 0), 80))
            nxt["discordRpc"] = nxt.get("discordRpc") is True
            nxt["autoUpdate"] = nxt.get("autoUpdate") is not False
            nxt["autoBackup"] = nxt.get("autoBackup") is not False
            nxt["backupKeep"] = int(min(max(round(_num(nxt.get("backupKeep"), 5)) or 5, 1), 20))
            nxt["closeToTray"] = nxt.get("closeToTray") is True
            nxt["autoStart"] = nxt.get("autoStart") is True
            nxt["compatCheck"] = nxt.get("compatCheck") is not False
            nxt["tourDone"] = nxt.get("tourDone") is True
            nxt["autoUpdateMods"] = nxt.get("autoUpdateMods") is True
            nxt["discordClientId"] = str(nxt.get("discordClientId") or "").strip()[:32]
            for k in ("nickname", "curseforgeKey", "javaPath", "msClientId", "updateUrl", "rootDir"):
                nxt[k] = str(nxt.get(k) or "").strip()
            if not nxt["rootDir"]:
                nxt["rootDir"] = ctx.settings["rootDir"]
            ctx.settings.clear()
            ctx.settings.update(nxt)
            ctx.save_settings()
        try:
            os.makedirs(ctx.root, exist_ok=True)
        except OSError:
            pass
        hook = getattr(ctx, "on_settings_changed", None)  # презентер Discord, трей, автозапуск
        if callable(hook):
            try:
                hook()
            except Exception as e:  # noqa: BLE001
                ctx.diag(f"on_settings_changed: {e}")
        return ctx.public_settings()

    # ---------- свой фон ----------
    state = {"busy": False}

    def _remove_bg_file():
        old = ctx.bg_path()
        if old:
            try:
                os.remove(old)
            except OSError:
                pass

    def bg_choose(_=None):
        if state["busy"]:
            return {"ok": False, "error": "Файл уже копируется"}
        state["busy"] = True
        try:
            en = ctx.settings.get("lang") == "en"
            allext = [e[1:] for e in BG_IMAGE + BG_VIDEO]
            src = ctx.ui.open_file(
                "Choose a background image or video" if en else "Выбери картинку или видео для фона",
                [("Images and videos" if en else "Картинки и видео", allext),
                 ("Images" if en else "Картинки", [e[1:] for e in BG_IMAGE]),
                 ("Videos" if en else "Видео", [e[1:] for e in BG_VIDEO])])
            if not src:
                return {"ok": False, "canceled": True}
            ext = os.path.splitext(src)[1].lower()
            typ = "image" if ext in BG_IMAGE else "video" if ext in BG_VIDEO else None
            if not typ:
                return {"ok": False, "error": "Этот формат не поддерживается. Подходят: PNG, JPG, WEBP, GIF, BMP, AVIF, MP4, WEBM, M4V, OGV, MOV."}
            if not os.path.isfile(src):
                return {"ok": False, "error": "Это не файл"}
            if os.path.getsize(src) > BG_LIMIT[typ]:
                return {"ok": False, "error": "Файл слишком большой: картинки до 100 МБ, видео до 1 ГБ."}
            os.makedirs(ctx.bg_dir, exist_ok=True)
            name = f"bg-{int(time.time() * 1000)}{ext}"
            dest = os.path.join(ctx.bg_dir, name)
            try:
                shutil.copyfile(src, dest + ".part")
                os.replace(dest + ".part", dest)
            except OSError as e:
                try:
                    os.remove(dest + ".part")
                except OSError:
                    pass
                return {"ok": False, "error": "Не удалось скопировать файл: " + str(e)}
            _remove_bg_file()
            ctx.settings.update(bgFile=name, bgType=typ, bgName=os.path.basename(src)[:80])
            ctx.save_settings()
            return {"ok": True, "settings": ctx.public_settings()}
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": str(e)}
        finally:
            state["busy"] = False

    def bg_reset(_=None):
        _remove_bg_file()
        ctx.settings.update(bgFile="", bgType="", bgName="")
        ctx.save_settings()
        return {"ok": True, "settings": ctx.public_settings()}

    # ---------- профили ----------
    def profiles_list(_=None):
        return {
            "current": ctx.settings["currentProfile"],
            "profiles": [dict(p, modsCount=ctx.count_mods(p["id"])) for p in ctx.settings["profiles"]],
        }

    def profiles_create(data=None):
        try:
            return {"ok": True, "profile": ctx.create_profile(data or {})}
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": str(e)}

    def profiles_select(pid=None):
        if not ctx.find_profile(pid):
            return {"ok": False, "error": "Профиль не найден"}
        ctx.settings["currentProfile"] = pid
        ctx.save_settings()
        return {"ok": True}

    def profiles_update(arg=None):
        arg = arg or {}
        p = ctx.find_profile(arg.get("id"))
        if not p:
            return {"ok": False, "error": "Профиль не найден"}
        try:
            q = arg.get("patch") or {}
            nxt = {}
            if "name" in q:
                nxt["name"] = str(q["name"]).strip()[:40]
                if not nxt["name"]:
                    raise ValueError("Название не может быть пустым")
            if "ram" in q:
                if q["ram"] is None or q["ram"] == "":
                    nxt["ram"] = None
                else:
                    try:
                        n = float(q["ram"])
                    except (TypeError, ValueError):
                        raise ValueError("Память: нужно число")
                    n = min(max(n, 1), system_ram_gb())
                    nxt["ram"] = int(n) if float(n).is_integer() else n
            if "jvmArgs" in q:
                parse_jvm_args(q["jvmArgs"])
                nxt["jvmArgs"] = str(q["jvmArgs"] or "").strip()[:600]
            if "width" in q or "height" in q:
                w = _dimension(q["width"] if "width" in q else p.get("width"), "Ширина")
                h = _dimension(q["height"] if "height" in q else p.get("height"), "Высота")
                if (w is None) != (h is None):
                    raise ValueError("Укажи ширину и высоту вместе (или оставь оба поля пустыми)")
                nxt["width"], nxt["height"] = w, h
            if "fullscreen" in q:
                nxt["fullscreen"] = bool(q["fullscreen"])
            if "javaPath" in q:
                nxt["javaPath"] = str(q["javaPath"] or "").strip()[:260]
            p.update(nxt)
            ctx.save_settings()
            return {"ok": True, "profile": dict(p, modsCount=ctx.count_mods(p["id"]))}
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": str(e)}

    def profiles_delete(arg=None):
        arg = arg or {}
        pid = arg.get("id")
        delete_files = arg.get("deleteFiles", True)
        p = ctx.find_profile(pid)
        if not p:
            return {"ok": False, "error": "Профиль не найден"}
        if ctx.launching:
            return {"ok": False, "error": "Нельзя удалять профиль, пока запускается игра"}
        try:
            if delete_files:
                shutil.rmtree(ctx.instance_dir(pid), ignore_errors=True)
            ctx.settings["profiles"] = [x for x in ctx.settings["profiles"] if x["id"] != pid]
            if ctx.settings["currentProfile"] == pid:
                ps = ctx.settings["profiles"]
                ctx.settings["currentProfile"] = ps[0]["id"] if ps else None
            ctx.save_settings()
            return {"ok": True, "current": ctx.settings["currentProfile"]}
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": str(e)}

    # ---------- папки, ссылки ----------
    def folder_open(arg=None):
        which = arg if isinstance(arg, str) else (arg or {}).get("which")
        pid = (arg.get("profileId") if isinstance(arg, dict) else None) or ctx.settings["currentProfile"]
        profile = ctx.find_profile(pid)
        d = ctx.root
        if which != "root" and profile:
            d = ctx.ensure_instance(profile["id"])
            if which in FOLDERS:
                d = os.path.join(d, FOLDERS[which])
        os.makedirs(d, exist_ok=True)
        ctx.ui.open_path(d)
        return {"ok": True}

    def link_open(key=None):
        url = LINKS.get(key) if isinstance(key, str) else None
        if not url:
            return {"ok": False}
        ctx.ui.open_url(url)
        return {"ok": True}

    # ---------- версии Minecraft ----------
    def versions_list(_=None):
        m = ctx.get_manifest()
        return {"latest": m["latest"],
                "versions": [{"id": v["id"], "type": v["type"], "releaseTime": v.get("releaseTime")}
                             for v in m["versions"]]}

    return {
        "settings:get": settings_get, "settings:set": settings_set,
        "bg:choose": bg_choose, "bg:reset": bg_reset,
        "profiles:list": profiles_list, "profiles:create": profiles_create,
        "profiles:select": profiles_select, "profiles:update": profiles_update,
        "profiles:delete": profiles_delete,
        "folder:open": folder_open, "link:open": link_open,
        "versions:list": versions_list,
    }
