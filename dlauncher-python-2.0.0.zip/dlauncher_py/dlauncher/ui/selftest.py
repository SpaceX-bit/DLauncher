"""Самопроверка интерфейса для CI: python main.py --selftest (QT_QPA_PLATFORM=offscreen).

Создаёт окно, открывает каждую вкладку, вызывает page.selftest() (страница сама строит свои диалоги без exec),
делает снимок окна. Любая ошибка -> код 1 и подробности в stdout и launcher.log.
"""
from __future__ import annotations

import traceback

from PySide6.QtWidgets import QApplication

from .mainwindow import PAGE_SPECS


def run_selftest(app: QApplication, actx, win, api) -> int:
    problems: list[str] = []

    def spin(n: int = 5):
        for _ in range(n):
            app.processEvents()

    if api.missing:
        problems.append("нет модулей ядра: " + ", ".join(api.missing))
    for key, err in win.page_errors.items():
        problems.append(f"страница {key} не создана:\n{err}")

    win.show()
    spin()
    for key, ru, _mod, _cls in PAGE_SPECS:
        page = win.pages.get(key)
        if page is None:
            continue
        try:
            win.show_page(key)
            spin()
            st = getattr(page, "selftest", None)
            if callable(st):
                st()
                spin()
            if win.grab().isNull():
                problems.append(f"{key}: пустой снимок окна")
        except Exception:  # noqa: BLE001
            problems.append(f"{key}: исключение\n{traceback.format_exc()}")

    # переключение языка и обратно
    try:
        for lang in ("en", "ru"):
            actx._set_settings(dict(actx.settings, lang=lang))
            spin()
            for key in win.pages:
                win.show_page(key)
                spin(2)
    except Exception:  # noqa: BLE001
        problems.append("смена языка:\n" + traceback.format_exc())

    for p in problems:
        print("SELFTEST FAIL:", p)
        actx.ctx.diag("SELFTEST FAIL: " + p)
    if not problems:
        print(f"SELFTEST OK: {len(win.pages)} страниц, {len(api.handlers)} каналов ядра")
    return 1 if problems else 0
