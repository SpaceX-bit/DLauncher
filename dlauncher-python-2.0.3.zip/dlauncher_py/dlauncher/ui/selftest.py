"""Самопроверка интерфейса для CI: python main.py --selftest (QT_QPA_PLATFORM=offscreen).

Создаёт окно, открывает каждую вкладку, вызывает page.selftest() (страница сама строит свои диалоги без exec),
делает снимок окна. Любая ошибка -> код 1 и подробности в stdout и launcher.log.
"""
from __future__ import annotations

import os
import traceback

from PySide6.QtWidgets import QApplication

from .mainwindow import PAGE_SPECS


def run_selftest(app: QApplication, actx, win, api) -> int:
    problems: list[str] = []

    # сторож: если что-то зависло, через 100 с печатаем, где именно, и завершаемся с ошибкой
    import faulthandler
    import sys
    try:
        out = sys.stderr
        if out is None:
            out = open(os.path.join(actx.ctx.user_data, "selftest-trace.txt"), "w")
        faulthandler.dump_traceback_later(100, exit=True, file=out)
    except Exception:  # noqa: BLE001
        pass

    # модальное окно в самопроверке заблокировало бы всё навсегда — превращаем его в ошибку со стеком вызовов
    try:
        from PySide6.QtWidgets import QDialog

        def _no_exec(self, *a, **k):
            problems.append("попытка открыть модальное окно в самопроверке:\n" + "".join(traceback.format_stack(limit=12)))
            return 0
        QDialog.exec = _no_exec
        QDialog.exec_ = _no_exec
    except Exception:  # noqa: BLE001
        pass

    def step(msg: str) -> None:
        print("selftest:", msg, flush=True)

    def spin(n: int = 5):
        for _ in range(n):
            app.processEvents()

    if api.missing:
        problems.append("нет модулей ядра: " + ", ".join(api.missing))
    for key, err in win.page_errors.items():
        problems.append(f"страница {key} не создана:\n{err}")

    win.show()
    spin()
    for key, ru, _mod, _cls in PAGE_SPECS:
        page = win.pages.get(key)
        if page is None:
            continue
        step(key)
        try:
            win.show_page(key)
            spin()
            st = getattr(page, "selftest", None)
            if callable(st):
                st()
                spin()
            shot = win.grab()
            if shot.isNull():
                problems.append(f"{key}: пустой снимок окна")
            elif os.environ.get("DLAUNCHER_SHOTS"):  # скриншоты вкладок для просмотра из CI
                os.makedirs(os.environ["DLAUNCHER_SHOTS"], exist_ok=True)
                shot.save(os.path.join(os.environ["DLAUNCHER_SHOTS"], f"{key}.png"))
        except Exception:  # noqa: BLE001
            problems.append(f"{key}: исключение\n{traceback.format_exc()}")

    # переключение языка и обратно
    step("language")
    try:
        for lang in ("en", "ru"):
            actx._set_settings(dict(actx.settings, lang=lang))
            spin()
            for key in win.pages:
                win.show_page(key)
                spin(2)
    except Exception:  # noqa: BLE001
        problems.append("смена языка:\n" + traceback.format_exc())

    try:
        faulthandler.cancel_dump_traceback_later()
    except Exception:  # noqa: BLE001
        pass
    for p in problems:
        print("SELFTEST FAIL:", p, flush=True)
        actx.ctx.diag("SELFTEST FAIL: " + p)
    if not problems:
        print(f"SELFTEST OK: {len(win.pages)} страниц, {len(api.handlers)} каналов ядра", flush=True)
    return 1 if problems else 0
