# -*- mode: python ; coding: utf-8 -*-
# Сборка: pyinstaller packaging/DLauncher.spec --noconfirm   (из корня проекта)
from PyInstaller.utils.hooks import collect_submodules
import os

ROOT = os.path.abspath(os.path.join(SPECPATH, ".."))

hidden = collect_submodules("dlauncher")  # страницы и модули ядра подключаются по имени (importlib)

a = Analysis(
    [os.path.join(ROOT, "main.py")],
    pathex=[ROOT],
    binaries=[],
    datas=[
        (os.path.join(ROOT, "assets"), "assets"),
        (os.path.join(ROOT, "dlauncher", "ui", "en.json"), os.path.join("dlauncher", "ui")),
        (os.path.join(ROOT, "update-config.json"), "."),
    ],
    hiddenimports=hidden,
    hookspath=[],
    runtime_hooks=[],
    excludes=["tkinter", "unittest", "pydoc", "PySide6.QtWebEngineCore", "PySide6.QtWebEngineWidgets",
              "PySide6.Qt3DCore", "PySide6.QtQuick", "PySide6.QtQml", "PySide6.QtCharts", "PySide6.QtDataVisualization"],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, [],
    exclude_binaries=True,
    name="DLauncher",
    debug=False,
    strip=False,
    upx=False,
    console=False,
    icon=os.path.join(ROOT, "assets", "icon.ico"),
)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name="DLauncher")
