"""Цвета и таблица стилей (QSS) в духе Electron-версии: тёмная тема, оранжевый акцент, «стекло»."""
from __future__ import annotations

ACCENT = "#ffb347"
ACCENT2 = "#ff7e5f"
TEXT = "#f4f1ff"
MUTED = "#b9b2d6"
OK = "#6ee7a0"
WARN = "#ffd166"
ERR = "#ff6b6b"
PAGE_BG = "#0b0b14"
MODAL_BG = "#161326"
OPT_BG = "#1b1730"


def qss(glass: bool = True, strength: int = 60) -> str:
    s = max(0, min(100, int(strength)))
    # «Стекло»: чем сильнее, тем прозрачнее панели (видно фон)
    a = int(150 + (100 - s) * 0.9) if glass else 235
    a = max(90, min(240, a))
    card = f"rgba(18,16,32,{a})"
    soft = f"rgba(0,0,0,{max(60, a - 70)})"
    return f"""
* {{ font-family: "Segoe UI", "Noto Sans", "DejaVu Sans", sans-serif; font-size: 13px; color: {TEXT}; }}
QWidget {{ background: transparent; }}
QDialog, QMessageBox {{ background: {MODAL_BG}; }}
QToolTip {{ background: {OPT_BG}; color: {TEXT}; border: 1px solid rgba(255,255,255,40); padding: 4px 6px; }}

QLabel {{ background: transparent; }}
QLabel[kind="h1"] {{ font-size: 34px; font-weight: 800; }}
QLabel[kind="h2"] {{ font-size: 18px; font-weight: 700; }}
QLabel[kind="h3"] {{ font-size: 12px; font-weight: 700; color: {ACCENT}; letter-spacing: 1px; }}
QLabel[kind="muted"] {{ color: {MUTED}; }}
QLabel[kind="ok"] {{ color: {OK}; }}
QLabel[kind="warn"] {{ color: {WARN}; }}
QLabel[kind="err"] {{ color: {ERR}; }}
QLabel[kind="accent"] {{ color: {ACCENT}; font-weight: 700; }}
QLabel[kind="ph"] {{ background: rgba(0,0,0,80); border-radius: 10px; color: {ACCENT}; font-weight: 800; font-size: 20px; }}

QFrame#card, QFrame[kind="card"] {{ background: {card}; border: 1px solid rgba(255,255,255,36); border-radius: 14px; }}
QFrame[kind="soft"] {{ background: {soft}; border: 1px solid rgba(255,255,255,24); border-radius: 12px; }}
QFrame[kind="current"] {{ background: {card}; border: 2px solid {ACCENT}; border-radius: 14px; }}
QFrame[kind="fit"] {{ background: rgba(60,200,120,45); border: 1px solid rgba(110,231,160,160); border-radius: 10px; }}
QFrame#navbar {{ background: {card}; border: 1px solid rgba(255,255,255,36); border-radius: 14px; }}

QPushButton {{ background: rgba(255,255,255,26); border: 1px solid rgba(255,255,255,46); border-radius: 10px;
  padding: 7px 14px; font-weight: 600; }}
QPushButton:hover {{ background: rgba(255,255,255,52); }}
QPushButton:pressed {{ background: rgba(255,255,255,70); }}
QPushButton:disabled {{ color: rgba(244,241,255,110); background: rgba(255,255,255,12); border-color: rgba(255,255,255,20); }}
QPushButton[kind="primary"] {{ border: none; color: #20122b;
  background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 {ACCENT}, stop:1 {ACCENT2}); }}
QPushButton[kind="primary"]:hover {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 #ffc674, stop:1 #ff9479); }}
QPushButton[kind="primary"]:disabled {{ color: rgba(32,18,43,150); background: rgba(255,179,71,90); }}
QPushButton[kind="danger"] {{ background: rgba(255,107,107,50); border-color: rgba(255,107,107,150); color: #ffd3d3; }}
QPushButton[kind="danger"]:hover {{ background: rgba(255,107,107,90); }}
QPushButton[kind="small"] {{ padding: 3px 10px; font-size: 12px; border-radius: 8px; }}
QPushButton[kind="nav"] {{ border: none; background: transparent; padding: 8px 16px; border-radius: 10px; font-weight: 700; color: {MUTED}; }}
QPushButton[kind="nav"]:hover {{ background: rgba(255,255,255,30); color: {TEXT}; }}
QPushButton[kind="nav"]:checked {{ color: #20122b;
  background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 {ACCENT}, stop:1 {ACCENT2}); }}
QPushButton[kind="chip"] {{ border-radius: 14px; padding: 4px 12px; background: rgba(0,0,0,70); }}
QPushButton[kind="chip"]:checked {{ border-color: {ACCENT}; color: {ACCENT}; }}
QPushButton[kind="play"] {{ font-size: 22px; font-weight: 800; padding: 14px 54px; border-radius: 16px; border: none; color: #20122b;
  background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 {ACCENT}, stop:1 {ACCENT2}); }}
QPushButton[kind="play"]:disabled {{ color: rgba(32,18,43,150); background: rgba(255,179,71,90); }}

QLineEdit, QPlainTextEdit, QTextEdit, QSpinBox, QDoubleSpinBox, QComboBox {{
  background: rgba(0,0,0,90); border: 1px solid rgba(255,255,255,46); border-radius: 9px; padding: 6px 9px;
  selection-background-color: {ACCENT}; selection-color: #20122b; }}
QLineEdit:focus, QPlainTextEdit:focus, QTextEdit:focus, QSpinBox:focus, QComboBox:focus {{ border-color: {ACCENT}; }}
QComboBox::drop-down {{ border: none; width: 22px; }}
QComboBox QAbstractItemView {{ background: {OPT_BG}; border: 1px solid rgba(255,255,255,50); selection-background-color: rgba(255,179,71,110); outline: 0; }}
QListWidget, QTreeWidget, QTableWidget {{ background: rgba(0,0,0,70); border: 1px solid rgba(255,255,255,36); border-radius: 10px; outline: 0; }}
QListWidget::item {{ padding: 6px; border-radius: 6px; }}
QListWidget::item:selected {{ background: rgba(255,179,71,90); color: {TEXT}; }}

QCheckBox {{ spacing: 8px; }}
QCheckBox::indicator {{ width: 18px; height: 18px; border-radius: 5px; border: 1px solid rgba(255,255,255,80); background: rgba(0,0,0,90); }}
QCheckBox::indicator:checked {{ background: {ACCENT}; border-color: {ACCENT}; }}
QRadioButton::indicator {{ width: 16px; height: 16px; border-radius: 8px; border: 1px solid rgba(255,255,255,80); background: rgba(0,0,0,90); }}
QRadioButton::indicator:checked {{ background: {ACCENT}; border-color: {ACCENT}; }}

QSlider::groove:horizontal {{ height: 6px; background: rgba(255,255,255,40); border-radius: 3px; }}
QSlider::sub-page:horizontal {{ background: {ACCENT}; border-radius: 3px; }}
QSlider::handle:horizontal {{ width: 16px; margin: -6px 0; border-radius: 8px; background: #fff; }}

QProgressBar {{ background: rgba(255,255,255,40); border: none; border-radius: 4px; height: 8px; text-align: center; color: transparent; }}
QProgressBar::chunk {{ border-radius: 4px; background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 {ACCENT}, stop:1 {ACCENT2}); }}

QScrollArea {{ border: none; background: transparent; }}
QScrollArea > QWidget > QWidget {{ background: transparent; }}
QScrollBar:vertical {{ width: 10px; background: transparent; margin: 2px; }}
QScrollBar::handle:vertical {{ background: rgba(255,255,255,70); border-radius: 4px; min-height: 30px; }}
QScrollBar::handle:vertical:hover {{ background: rgba(255,255,255,120); }}
QScrollBar:horizontal {{ height: 10px; background: transparent; margin: 2px; }}
QScrollBar::handle:horizontal {{ background: rgba(255,255,255,70); border-radius: 4px; min-width: 30px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ width: 0; height: 0; }}
QScrollBar::add-page, QScrollBar::sub-page {{ background: transparent; }}

QTabWidget::pane {{ border: none; }}
QTabBar::tab {{ background: rgba(0,0,0,70); padding: 7px 16px; border-radius: 9px; margin-right: 4px; color: {MUTED}; }}
QTabBar::tab:selected {{ background: rgba(255,179,71,60); color: {TEXT}; }}
QMenu {{ background: {OPT_BG}; border: 1px solid rgba(255,255,255,50); padding: 4px; }}
QMenu::item {{ padding: 6px 22px; border-radius: 6px; }}
QMenu::item:selected {{ background: rgba(255,179,71,90); }}
"""
