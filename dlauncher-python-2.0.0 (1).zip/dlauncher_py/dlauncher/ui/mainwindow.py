"""Главное окно: фон, панель вкладок, страницы, уведомления, значок в трее."""
from __future__ import annotations

import importlib
import os
import traceback

from PySide6.QtCore import QEasingCurve, QPropertyAnimation, QRectF, Qt, QTimer, QUrl
from PySide6.QtGui import QAction, QColor, QIcon, QLinearGradient, QMovie, QPainter, QPixmap
from PySide6.QtWidgets import (QApplication, QFrame, QGraphicsOpacityEffect, QHBoxLayout, QLabel, QMainWindow,
                               QMenu, QPushButton, QStackedWidget, QSystemTrayIcon, QVBoxLayout, QWidget)

from ..resources import asset
from . import theme
from .widgets import button

# (ключ, подпись, модуль, класс) — страницы лежат в ui/pages/*.py и подгружаются по одной:
# если одна упадёт при создании, остальные работают, а ошибка попадает в launcher.log и в самопроверку.
PAGE_SPECS = [
    ("play", "Играть", "dlauncher.ui.pages.play", "PlayPage"),
    ("profiles", "Профили", "dlauncher.ui.pages.profiles", "ProfilesPage"),
    ("mods", "Моды", "dlauncher.ui.pages.mods", "ModsPage"),
    ("installed", "Установлено", "dlauncher.ui.pages.installed", "InstalledPage"),
    ("worlds", "Миры", "dlauncher.ui.pages.worlds", "WorldsPage"),
    ("skins", "Скины", "dlauncher.ui.pages.skins", "SkinsPage"),
    ("settings", "Настройки", "dlauncher.ui.pages.settings", "SettingsPage"),
]


class BackgroundWidget(QWidget):
    """Фон окна: своя картинка/GIF/видео или background.jpg + затемнение."""

    def __init__(self, app):
        super().__init__()
        self.app = app
        self._pix: QPixmap | None = None
        self._movie: QMovie | None = None
        self._player = None
        self._frame = None
        self._scaled_key = None
        self._scaled: QPixmap | None = None
        self._dim = 0
        self.reload()

    def reload(self) -> None:
        s = self.app.settings
        self._dim = int(s.get("bgDim") or 0)
        self._stop_media()
        path = s.get("bgUrl") or ""
        typ = s.get("bgType") or ""
        if path and os.path.exists(path):
            if typ == "video":
                self._start_video(path)
            elif path.lower().endswith(".gif"):
                self._movie = QMovie(path)
                self._movie.frameChanged.connect(lambda _=0: self.update())
                self._movie.start()
            else:
                self._pix = QPixmap(path)
        if not self._has_media() and (self._pix is None or self._pix.isNull()):
            self._pix = QPixmap(asset("background.jpg"))
        self._scaled_key = None
        self.update()

    def _has_media(self) -> bool:
        return self._movie is not None or self._player is not None

    def _stop_media(self) -> None:
        self._pix = None
        if self._movie is not None:
            self._movie.stop()
            self._movie = None
        if self._player is not None:
            try:
                self._player.stop()
            except Exception:  # noqa: BLE001
                pass
            self._player = None
        self._frame = None

    def _start_video(self, path: str) -> None:
        try:
            from PySide6.QtMultimedia import QMediaPlayer, QVideoSink
            self._player = QMediaPlayer(self)
            sink = QVideoSink(self)
            self._player.setVideoSink(sink)
            sink.videoFrameChanged.connect(self._on_frame)
            self._player.setSource(QUrl.fromLocalFile(path))
            self._player.setLoops(QMediaPlayer.Loops.Infinite)
            self._player.play()
        except Exception as e:  # noqa: BLE001
            self.app.ctx.diag(f"video background unavailable: {e}")
            self._player = None

    def _on_frame(self, frame) -> None:
        try:
            self._frame = frame.toImage()
            self.update()
        except Exception:  # noqa: BLE001
            pass

    def paintEvent(self, _):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        p.fillRect(self.rect(), QColor(theme.PAGE_BG))
        src = None
        if self._movie is not None:
            src = self._movie.currentPixmap()
        elif self._frame is not None:
            src = QPixmap.fromImage(self._frame)
        elif self._pix is not None:
            src = self._pix
        if src is not None and not src.isNull():
            w, h = self.width(), self.height()
            scaled = src.scaled(w, h, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
            p.drawPixmap((w - scaled.width()) // 2, (h - scaled.height()) // 2, scaled)
        if self._dim:
            p.fillRect(self.rect(), QColor(0, 0, 0, int(255 * self._dim / 100)))
        g = QLinearGradient(0, 0, 0, self.height())
        g.setColorAt(0.0, QColor(8, 6, 20, 140))
        g.setColorAt(0.22, QColor(8, 6, 20, 0))
        g.setColorAt(0.55, QColor(8, 6, 20, 0))
        g.setColorAt(1.0, QColor(8, 6, 20, 205))
        p.fillRect(self.rect(), g)
        p.end()


class Toast(QLabel):
    def __init__(self, parent):
        super().__init__(parent)
        self.setWordWrap(True)
        self.setAlignment(Qt.AlignCenter)
        self.hide()
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self.hide)

    def show_text(self, text: str, kind: str) -> None:
        color = {"ok": theme.OK, "err": theme.ERR, "warn": theme.WARN}.get(kind, theme.ACCENT)
        self.setStyleSheet(
            f"background: rgba(22,19,38,240); color: {theme.TEXT}; border: 1px solid {color};"
            "border-radius: 12px; padding: 10px 18px; font-weight: 600;")
        self.setText(text)
        self.setFixedWidth(min(560, max(240, self.parent().width() - 80)))
        self.adjustSize()
        self.move((self.parent().width() - self.width()) // 2, self.parent().height() - self.height() - 28)
        self.raise_()
        self.show()
        self._timer.start(4200 if kind != "err" else 7000)


class MainWindow(QMainWindow):
    def __init__(self, app, start_hidden: bool = False):
        super().__init__()
        self.app = app
        app.window = self
        self.pages: dict[str, QWidget] = {}
        self.page_errors: dict[str, str] = {}
        self._nav: dict[str, QPushButton] = {}
        self._quitting = False
        self.setWindowTitle("DLauncher")
        self.setWindowIcon(QIcon(asset("icon.png")))
        self.resize(1280, 760)
        self.setMinimumSize(1000, 600)

        self.bg = BackgroundWidget(app)
        self.setCentralWidget(self.bg)
        root = QVBoxLayout(self.bg)
        root.setContentsMargins(22, 14, 22, 18)
        root.setSpacing(12)

        # верхняя панель
        top = QHBoxLayout()
        logo = QLabel('D<span style="color:%s">Launcher</span>' % theme.ACCENT)
        logo.setStyleSheet("font-size: 24px; font-weight: 800; color: #fff;")
        top.addWidget(logo)
        top.addStretch(1)
        nav = QFrame()
        nav.setObjectName("navbar")
        nl = QHBoxLayout(nav)
        nl.setContentsMargins(5, 5, 5, 5)
        nl.setSpacing(4)
        top.addWidget(nav)
        top.addStretch(1)
        ver = QLabel("v" + app.ctx.app_version)
        ver.setProperty("kind", "muted")
        top.addWidget(ver)
        root.addLayout(top)

        self.stack = QStackedWidget()
        root.addWidget(self.stack, 1)

        for key, ru, mod, cls in PAGE_SPECS:
            b = button(app, ru, "nav", checkable=True)
            b.clicked.connect(lambda _=False, k=key: self.show_page(k))
            nl.addWidget(b)
            self._nav[key] = b
            self.stack.addWidget(self._make_page(key, mod, cls))

        self.toast_label = Toast(self.bg)
        app.lang_changed.connect(self._on_lang)
        app.settings_changed.connect(self._on_settings)
        self._apply_style()
        self._make_tray()
        app.event.connect(self._on_event)
        self.show_page("play")
        if start_hidden and self.tray is not None:
            self.hide()
        else:
            QTimer.singleShot(1500, self._offer_import)

    def _offer_import(self) -> None:
        """При первом запуске предлагаем перенести сборки из других лаунчеров."""
        if os.environ.get("DLAUNCHER_SELFTEST"):
            return
        try:
            from .dialogs.importer import maybe_show_on_start
            maybe_show_on_start(self.app)
        except Exception:  # noqa: BLE001
            self.app.ctx.diag(f"import offer: {traceback.format_exc()}")

    def _on_event(self, channel: str, payload) -> None:
        if channel == "app:quit":
            self.quit_app()
        elif channel == "update:status" and isinstance(payload, dict):
            self.app.last_update = payload
            if payload.get("state") == "ready":
                from .pages.settings import update_text
                self.app.toast(update_text(self.app, payload), "ok")

    # ---------- страницы ----------
    def _make_page(self, key: str, mod: str, cls: str) -> QWidget:
        try:
            m = importlib.import_module(mod)
            page = getattr(m, cls)(self.app)
            self.pages[key] = page
            return page
        except Exception:  # noqa: BLE001
            tb = traceback.format_exc()
            self.page_errors[key] = tb
            self.app.ctx.diag(f"page {key} failed: {tb}")
            ph = QLabel(f"Не удалось открыть вкладку «{key}».\nПодробности записаны в launcher.log.\n\n{tb.strip().splitlines()[-1]}")
            ph.setWordWrap(True)
            ph.setAlignment(Qt.AlignCenter)
            ph.setProperty("kind", "err")
            return ph

    def show_page(self, key: str) -> None:
        keys = [k for k, *_ in PAGE_SPECS]
        if key not in keys:
            return
        self.stack.setCurrentIndex(keys.index(key))
        for k, b in self._nav.items():
            b.setChecked(k == key)
        page = self.stack.currentWidget()
        fn = getattr(page, "on_show", None)
        if callable(fn):
            try:
                fn()
            except Exception:  # noqa: BLE001
                self.app.ctx.diag(f"on_show {key}: {traceback.format_exc()}")

    def current_key(self) -> str:
        return [k for k, *_ in PAGE_SPECS][self.stack.currentIndex()]

    # ---------- оформление ----------
    def _apply_style(self) -> None:
        s = self.app.settings
        QApplication.instance().setStyleSheet(theme.qss(bool(s.get("glass", True)), int(s.get("glassStrength", 60))))

    def _on_settings(self, _s) -> None:
        self._apply_style()
        self.bg.reload()
        self._sync_tray()

    def _on_lang(self) -> None:
        for page in self.pages.values():
            fn = getattr(page, "retranslate", None)
            if callable(fn):
                try:
                    fn()
                except Exception:  # noqa: BLE001
                    self.app.ctx.diag(f"retranslate: {traceback.format_exc()}")

    def show_toast(self, text: str, kind: str = "info") -> None:
        self.toast_label.show_text(text, kind)

    def resizeEvent(self, e):  # noqa: N802
        super().resizeEvent(e)
        if self.toast_label.isVisible():
            self.toast_label.move((self.width() - self.toast_label.width()) // 2,
                                  self.height() - self.toast_label.height() - 28)

    # ---------- трей ----------
    def _make_tray(self) -> None:
        self.tray = None
        if not QSystemTrayIcon.isSystemTrayAvailable():
            return
        t = QSystemTrayIcon(QIcon(asset("icon.png")), self)
        t.setToolTip("DLauncher")
        menu = QMenu()
        self._act_play = QAction(self.app.t("Играть"), menu)
        self._act_play.triggered.connect(lambda: (self.bring_to_front(), self.app.event.emit("tray:play", None)))
        self._act_show = QAction(self.app.t("Показать лаунчер"), menu)
        self._act_show.triggered.connect(self.bring_to_front)
        self._act_quit = QAction(self.app.t("Выход"), menu)
        self._act_quit.triggered.connect(self.quit_app)
        menu.addAction(self._act_play)
        menu.addAction(self._act_show)
        menu.addSeparator()
        menu.addAction(self._act_quit)
        t.setContextMenu(menu)
        t.activated.connect(lambda reason: self.bring_to_front() if reason in (
            QSystemTrayIcon.Trigger, QSystemTrayIcon.DoubleClick) else None)
        self.tray = t
        self._tray_menu = menu
        self._sync_tray()
        self.app.lang_changed.connect(lambda: (
            self._act_play.setText(self.app.t("Играть")), self._act_show.setText(self.app.t("Показать лаунчер")),
            self._act_quit.setText(self.app.t("Выход"))))

    def _sync_tray(self) -> None:
        if self.tray is None:
            return
        s = self.app.settings
        self.tray.setVisible(bool(s.get("closeToTray") or s.get("autoStart")))

    def bring_to_front(self) -> None:
        self.showNormal()
        self.raise_()
        self.activateWindow()

    def quit_app(self) -> None:
        self._quitting = True
        self.close()
        QApplication.quit()

    def closeEvent(self, e):  # noqa: N802
        if (not self._quitting and self.tray is not None and self.app.settings.get("closeToTray")):
            e.ignore()
            self.hide()
            return
        self._quitting = True
        super().closeEvent(e)
        QApplication.quit()
