"""Вкладка «Играть»: выбор профиля, запуск, прогресс, быстрый вход, статистика, новости, консоль."""
from __future__ import annotations

from PySide6.QtCore import QTimer, Qt
from PySide6.QtWidgets import QComboBox, QHBoxLayout, QLabel, QProgressBar, QVBoxLayout, QWidget

from .. import i18n
from ..widgets import Card, ClickLabel, VScroll, button, clear_layout, label
from ._profile_util import fmt_date, fmt_dur, get_page, loader_name, profile_label

i18n.register({
    "Играть": "Play",
    "Запуск...": "Starting...",
    "Игра запущена": "Game is running",
    "Выбранный профиль": "Selected profile",
    "Создать профиль": "Create a profile",
    "Сначала создай профиль": "Create a profile first",
    "Быстрый вход на сервер": "Quick join a server",
    "Последний сервер": "Last server",
    "Не заходить на сервер": "Don't join a server",
    "Статистика": "Statistics",
    "Всего сыграно": "Total playtime",
    "Запусков": "Launches",
    "Любимый профиль": "Favorite profile",
    "Новости Minecraft": "Minecraft news",
    "Обновить": "Refresh",
    "Консоль": "Console",
    "Загрузка...": "Loading...",
    "Профилей пока нет. Создай первый — это быстро.": "No profiles yet. Create your first one — it's quick.",
    "Игра завершилась с ошибкой": "The game crashed",
    "Разобрать причину": "Find the cause",
    "Закрыть": "Close",
    "Версия: {v} · {l}": "Version: {v} · {l}",
    "Последний запуск: {d}": "Last played: {d}",
    "Ни разу не запускался": "Never played",
    "Нет данных": "No data",
})


class PlayPage(QWidget):
    def __init__(self, app):
        super().__init__()
        self.app = app
        self.launching = False
        self._news_items: list[dict] = []
        self._servers: list[dict] = []
        self._last_server = None

        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(16)

        # ----- левая колонка: запуск
        left = QVBoxLayout()
        left.setSpacing(14)
        root.addLayout(left, 3)
        left.addStretch(1)
        title = label(app, None, "h1")
        title.setText('<span style="color:#ffb347">D</span>Launcher')
        title.setAlignment(Qt.AlignHCenter)
        left.addWidget(title)
        sub = label(app, "Лаунчер Minecraft", "muted")
        sub.setAlignment(Qt.AlignHCenter)
        left.addWidget(sub)

        card = Card()
        card.lay.addWidget(label(app, "Выбранный профиль", "h3"))
        self.combo = QComboBox()
        self.combo.currentIndexChanged.connect(self._combo_changed)
        card.lay.addWidget(self.combo)
        self.info = label(app, None, "muted", wrap=True)
        card.lay.addWidget(self.info)
        self.empty = label(app, "Профилей пока нет. Создай первый — это быстро.", "muted", wrap=True)
        card.lay.addWidget(self.empty)
        self.btn_create = button(app, "Создать профиль", "primary", self._open_create)
        card.lay.addWidget(self.btn_create)
        row = QHBoxLayout()
        row.addWidget(label(app, "Быстрый вход на сервер", "muted"))
        self.server_combo = QComboBox()
        row.addWidget(self.server_combo, 1)
        self.server_wrap = QWidget()
        self.server_wrap.setLayout(row)
        card.lay.addWidget(self.server_wrap)
        left.addWidget(card)

        self.play = button(app, "Играть", "play", self.start)
        left.addWidget(self.play, 0, Qt.AlignHCenter)
        self.status = label(app, None, "muted", wrap=True)
        self.status.setAlignment(Qt.AlignHCenter)
        left.addWidget(self.status)
        self.bar = QProgressBar()
        self.bar.setRange(0, 100)
        self.bar.setTextVisible(False)
        self.bar.setFixedHeight(8)
        self.bar.hide()
        left.addWidget(self.bar)
        btns = QHBoxLayout()
        btns.addStretch(1)
        btns.addWidget(button(app, "Консоль", "ghost", self._open_console))
        btns.addStretch(1)
        left.addLayout(btns)
        left.addStretch(2)

        # ----- правая колонка: статистика и новости
        right = VScroll()
        root.addWidget(right, 2)
        self.stats_card = Card()
        self.stats_card.lay.addWidget(label(app, "Статистика", "h3"))
        self.stats_body = QVBoxLayout()
        self.stats_card.lay.addLayout(self.stats_body)
        right.lay.addWidget(self.stats_card)
        self.news_card = Card()
        head = QHBoxLayout()
        head.addWidget(label(app, "Новости Minecraft", "h3"))
        head.addStretch(1)
        head.addWidget(button(app, "Обновить", "small", lambda: self.load_news(True)))
        self.news_card.lay.addLayout(head)
        self.news_body = QVBoxLayout()
        self.news_card.lay.addLayout(self.news_body)
        right.lay.addWidget(self.news_card)
        right.lay.addStretch(1)

        app.profiles_changed.connect(self.refresh)
        app.settings_changed.connect(lambda _s: self._fill_info())
        app.event.connect(self._on_event)
        self.refresh()
        QTimer.singleShot(1500, self.load_news)

    # ---------- события ядра ----------
    def _on_event(self, channel: str, payload):
        if channel == "game:status":
            self.status.setText(self.app.t(str(payload or "")))
        elif channel == "game:progress" and isinstance(payload, dict):
            total = int(payload.get("total") or 0)
            if total > 0:
                self.bar.show()
                self.bar.setValue(int(100 * int(payload.get("task") or 0) / total))
                lab = payload.get("label") or payload.get("type") or ""
                self.status.setText(f"{self.app.t('Загрузка...')} {lab} {payload.get('task', 0)}/{total}")
        elif channel == "game:closed" and isinstance(payload, dict):
            self._finished(payload)
        elif channel == "server:last":
            self.app.refresh_profiles()
        elif channel == "tray:play":
            self.start()

    def _finished(self, payload: dict) -> None:
        self.launching = False
        self.play.setEnabled(True)
        self.bar.hide()
        self.status.setText("")
        self.app.bind(self.play, "Играть")
        self.load_stats()
        code = payload.get("code")
        if code not in (0, None):
            self._offer_crash(payload)

    def _offer_crash(self, payload: dict) -> None:
        try:
            from ..dialogs.crash import CrashDialog
            CrashDialog(self.app, payload.get("profileId"), payload.get("code")).show()
        except Exception as e:  # noqa: BLE001
            self.app.ctx.diag(f"crash dialog: {e}")

    # ---------- профили ----------
    def refresh(self) -> None:
        app = self.app
        self.combo.blockSignals(True)
        self.combo.clear()
        for p in app.profiles:
            self.combo.addItem(profile_label(p), p["id"])
        idx = max(0, next((i for i, p in enumerate(app.profiles) if p["id"] == app.current_id), 0))
        if app.profiles:
            self.combo.setCurrentIndex(idx)
        self.combo.blockSignals(False)
        has = bool(app.profiles)
        self.combo.setVisible(has)
        self.info.setVisible(has)
        self.empty.setVisible(not has)
        self.btn_create.setVisible(not has)
        self.server_wrap.setVisible(has)
        self.play.setEnabled(has and not self.launching)
        self._fill_info()
        self.load_servers()

    def _combo_changed(self, _i) -> None:
        pid = self.combo.currentData()
        if pid and pid != self.app.current_id:
            self.app.call("profiles:select", pid, lambda _r: self.app.refresh_profiles(), lambda m: self.app.toast(m, "err"))

    def _fill_info(self) -> None:
        p = self.app.current_profile()
        if not p:
            self.info.setText("")
            return
        last = fmt_date(self.app, p.get("lastPlayed")) if p.get("lastPlayed") else None
        txt = self.app.t("Версия: {v} · {l}", v=p.get("version", ""), l=loader_name(p.get("loader", "vanilla")))
        txt += "\n" + (self.app.t("Последний запуск: {d}", d=last) if last else self.app.t("Ни разу не запускался"))
        self.info.setText(txt)

    def load_servers(self) -> None:
        p = self.app.current_profile()
        self.server_combo.clear()
        self.server_combo.addItem(self.app.t("Не заходить на сервер"), None)
        self._servers = []
        if not p:
            return

        def ok(r):
            if not isinstance(r, dict) or not r.get("ok"):
                return
            self._servers = r.get("servers") or []
            last = r.get("last")
            self.server_combo.clear()
            self.server_combo.addItem(self.app.t("Не заходить на сервер"), None)
            if last:
                self.server_combo.addItem(f"{self.app.t('Последний сервер')}: {last['host']}:{last['port']}", {"host": last["host"], "port": last["port"]})
            for s in self._servers:
                self.server_combo.addItem(f"{'★ ' if s.get('favorite') else ''}{s['name']} ({s['host']}:{s['port']})", {"host": s["host"], "port": s["port"]})
        self.app.call("servers:list", {"profileId": p["id"]}, ok, lambda m: None)

    # ---------- запуск ----------
    def _open_create(self) -> None:
        self.app.show_page("profiles")
        page = get_page(self.app, "profiles")
        fn = getattr(page, "open_create", None)
        if callable(fn):
            fn()

    def start(self) -> None:
        if self.launching:
            return
        p = self.app.current_profile()
        if not p:
            self.app.toast("Сначала создай профиль", "warn")
            self._open_create()
            return
        try:
            from ..dialogs.compat import pre_launch_check
        except Exception:  # noqa: BLE001
            pre_launch_check = None
        if pre_launch_check is None:
            self._do_launch(p)
        else:
            pre_launch_check(self.app, p, lambda: self._do_launch(p))

    def _do_launch(self, p: dict) -> None:
        if self.launching:
            return
        self.launching = True
        self.play.setEnabled(False)
        self.app.bind(self.play, "Запуск...")
        self.bar.hide()
        payload = {"profileId": p["id"]}
        server = self.server_combo.currentData()
        if server:
            payload.update(quickJoin=True, server=server)

        def ok(r):
            if isinstance(r, dict) and r.get("ok"):
                self.app.bind(self.play, "Игра запущена")
                self.bar.hide()
                self.app.refresh_profiles()
                return
            self._failed((r or {}).get("error") or "Не удалось запустить игру")

        self.app.call("game:launch", payload, ok, self._failed)

    def _failed(self, msg: str) -> None:
        self.launching = False
        self.play.setEnabled(bool(self.app.profiles))
        self.app.bind(self.play, "Играть")
        self.bar.hide()
        self.status.setText("")
        self.app.toast(msg, "err")

    # ---------- статистика ----------
    def on_show(self) -> None:
        self.load_stats()

    def load_stats(self) -> None:
        def ok(r):
            clear_layout(self.stats_body)
            if not isinstance(r, dict) or not r.get("ok"):
                return
            total = r.get("total") or {}
            if not total.get("launches") and not total.get("ms"):
                self.stats_body.addWidget(label(self.app, "Нет данных", "muted"))
                return
            self.stats_body.addWidget(self._kv("Всего сыграно", fmt_dur(self.app, total.get("ms"))))
            self.stats_body.addWidget(self._kv("Запусков", str(total.get("launches", 0))))
            top = next((i for i in r.get("items") or [] if i["id"] == r.get("top")), None)
            if top:
                self.stats_body.addWidget(self._kv("Любимый профиль", str(top["name"])))
        self.app.call("stats:get", None, ok, lambda m: None)

    def _kv(self, k_ru: str, v: str) -> QWidget:
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        h.addWidget(label(self.app, k_ru, "muted"))
        h.addStretch(1)
        vl = QLabel(v)
        vl.setProperty("kind", "accent")
        h.addWidget(vl)
        return w

    # ---------- новости ----------
    def load_news(self, force: bool = False) -> None:
        clear_layout(self.news_body)
        self.news_body.addWidget(label(self.app, "Загрузка...", "muted"))

        def ok(r):
            clear_layout(self.news_body)
            if not isinstance(r, dict) or not r.get("ok"):
                lb = label(self.app, None, "muted", wrap=True)
                lb.setText(self.app.t((r or {}).get("error") or "Не удалось загрузить новости."))
                self.news_body.addWidget(lb)
                return
            self._news_items = r["items"]
            for it in self._news_items[:8]:
                self.news_body.addWidget(self._news_row(it))

        def err(m):
            clear_layout(self.news_body)
            lb = label(self.app, None, "muted", wrap=True)
            lb.setText(m)
            self.news_body.addWidget(lb)
        self.app.call("news:list", {"force": force}, ok, err)

    def _news_row(self, it: dict) -> QWidget:
        w = Card("soft", margins=(12, 8, 12, 8), spacing=2)
        t = ClickLabel(it["title"])
        t.setProperty("kind", "accent")
        t.setCursor(Qt.PointingHandCursor)
        t.setWordWrap(True)
        t.clicked.connect(lambda i=it: self._read_news(i))
        w.lay.addWidget(t)
        if it.get("text"):
            d = QLabel(it["text"][:140])
            d.setProperty("kind", "muted")
            d.setWordWrap(True)
            w.lay.addWidget(d)
        return w

    def _read_news(self, it: dict) -> None:
        from ..widgets import Modal

        def ok(r):
            dlg = Modal(self.app, it["title"], width=640, height=480)
            dlg.title.setText(it["title"])
            from PySide6.QtWidgets import QPlainTextEdit
            te = QPlainTextEdit()
            te.setReadOnly(True)
            te.setPlainText((r or {}).get("body") or (r or {}).get("error") or "")
            dlg.body.addWidget(te, 1)
            dlg.add_button("Закрыть", "primary", close=True)
            dlg.exec()
        self.app.call("news:read", {"id": it["id"]}, ok, lambda m: self.app.toast(m, "err"))

    def _open_console(self) -> None:
        from ..dialogs.console import ConsoleDialog
        dlg = ConsoleDialog(self.app)
        dlg.show()
        self._console = dlg

    def retranslate(self) -> None:
        self.refresh()
        self.load_news()
        self.load_stats()

    def selftest(self) -> None:
        from ..dialogs.console import ConsoleDialog
        ConsoleDialog(self.app)
        try:
            from ..dialogs.crash import CrashDialog
            CrashDialog(self.app, None, 1)
        except ImportError:
            raise
