// Возможности версии 1.7: статистика, новости, консоль, разбор вылета, миры и копии, скриншоты,
// скины с 3D-просмотром, экспорт/импорт профиля. Подключается после renderer.js и пользуется его
// общими функциями ($, api, esc, cur, fmtSize, fmtDate, showView, loadProfiles ...).
(function () {
  'use strict';

  const fmtDur = (ms) => {
    const m = Math.floor(ms / 60000);
    if (m < 1) return 'меньше минуты';
    const h = Math.floor(m / 60);
    return h ? `${h} ч ${m % 60} мин` : `${m} мин`;
  };
  const dateTime = (t) => (t ? new Date(t).toLocaleString(I18N.locale(), { dateStyle: 'short', timeStyle: 'short' }) : '—');
  // «a · b · c» из отдельных элементов: каждый кусок переводится сам по себе
  const meta = (parts) => parts.filter(Boolean).map((x) => `<span>${esc(x)}</span>`).join(' · ');
  // кнопка с подтверждением вторым нажатием
  function twoClick(btn, label, action) {
    btn.onclick = () => {
      if (btn.dataset.sure !== '1') {
        btn.dataset.sure = '1';
        btn.textContent = 'Точно?';
        setTimeout(() => { btn.dataset.sure = ''; btn.textContent = label; }, 3000);
        return;
      }
      action();
    };
  }
  const viewActive = (name) => $('view-' + name).classList.contains('active');

  // ====================== СТАТИСТИКА ======================
  async function loadStats() {
    const box = $('stats-body');
    let r;
    try {
      r = await api.invoke('stats:get');
    } catch {
      return;
    }
    if (!r || !r.ok || !r.total || !r.total.launches) {
      box.className = 'muted';
      box.textContent = 'Пока нет данных: сыграй хотя бы раз.';
      return;
    }
    const items = Array.isArray(r.items) ? r.items : [];
    const max = Math.max(1, ...items.map((i) => i.ms));
    box.className = '';
    box.innerHTML =
      `<div class="stat-sub">Всего сыграно</div><div class="stat-total">${esc(fmtDur(r.total.ms))}</div>` +
      `<div class="stat-sub">Запусков: ${r.total.launches}</div>` +
      items.slice(0, 5).map((i) =>
        `<div class="stat-row"><span class="n">${esc(i.name)}${r.playing === i.id ? ' ▶' : ''}</span><span>${esc(fmtDur(i.ms))}</span><div class="bar"><i style="width:${Math.round((i.ms / max) * 100)}%"></i></div></div>`
      ).join('');
  }
  setInterval(() => { if (viewActive('play') && !document.hidden) loadStats(); }, 60000);

  // ====================== НОВОСТИ ======================
  let newsLoaded = false;
  async function loadNews(force) {
    const box = $('news-list');
    if (!newsLoaded || force) box.innerHTML = '<p class="muted">Загрузка...</p>';
    let r;
    try {
      r = await api.invoke('news:list', { force: !!force });
    } catch {
      r = { ok: false, error: 'Не удалось загрузить новости. Проверь подключение к интернету.' };
    }
    if (!r.ok) {
      newsLoaded = false;
      box.innerHTML = `<p class="muted">${esc(r.error)}</p>`;
      return;
    }
    newsLoaded = true;
    box.innerHTML = '';
    (r.items || []).slice(0, 12).forEach((it) => {
      const b = document.createElement('button');
      b.className = 'news-item';
      b.innerHTML =
        `<span class="t">${esc(it.title)}</span>` +
        (it.text ? `<span class="d">${esc(it.text)}</span>` : '') +
        `<span class="m">${meta([it.type === 'snapshot' ? 'Снапшот' : 'Релиз', it.date ? fmtDate(it.date) : ''])}</span>`;
      b.onclick = () => openNews(it);
      box.appendChild(b);
    });
  }
  async function openNews(it) {
    $('news-title').textContent = it.title;
    $('news-date').textContent = it.date ? fmtDate(it.date) : '';
    $('news-body').textContent = 'Загрузка...';
    $('news-modal').classList.remove('hidden');
    let r;
    try {
      r = await api.invoke('news:read', { id: it.id });
    } catch {
      r = { ok: false, error: 'Не удалось загрузить новости. Проверь подключение к интернету.' };
    }
    $('news-body').textContent = r.ok ? r.body || it.text || '—' : r.error;
  }
  $('news-refresh').onclick = () => loadNews(true);
  $('news-close').onclick = () => $('news-modal').classList.add('hidden');
  $('news-modal').onclick = (e) => { if (e.target === $('news-modal')) $('news-modal').classList.add('hidden'); };

  // ====================== КОНСОЛЬ ======================
  const CON_MAX = 3000;
  function conNode(l) {
    const d = document.createElement('div');
    d.textContent = l.t;
    if (l.s === 'l') d.className = 'l';
    else if (/\bERROR\b|\bFATAL\b|Exception|^\s+at\s/.test(l.t)) d.className = 'e';
    else if (/\bWARN\b/.test(l.t)) d.className = 'w';
    return d;
  }
  function conCount() {
    const n = $('con-log').children.length;
    $('con-count').textContent = n ? `Строк: ${n}` : '';
  }
  function conAppend(lines) {
    const log = $('con-log');
    const frag = document.createDocumentFragment();
    lines.forEach((l) => frag.appendChild(conNode(l)));
    log.appendChild(frag);
    while (log.children.length > CON_MAX) log.removeChild(log.firstChild);
    conCount();
    if ($('con-follow').checked) log.scrollTop = log.scrollHeight;
  }
  async function openConsole() {
    $('con-modal').classList.remove('hidden');
    $('con-log').innerHTML = '';
    const r = await api.invoke('console:get');
    if (r && Array.isArray(r.lines) && r.lines.length) conAppend(r.lines);
    else $('con-log').innerHTML = '<div class="l">Консоль пуста: запусти игру, и здесь появится её вывод.</div>';
    conCount();
  }
  api.on('console:lines', (lines) => {
    if ($('con-modal').classList.contains('hidden') || !Array.isArray(lines)) return;
    const log = $('con-log');
    if (log.firstChild && log.firstChild.classList.contains('l') && log.children.length === 1 && /пуста/.test(log.firstChild.textContent)) log.innerHTML = '';
    conAppend(lines);
  });
  api.on('console:reset', () => { $('con-log').innerHTML = ''; conCount(); });
  $('btn-console').onclick = openConsole;
  $('con-close').onclick = () => $('con-modal').classList.add('hidden');
  $('con-modal').onclick = (e) => { if (e.target === $('con-modal')) $('con-modal').classList.add('hidden'); };
  $('con-clear').onclick = () => api.invoke('console:clear');
  $('con-copy').onclick = async () => {
    const r = await api.invoke('console:copy');
    $('con-copy').textContent = r && r.ok ? 'Скопировано ✓' : 'Копировать всё';
    setTimeout(() => { $('con-copy').textContent = 'Копировать всё'; }, 1800);
  };
  $('con-log').addEventListener('scroll', () => {
    const el = $('con-log');
    $('con-follow').checked = el.scrollHeight - el.scrollTop - el.clientHeight < 40;
  });

  // ====================== РАЗБОР ВЫЛЕТА ======================
  let crashProfile = null;
  function showCrash(res, r) {
    crashProfile = res.profileId;
    $('crash-title').textContent = `Игра завершилась с ошибкой (код ${res.code})`;
    $('crash-summary').textContent = r.summary || '';
    const list = $('crash-list');
    list.innerHTML = '';
    r.findings.forEach((f) => {
      const box = document.createElement('div');
      box.className = 'crash-item';
      box.innerHTML = `<b>${esc(f.title)}</b><p>${esc(f.text)}</p>` + (f.mods && f.mods.length ? `<div class="mods">${esc(f.mods.join(', '))}</div>` : '');
      const row = document.createElement('div');
      row.className = 'row';
      const add = (label, fn) => {
        const b = document.createElement('button');
        b.className = 'btn ghost small';
        b.textContent = label;
        b.onclick = () => { $('crash-modal').classList.add('hidden'); fn(); };
        row.appendChild(b);
      };
      if (f.action === 'ram') add('Настроить память профиля', () => { const p = profiles.find((x) => x.id === crashProfile); showView('profiles'); if (p) openProfileEdit(p); });
      if (f.action === 'java') add('Открыть настройки Java', () => showView('settings'));
      if (f.mods && f.mods.length) add('Открыть моды профиля', () => { selectProfile(crashProfile).then(() => showView('installed')); });
      if (row.children.length) box.appendChild(row);
      list.appendChild(box);
    });
    $('crash-report').classList.toggle('hidden', !r.hasReport);
    $('crash-modal').classList.remove('hidden');
  }
  $('crash-close').onclick = () => $('crash-modal').classList.add('hidden');
  $('crash-modal').onclick = (e) => { if (e.target === $('crash-modal')) $('crash-modal').classList.add('hidden'); };
  $('crash-console').onclick = () => { $('crash-modal').classList.add('hidden'); openConsole(); };
  $('crash-report').onclick = () => api.invoke('crash:open', { profileId: crashProfile });

  window.onGameClosed = async (res) => {
    loadStats();
    const code = res.code;
    if (typeof code !== 'number' || code === 0) return;
    let r;
    try {
      r = await api.invoke('crash:analyze', { profileId: res.profileId, code });
    } catch {
      return;
    }
    if (!r || !r.ok || r.empty || !Array.isArray(r.findings)) return;
    // если причину определить не удалось и отчёта о вылете нет, окно не показываем: пользователь мог просто закрыть игру
    if (!r.hasReport && !r.findings.some((f) => f.id !== 'unknown')) return;
    showCrash(res, r);
  };

  // ====================== МИРЫ / КОПИИ / СКРИНШОТЫ ======================
  let wrTab = 'worlds';
  let wrData = null;
  let shotItems = [];
  let shotIdx = -1;

  function wrInfo(text) { $('wr-info').textContent = text; }

  async function loadWorlds() {
    const p = cur();
    const list = $('wr-list');
    const grid = $('wr-shots');
    if (!p) {
      wrInfo('');
      grid.classList.add('hidden');
      list.classList.remove('hidden');
      list.innerHTML = '<p class="muted">Сначала создай профиль во вкладке «Профили».</p>';
      return;
    }
    document.querySelectorAll('#wr-seg .seg-btn').forEach((b) => b.classList.toggle('active', b.dataset.wr === wrTab));
    wrInfo(profileLabel(p));
    if (wrTab === 'shots') {
      list.classList.add('hidden');
      grid.classList.remove('hidden');
      return loadShots(p);
    }
    grid.classList.add('hidden');
    list.classList.remove('hidden');
    const r = await api.invoke('worlds:list', { profileId: p.id });
    if (!r.ok) { list.innerHTML = `<p class="muted">${esc(r.error)}</p>`; return; }
    wrData = r;
    if (r.running) wrInfo(`${profileLabel(p)} · Игра запущена: восстановление копий недоступно`);
    wrTab === 'backups' ? renderBackups(r) : renderWorlds(r);
  }

  function renderWorlds(r) {
    const box = $('wr-list');
    if (!r.worlds.length) {
      box.innerHTML = '<p class="muted">В этом профиле пока нет миров. Они появятся после первой игры.</p>';
      return;
    }
    box.innerHTML = '';
    r.worlds.forEach((w) => {
      const row = document.createElement('div');
      row.className = 'inst-row';
      row.innerHTML = `
        <div class="ph">${esc((w.name || '?').trim().charAt(0).toUpperCase())}</div>
        <div class="info">
          <div class="name">${esc(w.name)}</div>
          <div class="meta">${meta([w.version ? 'Minecraft ' + w.version : '', fmtSize(w.size), 'Игра: ' + dateTime(w.lastPlayed), w.backups ? `Копий: ${w.backups}` : 'Копий нет'])}</div>
        </div>
        <button class="btn" data-act="backup">Сделать копию</button>`;
      const b = row.querySelector('button');
      b.onclick = async () => {
        b.disabled = true;
        const res = await api.invoke('worlds:backup', { profileId: wrData.profile.id, folder: w.folder });
        await loadWorlds();
        wrInfo(res.ok ? `Копия создана: ${res.file}` : res.error);
        if (res.ok && res.warning) wrInfo(res.warning);
      };
      box.appendChild(row);
    });
  }

  function renderBackups(r) {
    const box = $('wr-list');
    if (!r.backups.length) {
      box.innerHTML = '<p class="muted">Резервных копий пока нет. Их можно сделать вручную на вкладке «Миры» или включить автоматические копии в настройках.</p>';
      return;
    }
    box.innerHTML = '';
    r.backups.forEach((bk) => {
      const row = document.createElement('div');
      row.className = 'inst-row';
      row.innerHTML = `
        <div class="ph">${esc((bk.world || '?').trim().charAt(0).toUpperCase())}</div>
        <div class="info">
          <div class="name">${esc(bk.world)}</div>
          <div class="meta">${meta([dateTime(bk.time), fmtSize(bk.size)])}</div>
        </div>
        <button class="btn" data-act="restore">Восстановить</button>
        <button class="btn ghost danger" data-act="delete">Удалить</button>`;
      const restore = row.querySelector('[data-act="restore"]');
      restore.disabled = !!r.running;
      restore.title = 'Мир распакуется как новый — существующие миры не затрагиваются';
      restore.onclick = async () => {
        restore.disabled = true;
        const res = await api.invoke('worlds:restore', { profileId: r.profile.id, file: bk.file });
        await loadWorlds();
        wrInfo(res.ok ? `Мир восстановлен как «${res.folder}»` : res.error);
      };
      twoClick(row.querySelector('[data-act="delete"]'), 'Удалить', async () => {
        const res = await api.invoke('worlds:remove-backup', { profileId: r.profile.id, file: bk.file });
        await loadWorlds();
        if (!res.ok) wrInfo(res.error);
      });
      box.appendChild(row);
    });
  }

  api.on('worlds:progress', ({ text }) => {
    if (viewActive('worlds')) wrInfo(text);
    if ($('btn-play').disabled) $('status').textContent = text;
  });

  async function loadShots(p) {
    const grid = $('wr-shots');
    const r = await api.invoke('shots:list', { profileId: p.id });
    if (!r.ok) { grid.innerHTML = `<p class="muted">${esc(r.error)}</p>`; return; }
    shotItems = r.items;
    wrInfo(r.total ? `${profileLabel(p)} · Скриншотов: ${r.total}` : profileLabel(p));
    if (!r.items.length) {
      grid.innerHTML = '<p class="muted">Скриншотов пока нет. В игре они делаются клавишей F2.</p>';
      return;
    }
    grid.innerHTML = '';
    r.items.forEach((it, i) => {
      const b = document.createElement('button');
      b.className = 'shot';
      b.title = it.file;
      const img = document.createElement('img');
      img.loading = 'lazy';
      img.alt = '';
      img.src = it.url;
      b.appendChild(img);
      b.onclick = () => openShot(i);
      grid.appendChild(b);
    });
  }

  function openShot(i) {
    if (!shotItems.length) return $('shot-modal').classList.add('hidden');
    shotIdx = (i + shotItems.length) % shotItems.length;
    const it = shotItems[shotIdx];
    $('shot-img').src = it.url;
    $('shot-name').textContent = `${it.file} · ${fmtSize(it.size)} · ${dateTime(it.time)}`;
    $('shot-modal').classList.remove('hidden');
    $('shot-del').textContent = 'Удалить';
    $('shot-del').dataset.sure = '';
  }
  const shotArgs = () => ({ profileId: cur() && cur().id, file: shotItems[shotIdx] && shotItems[shotIdx].file });
  $('shot-prev').onclick = () => openShot(shotIdx - 1);
  $('shot-next').onclick = () => openShot(shotIdx + 1);
  $('shot-close').onclick = () => $('shot-modal').classList.add('hidden');
  $('shot-modal').onclick = (e) => { if (e.target === $('shot-modal')) $('shot-modal').classList.add('hidden'); };
  $('shot-open').onclick = () => api.invoke('shots:open', shotArgs());
  $('shot-copy').onclick = async () => {
    const r = await api.invoke('shots:copy', shotArgs());
    $('shot-copy').textContent = r.ok ? 'Скопировано ✓' : 'Ошибка';
    setTimeout(() => { $('shot-copy').textContent = 'Копировать'; }, 1500);
  };
  twoClick($('shot-del'), 'Удалить', async () => {
    const r = await api.invoke('shots:delete', shotArgs());
    if (!r.ok) { wrInfo(r.error); return; }
    const at = shotIdx;
    shotItems.splice(at, 1);
    if (shotItems.length) openShot(Math.min(at, shotItems.length - 1));
    else $('shot-modal').classList.add('hidden');
    await loadWorlds();
  });

  document.querySelectorAll('#wr-seg .seg-btn').forEach((b) => {
    b.onclick = () => { wrTab = b.dataset.wr; loadWorlds(); };
  });
  $('wr-refresh').onclick = () => loadWorlds();
  $('wr-folder').onclick = () => api.invoke('folder:open', wrTab === 'worlds' ? 'saves' : wrTab === 'backups' ? 'backups' : 'screenshots');

  // ====================== СКИНЫ (3D-просмотр) ======================
  const S = 9; // пикселей на пиксель текстуры
  const FACES = ['front', 'back', 'right', 'left', 'top', 'bottom'];

  // Прямоугольники граней коробки w×h×d, текстура которой начинается в (u, v)
  function faceRects(u, v, w, h, d) {
    return {
      top: [u + d, v, w, d],
      bottom: [u + d + w, v, w, d],
      right: [u, v + d, d, h],
      front: [u + d, v + d, w, h],
      left: [u + d + w, v + d, d, h],
      back: [u + 2 * d + w, v + d, w, h],
    };
  }

  // Старые скины 64×32: левые руку и ногу берём зеркально из правых
  function normalizeSkin(img) {
    const c = document.createElement('canvas');
    c.width = 64;
    c.height = 64;
    const x = c.getContext('2d');
    x.imageSmoothingEnabled = false;
    x.drawImage(img, 0, 0);
    if (img.height === 32 || img.naturalHeight === 32) {
      const mirror = (u1, v1, u2, v2) => {
        const from = faceRects(u1, v1, 4, 12, 4);
        const to = faceRects(u2, v2, 4, 12, 4);
        const swap = { right: 'left', left: 'right' };
        FACES.forEach((f) => {
          const [sx, sy, sw, sh] = from[swap[f] || f];
          const [dx, dy] = to[f];
          x.save();
          x.translate(dx + sw, dy);
          x.scale(-1, 1);
          x.drawImage(c, sx, sy, sw, sh, 0, 0, sw, sh);
          x.restore();
        });
      };
      mirror(40, 16, 32, 48); // рука
      mirror(0, 16, 16, 48); // нога
    }
    return c;
  }

  function placeholderSkin() {
    const c = document.createElement('canvas');
    c.width = 64;
    c.height = 64;
    const x = c.getContext('2d');
    const fill = (rects, color) => FACES.forEach((f) => { x.fillStyle = color; x.fillRect(...rects[f]); });
    fill(faceRects(0, 0, 8, 8, 8), '#c68a62');
    fill(faceRects(16, 16, 8, 12, 4), '#3d8f9a');
    fill(faceRects(40, 16, 4, 12, 4), '#c68a62');
    fill(faceRects(32, 48, 4, 12, 4), '#c68a62');
    fill(faceRects(0, 16, 4, 12, 4), '#3b3a8c');
    fill(faceRects(16, 48, 4, 12, 4), '#3b3a8c');
    x.fillStyle = '#4a2e1a';
    x.fillRect(8, 8, 8, 2); // волосы над лицом
    x.fillStyle = '#fff';
    x.fillRect(9, 12, 2, 1); x.fillRect(13, 12, 2, 1);
    x.fillStyle = '#5b3a8a';
    x.fillRect(10, 12, 1, 1); x.fillRect(13, 12, 1, 1);
    return c;
  }

  function makeBox(src, u, v, w, h, d, cx, cy, grow) {
    const W = (w + grow) * S, H = (h + grow) * S, D = (d + grow) * S;
    const box = document.createElement('div');
    box.className = 'sk-box';
    box.style.cssText = `width:${W}px;height:${H}px;left:${(cx * S) - W / 2}px;top:${(cy * S) - H / 2}px;`;
    const rects = faceRects(u, v, w, h, d);
    const geo = {
      front: [W, H, 0, 0, `translateZ(${D / 2}px)`],
      back: [W, H, 0, 0, `rotateY(180deg) translateZ(${D / 2}px)`],
      right: [D, H, (W - D) / 2, 0, `rotateY(-90deg) translateZ(${W / 2}px)`],
      left: [D, H, (W - D) / 2, 0, `rotateY(90deg) translateZ(${W / 2}px)`],
      top: [W, D, 0, (H - D) / 2, `rotateX(90deg) translateZ(${H / 2}px)`],
      bottom: [W, D, 0, (H - D) / 2, `rotateX(-90deg) translateZ(${H / 2}px)`],
    };
    let any = false;
    FACES.forEach((f) => {
      const [sx, sy, sw, sh] = rects[f];
      const cv = document.createElement('canvas');
      cv.width = sw;
      cv.height = sh;
      const cc = cv.getContext('2d');
      cc.imageSmoothingEnabled = false;
      cc.drawImage(src, sx, sy, sw, sh, 0, 0, sw, sh);
      if (grow) {
        // слой одежды: если грань пустая, её не добавляем
        const data = cc.getImageData(0, 0, sw, sh).data;
        let has = false;
        for (let i = 3; i < data.length; i += 4) if (data[i] > 0) { has = true; break; }
        if (!has) return;
      }
      any = true;
      const [gw, gh, gl, gt, tr] = geo[f];
      cv.style.cssText = `width:${gw}px;height:${gh}px;left:${gl}px;top:${gt}px;transform:${tr};`;
      box.appendChild(cv);
    });
    return any ? box : null;
  }

  function buildChar(host, img, slim) {
    host.innerHTML = '';
    const skin = normalizeSkin(img);
    const aw = slim ? 3 : 4;
    const parts = [
      // [база u, v], [слой u, v], w, h, d, центр x, y, расширение слоя
      [[0, 0], [32, 0], 8, 8, 8, 0, -12, 1],
      [[16, 16], [16, 32], 8, 12, 4, 0, -2, 0.5],
      [[40, 16], [40, 32], aw, 12, 4, -(4 + aw / 2), -2, 0.5],
      [[32, 48], [48, 48], aw, 12, 4, 4 + aw / 2, -2, 0.5],
      [[0, 16], [0, 32], 4, 12, 4, -2, 10, 0.5],
      [[16, 48], [0, 48], 4, 12, 4, 2, 10, 0.5],
    ];
    parts.forEach(([base, layer, w, h, d, cx, cy, grow]) => {
      const a = makeBox(skin, base[0], base[1], w, h, d, cx, cy, 0);
      if (a) host.appendChild(a);
      const b = makeBox(skin, layer[0], layer[1], w, h, d, cx, cy, grow);
      if (b) host.appendChild(b);
    });
  }

  let skAngle = -28;
  let skDrag = null;
  let skRaf = 0;
  const skApply = () => { $('sk-char').style.transform = `rotateX(-10deg) rotateY(${skAngle}deg)`; };
  function skLoop() {
    if (!viewActive('skins')) { skRaf = 0; return; }
    if (!skDrag) { skAngle += 0.45; skApply(); }
    skRaf = requestAnimationFrame(skLoop);
  }
  const stage = $('sk-stage');
  stage.addEventListener('pointerdown', (e) => { skDrag = { x: e.clientX, a: skAngle }; stage.setPointerCapture(e.pointerId); });
  stage.addEventListener('pointermove', (e) => { if (skDrag) { skAngle = skDrag.a + (e.clientX - skDrag.x) * 0.8; skApply(); } });
  const skEnd = () => { skDrag = null; };
  stage.addEventListener('pointerup', skEnd);
  stage.addEventListener('pointercancel', skEnd);

  let skState = null; // ответ skins:get
  let skPending = null; // выбранный, но ещё не применённый файл
  let skVariant = 'classic';

  function skDraw(dataUrl, slim) {
    const done = (img) => buildChar($('sk-char'), img, slim);
    if (!dataUrl) return done(placeholderSkin());
    const img = new Image();
    img.onload = () => done(img);
    img.onerror = () => done(placeholderSkin());
    img.src = dataUrl;
  }

  function skSetVariant(v) {
    skVariant = v;
    document.querySelectorAll('#sk-variant .seg-btn').forEach((b) => b.classList.toggle('active', b.dataset.variant === v));
  }

  function renderCapes(state) {
    const box = $('sk-capes');
    box.innerHTML = '';
    const none = document.createElement('button');
    none.className = 'sk-cape' + (state.capes.some((c) => c.active) ? '' : ' on');
    none.textContent = 'Без плаща';
    none.onclick = () => setCape('');
    box.appendChild(none);
    state.capes.forEach((c) => {
      const b = document.createElement('button');
      b.className = 'sk-cape' + (c.active ? ' on' : '');
      const cv = document.createElement('canvas');
      cv.width = 10;
      cv.height = 16;
      b.appendChild(cv);
      const t = document.createElement('span');
      t.textContent = c.name;
      b.appendChild(t);
      if (c.image) {
        const im = new Image();
        im.onload = () => {
          const k = im.naturalWidth / 64; // у HD-плащей текстура больше
          const x = cv.getContext('2d');
          x.imageSmoothingEnabled = false;
          x.drawImage(im, k, k, 10 * k, 16 * k, 0, 0, 10, 16);
        };
        im.src = c.image;
      }
      b.onclick = () => setCape(c.id);
      box.appendChild(b);
    });
    if (!state.capes.length) {
      const h = document.createElement('p');
      h.className = 'hint';
      h.textContent = 'На этом аккаунте нет плащей.';
      box.appendChild(h);
    }
  }

  function skRender() {
    const s = skState;
    $('sk-name').textContent = s.name || '';
    $('sk-pending').classList.toggle('hidden', !skPending);
    if (skPending) $('sk-pending-name').textContent = `Выбран файл: ${skPending.name}${skPending.legacy ? ' (старый формат 64×32)' : ''}`;
    skDraw(skPending ? skPending.image : s.skin, skVariant === 'slim');
    renderCapes(s);
  }

  async function loadSkins() {
    $('sk-msg').textContent = 'Загрузка...';
    $('sk-body').classList.add('hidden');
    let r;
    try {
      r = await api.invoke('skins:get');
    } catch (err) {
      r = { ok: false, error: String(err.message || err) };
    }
    if (!r.ok) { $('sk-msg').textContent = r.error; return; }
    skState = r;
    skPending = null;
    skSetVariant(r.variant);
    $('sk-msg').textContent = '';
    $('sk-body').classList.remove('hidden');
    skRender();
    if (!skRaf) skRaf = requestAnimationFrame(skLoop);
  }
  const skFail = (r) => { $('sk-msg').textContent = r.error || ''; };
  const skUpdate = (r) => {
    if (!r.ok) return skFail(r);
    skState = r;
    skPending = null;
    skSetVariant(r.variant);
    $('sk-msg').textContent = '';
    skRender();
  };
  async function setCape(id) { skUpdate(await api.invoke('skins:cape', { id })); }

  $('sk-choose').onclick = async () => {
    const r = await api.invoke('skins:choose');
    if (r.canceled) return;
    if (!r.ok) return skFail(r);
    $('sk-msg').textContent = '';
    skPending = r;
    skRender();
  };
  $('sk-apply').onclick = async () => {
    $('sk-apply').disabled = true;
    $('sk-msg').textContent = 'Отправляю скин...';
    const r = await api.invoke('skins:apply', { variant: skVariant });
    $('sk-apply').disabled = false;
    skUpdate(r);
    if (r.ok) $('sk-msg').textContent = 'Скин обновлён ✓';
  };
  $('sk-cancel').onclick = async () => {
    await api.invoke('skins:discard');
    skPending = null;
    skRender();
  };
  twoClick($('sk-reset'), 'Вернуть стандартный', async () => skUpdate(await api.invoke('skins:reset')));
  document.querySelectorAll('#sk-variant .seg-btn').forEach((b) => {
    b.onclick = () => { skSetVariant(b.dataset.variant); if (skState) skRender(); };
  });

  // ====================== ЭКСПОРТ / ИМПОРТ ПРОФИЛЯ ======================
  window.exportProfile = async (p, btn) => {
    btn.disabled = true;
    $('pf-status').textContent = 'Экспорт профиля...';
    const r = await api.invoke('profile:export', { profileId: p.id });
    btn.disabled = false;
    if (r.canceled) { $('pf-status').textContent = ''; return; }
    $('pf-status').textContent = r.ok
      ? `Профиль сохранён: ${r.file} · по ссылкам Modrinth: ${r.linked}, внутри архива: ${r.bundled}`
      : r.error;
  };
  api.on('profile:progress', ({ text }) => { $('pf-status').textContent = text; });

  // Импорт .mrpack: окно установки показывается, когда начинается сама установка (после выбора файла)
  let importing = false;
  let importShown = false;
  const showImport = () => {
    if (importShown) return;
    importShown = true;
    $('pack-title').textContent = 'Импорт сборки';
    $('pack-text').textContent = 'Подготовка...';
    $('pack-bar').style.width = '0%';
    $('pack-result').textContent = '';
    $('pack-close').classList.add('hidden');
    $('pack-modal').classList.remove('hidden');
  };
  api.on('pack:progress', () => { if (importing) showImport(); });

  $('pf-mrpack').onclick = async () => {
    $('pf-mrpack').disabled = true;
    importing = true;
    importShown = false;
    const r = await api.invoke('profile:import');
    importing = false;
    $('pf-mrpack').disabled = false;
    if (r.canceled) return;
    showImport();
    $('pack-close').classList.remove('hidden');
    if (!r.ok) {
      $('pack-text').textContent = 'Не удалось импортировать сборку';
      $('pack-result').textContent = r.error;
      return;
    }
    $('pack-bar').style.width = '100%';
    $('pack-text').textContent = `Готово: создан профиль «${r.profile.name}»`;
    $('pack-result').textContent = r.missing.length
      ? `Не скачалось файлов: ${r.missing.length} (${r.missing.slice(0, 3).join(', ')}${r.missing.length > 3 ? '…' : ''}). Часть модов можно докачать вручную.`
      : 'Все файлы сборки скачаны. Выбери профиль и нажми «ИГРАТЬ» — загрузчик установится при первом запуске.';
    await loadProfiles();
  };

  // ====================== СВЯЗКА С ОСТАЛЬНЫМ ИНТЕРФЕЙСОМ ======================
  window.onViewShown = (name) => {
    if (name === 'play') { loadStats(); loadNews(false); }
    if (name === 'worlds') loadWorlds();
    if (name === 'skins') loadSkins();
  };
  window.onProfileChanged = () => {
    if (viewActive('worlds')) loadWorlds();
  };
  api.on('tray:play', () => { if (!$('btn-play').disabled) { showView('play'); $('btn-play').click(); } });

  document.addEventListener('keydown', (e) => {
    const open = (id) => !$(id).classList.contains('hidden');
    if (e.key === 'Escape') {
      ['con-modal', 'crash-modal', 'news-modal', 'shot-modal'].forEach((id) => $(id).classList.add('hidden'));
    } else if (open('shot-modal') && (e.key === 'ArrowLeft' || e.key === 'ArrowRight')) {
      openShot(shotIdx + (e.key === 'ArrowRight' ? 1 : -1));
    }
  });

  // Если в интерфейсе что-то сломалось, показываем текст ошибки на экране (по нему можно найти причину)
  let errBanner = null;
  const showError = (msg) => {
    if (!errBanner) {
      errBanner = document.createElement('div');
      errBanner.style.cssText = 'position:fixed;left:12px;right:12px;bottom:76px;z-index:200;background:rgba(120,20,30,.94);color:#fff;border-radius:12px;padding:10px 14px;font-size:12px;line-height:1.4;cursor:pointer;word-break:break-word;';
      errBanner.title = 'Нажми, чтобы скрыть';
      errBanner.onclick = () => errBanner.remove() || (errBanner = null);
      document.body.appendChild(errBanner);
    }
    errBanner.textContent = `Ошибка интерфейса: ${msg}`;
  };
  window.addEventListener('error', (e) => showError(e.message || 'unknown'));
  window.addEventListener('unhandledrejection', (e) => showError(String((e.reason && e.reason.message) || e.reason || 'unknown')));

  // первая загрузка главного экрана
  loadStats();
  loadNews(false);
})();
